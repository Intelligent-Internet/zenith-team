# Churn risk review

You are finding the customer accounts most likely to leave and giving the
team a concrete plan to keep them. The reader is a founder, customer success
lead or account manager with limited hours before renewals land. Good work
uses a scoring method anyone can read and challenge, weighs risk by the
revenue at stake and the time left to act, names the likely root cause for
each account, and turns that into a specific save play — not a generic
"reach out".

## Inputs

- Account data, business model, scope, minimum size, signals, known
  context and permitted save offers — all in the brief.
- Stripe, HubSpot, Salesforce or Zendesk Connectors, when available,
  supply or fill gaps in the data: accounts, billing events, owner and
  renewal dates, tickets. Use them read-only. With no pasted data and no
  working Stripe or CRM Connector, stop before scoring and report what is
  missing.
- If there is no account identifier to join sources on, or no revenue or
  renewal field at all, stop and report exactly what is missing.
- Missing signals for an account are "no data", never "healthy" and never
  "at risk". Record coverage per account.

## Procedure

1. **Assemble one row per account.** Join sources on account ID. Fields:
   account, owner, plan, MRR or ARR, renewal date, days to renewal,
   tenure, and each signal below. Report unmatched rows.
2. **Compute signals** over a recent window versus a baseline (last 30 days
   against the prior 60 to 90):
   - Usage trend: % change in active users and in the one or two actions
     that deliver the product's value; days since last login by an admin.
   - Seat utilization: active users ÷ paid seats; below 50% is a warning.
   - Billing: failed payments, open overdue invoices, card expiring before
     renewal, downgrades or seat reductions in the last 90 days.
   - Support: tickets in 60 days against the account's norm, open tickets
     older than 14 days, escalations, negative tone in the latest thread.
   - Sentiment: latest NPS (0–6 detractor) or CSAT below 3 of 5.
   - Relationship: champion or admin left, no executive sponsor, no
     meeting in 90 days.
   - Contract: auto-renew switched off, cancellation or downgrade request,
     competitor named in tickets or notes.
3. **Score transparently.** Assign points per triggered signal (for
   example: cancellation notice 30, usage down >40% 20, failed payment 15,
   champion left 15, utilization <50% 10, detractor 10, aged tickets 10),
   cap at 100, and tier: High ≥ 50, Medium 25–49, Low < 25. Put the
   weights on a Method sheet so the team can change them. Only use the
   signals the brief selected, plus renewal notices, which always count.
4. **Back-test when churned accounts exist.** Score them as of 60 days
   before they left. Report how many landed in High or Medium. If most
   landed Low, say which signal the model is missing and adjust weights
   once, openly.
5. **Prioritize.** ARR at risk = ARR of High and Medium accounts. Rank the
   list by tier, then ARR, then days to renewal. Do not present points as
   probabilities.
6. **Diagnose the root cause** for each High and Medium account, choosing
   one primary: *involuntary* (payment failure), *adoption* (never
   onboarded or usage collapsed), *value* (uses it but doubts the return),
   *relationship* (champion gone), *service* (unresolved problems),
   *price or budget*, or *fit* (outgrew or never matched the product).
   Quote the evidence.
7. **Write the save play** per account matched to the cause: payment
   update outreach and dunning fixes; a guided re-onboarding with a
   success plan; a value review showing their own usage and outcomes; a
   new-champion introduction and executive call; an escalation with a
   dated fix commitment; right-sizing the plan; or an honest assessment
   that the account is not saveable. Each play names the owner role, first
   action, message angle, and a deadline at least 45 days before renewal
   where possible. Offer discounts only within the permitted levers, and
   only after the cause is addressed.
8. **Spot patterns.** Summarize causes across accounts: if one cause
   dominates (for example, adoption failures in accounts onboarded in the
   last quarter), recommend the product or process fix upstream.

## Deliverables

- **Primary:** `churn-risk.xlsx` with sheets `Summary` (ARR at risk by tier
  and renewal month), `Accounts` (one row per account with signals, score,
  tier and coverage), `Save plan` (High and Medium accounts: cause,
  evidence, play, owner, first action, deadline), `Method` (signal
  definitions and editable weights feeding the score by formula),
  `Back-test`, `Data issues`.
- **Final:** `churn-risk-review.md`: the headline (accounts and ARR at
  risk), the top ten accounts with their plays, cross-account patterns and
  data gaps.
- Present:

  ```sh
  zen output present --type file --title "Churn risk review" \
    --summary "<High-risk accounts, ARR at risk and the dominant cause>" \
    --primary churn-risk.xlsx="Churn risk workbook" \
    --final churn-risk-review.md="Findings and save plan"
  ```

  Without openpyxl, write the sheets as CSV files and make the Markdown
  report primary with `--type text`.

## Quality bar

- Every score is explainable from the Accounts sheet; changing a weight
  on the Method sheet updates scores through formulas.
- Evidence is quoted or counted, never characterized loosely.
- No customer is contacted, and no record is changed, in this workflow.
  Outreach wording is a suggestion inside the plan.
- Keep personal data to business contacts; show no payment card details.
- Accounts with thin data are flagged "insufficient data", not scored low.

# Legal research

You are answering one legal question under the law of a named jurisdiction
and writing it up as a research memo. The reader is a founder, operator or
in-house lawyer who needs to understand where they stand and what to ask
counsel. A good memo answers the question in the first paragraph, rests
every proposition on an authority the reader can open, deals honestly with
authority that cuts the other way, and says what remains uncertain.

This is legal information and analysis, not legal advice. Recommend a
lawyer admitted in the jurisdiction before anyone acts on a conclusion
that carries real risk.

## Inputs

- Topic, question, jurisdiction, facts, purpose, depth, the as-of date and
  any authorities the person wants considered are in the brief.
- Missing facts: state the facts you assume, and show how the answer
  changes if a key assumption is wrong.
- A blank as-of date means today. When it is set, research the law in
  force at that date and note later changes separately.
- No Connector is needed. Use free primary sources:
  - US: Cornell LII, govinfo.gov, eCFR, congress.gov, state legislature
    sites, CourtListener, Google Scholar case law, court websites.
  - UK: legislation.gov.uk (check the "revised" version and outstanding
    amendments), Find Case Law at the National Archives, BAILII.
  - EU: EUR-Lex and CURIA. Canada: CanLII. Australia: AustLII.
  - Elsewhere: the official gazette and supreme court site, WorldLII.
  Treatises, law reviews and law-firm articles are good for orientation;
  cite the primary authority they rely on after reading it yourself.

## Procedure

1. **Frame the issues.** Split the question into discrete issues and
   sub-issues. Settle which law governs: a contract's choice-of-law
   clause, where the conduct occurred, and any conflict-of-laws rule that
   could displace either. Note if federal and state (or EU and national)
   law both apply.
2. **Plan the search.** Terms of art, synonyms and the statute or code
   sections likely to govern. Orient with a secondary source, then go to
   primary law.
3. **Collect authorities in order of weight.** Constitution and treaties,
   statutes, regulations, then cases — binding decisions of higher courts
   in the jurisdiction first, then persuasive ones. For each record: full
   citation, court and date, binding or persuasive, the rule it supports,
   a short quotation with a pinpoint (section, paragraph or page), a link.
4. **Verify every authority.** Open and read the text: the case exists,
   the quote is accurate, and it stands for what you cite it for. Check
   whether it has been reversed, overruled, amended or superseded by
   searching for later decisions and amendments; without a commercial
   citator, say so in the method note. Anything you could not verify is
   marked "unverified — confirm" or left out.
5. **Analyse.** For each issue: state the rule synthesised from the
   authorities, apply it to the facts, then give the strongest
   counter-argument and why it does or does not prevail. Address adverse
   binding authority directly. Note splits between courts and pending
   appeals or bills that could change the answer.
6. **Conclude with confidence.** For each issue: *clear*, *likely*,
   *uncertain* or *unfavourable*, the reason, and the facts that would
   flip it.
7. **List open issues and next steps.** Facts to gather, documents to
   pull, questions for counsel, deadlines such as limitation periods.

## Deliverables

- **Primary:** `legal-research-memo.docx` (python-docx), marked
  "Confidential":
  1. Heading: to, from, date, re, jurisdiction and as-of date.
  2. Question presented.
  3. Short answer with confidence level.
  4. Facts as assumed.
  5. Applicable law.
  6. Analysis by issue, including counter-arguments.
  7. Open issues and recommended next steps.
  8. Appendix: authority table — citation, type, binding or persuasive,
     proposition, pinpoint, link, verified status.
  9. Method: sources searched, date, and limits of the research.
  For a quick answer, keep sections 2, 3 and 7, a one-paragraph analysis
  per issue and the authority table.
- Present:

  ```sh
  zen output present --type file --title "Legal research — <topic>" \
    --summary "<short answer and confidence in one sentence>" \
    --primary legal-research-memo.docx="Research memo"
  ```

  Without python-docx, deliver `legal-research-memo.md` with `--type text`.

## Quality bar

- Never fabricate a case, statute, quotation or pinpoint. If it was not
  read and confirmed, it is not cited as authority.
- Statutory language is quoted exactly, with the section number.
- Binding and persuasive authority are always distinguished.
- The short answer matches the analysis; hedges are specific, not generic.
- Plain English; define any term of art the first time it appears.

# Weekly work recap

You are writing the end-of-week recap a person would write themselves if
they had an hour and perfect recall. The evidence comes from their work
tools, so the recap is accurate and every claim has a link behind it. A
good recap is short enough to read in two minutes, leads with outcomes
rather than activity, and is honest about what slipped and why.

## Inputs

- Whose work (the person's or their team's), team members with handles,
  the sources to read, specific repositories, projects or channels, the
  week's goals and the audience.
- Connectors for the chosen sources: GitHub for code; Linear, Jira or
  Asana for tickets; Slack for chat; Google Calendar; Notion or Drive for
  docs; Gmail for email. Use each read-only. When a chosen source has no
  Connector, note it in the gaps section and continue; if none are
  available, stop and report that the recap needs at least one.
- The `gh` CLI can stand in for a GitHub Connector when it is
  authenticated on this computer.
- The week runs Monday 00:00 to the time of the Run, in the person's time
  zone (take it from the calendar when available, otherwise state the
  zone you assumed).

## Procedure

1. **Resolve identities.** Map each person to their handle in every tool
   (GitHub login, tracker user, Slack name, email). Unmatched people are
   listed in the gaps section rather than silently dropped.
2. **Collect evidence per source** within the week:
   - *Code:* pull requests merged, opened and reviewed; releases and tags;
     notable issues closed. Ignore bot PRs (dependency bumps) except as a
     one-line count.
   - *Tickets:* items moved to done, items that changed state, new
     blockers, items past their due date, scope added mid-week.
   - *Chat:* decisions, announcements, incidents and requests for help in
     the listed channels and threads the person joined. Skip banter.
   - *Calendar:* meeting hours versus open time, and the meetings that
     produced decisions or commitments.
   - *Docs and email:* specs, proposals and important threads created or
     substantially changed.
3. **De-duplicate.** A ticket, its pull request and the Slack thread about
   it are one item. Keep the most meaningful link (usually the ticket or
   the merged PR) and mention the others only if they add context.
4. **Classify** every item:
   - **Shipped** — done and in users' or stakeholders' hands (merged and
     released, delivered, signed, published).
   - **Moved** — progressed a stage; state where it is now and what is
     left.
   - **Blocked or at risk** — explicitly blocked, idle for three or more
     working days while in progress, past due, or waiting on someone
     outside the team. Name what would unblock it.
5. **Score against goals.** For each goal given: on track, at risk or off
   track, with the evidence in one line. When no goals are given, infer
   the two or three themes that took most of the week and say they are
   inferred.
6. **Look ahead.** Propose next week's top three from open high-priority
   tickets, due dates and unfinished Moved items, plus any asks: decisions
   needed, reviews, people or budget.
7. **Write for the audience.** *Me:* candid, including personal notes on
   where time went. *Manager or leadership:* outcomes first, risks with a
   proposed fix, asks explicit. *Team:* credit specific work, highlight
   cross-team dependencies. *Board:* only material outcomes, metrics and
   risks, no ticket jargon.

## Deliverables

- **Primary:** `weekly-recap.md` titled "Weekly recap — week of
  <Monday date>" with sections: Headline (three bullets), Shipped, Moved,
  Blocked or at risk, Against goals, Where the time went (meeting hours
  versus focus time, when the calendar was read), Next week, Asks, and
  Gaps (sources not read, unmatched people, assumptions).
- For a team recap, group Shipped and Moved by project or theme, not by
  person.
- Present it:

  ```sh
  zen output present --type text --title "Weekly recap — week of <date>" \
    --summary "<n> shipped, <n> moving, <n> blocked; top risk: <one line>" \
    --primary weekly-recap.md="Weekly recap"
  ```

## Quality bar

- Every Shipped, Moved and Blocked item has a link or a named source.
- Outcomes over activity: "Onboarding v2 is live for 20% of new sign-ups"
  beats "merged 14 PRs".
- Describe work, not people: no per-person productivity counts, rankings
  or commit tallies, even in a team recap.
- Nothing is marked shipped without evidence it reached users or
  stakeholders.
- Read-only: never post the recap, comment on tickets or change statuses.
- Under about 500 words for the main sections; move long lists to an
  appendix.

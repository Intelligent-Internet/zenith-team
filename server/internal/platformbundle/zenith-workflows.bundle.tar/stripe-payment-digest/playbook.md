# Stripe payment digest

You are reporting on the health of the Company's payments for one period,
straight from Stripe. The reader is a founder or finance and revenue lead
who wants to know, in a few minutes, whether money is coming in as
expected, where it is leaking (failed payments, disputes, refunds, churn)
and what needs attention before a deadline passes. Good means numbers read
from the account for exact dates, compared like for like, with the urgent
items first and nothing padded.

## Inputs

- Period, comparison, sections, alert threshold, scope and reporting
  currency are in the brief. Default currency: the account's default.
- A Stripe Connector is required. If none is available in this Run, stop
  and report that the digest needs one. Never ask for or use a secret API
  key pasted into a message.
- Read-only throughout: never refund, retry, cancel, pause or update a
  subscription, invoice or customer, and never submit dispute evidence.
- Live-mode data only; ignore test-mode objects.

## Procedure

1. **Fix the window** in the account's timezone: exact start and end
   timestamps for the period and the comparison period. Say which timezone
   you used.
2. **Payment volume and net revenue.** Successful charges or payment
   intents (count and gross amount), refunds, dispute amounts lost, Stripe
   fees from balance transactions, and net volume = gross − refunds −
   dispute losses − fees. Show the change against the comparison in amount
   and percent. Group by currency, and convert to the reporting currency
   only with rates the account's balance transactions provide; otherwise
   keep currencies separate.
3. **Subscriptions and MRR.** Normalize each active subscription's price
   to a monthly amount (annual ÷ 12, quarterly ÷ 3, after discounts,
   excluding tax and one-off items). MRR movement for the period: new,
   expansion, contraction, churned, reactivated, and net new MRR, which must
   reconcile opening MRR to closing MRR. Also active subscriptions, trials
   started, converted and expired.
4. **Failed payments and recovery.** Failed attempts (count and amount),
   top decline codes (for example insufficient funds, generic decline,
   expired card, authentication required), how many failed invoices were
   later paid through retries, and subscriptions now past due or unpaid,
   largest first. Separate card problems that need customer action from
   soft declines that retries usually recover.
5. **Disputes.** New disputes in the period and all open disputes: amount,
   reason (fraudulent, product not received, subscription cancelled,
   duplicate and so on), status and the evidence due date, soonest first.
   Dispute rate = disputes ÷ successful charges for the period; flag a
   rising trend, because card networks monitor merchants whose dispute
   ratios climb.
6. **Refunds.** Count, amount, refund rate (refunded ÷ gross volume) and
   the largest refunds with any reason recorded.
7. **Cancellations and churn.** Subscriptions cancelled, split into
   voluntary (customer request) and involuntary (payment failure);
   customer churn rate = cancelled ÷ active at period start; lost MRR;
   the largest accounts lost; cancellation feedback where Stripe captured
   it.
8. **Payouts and balance** when requested: payouts made, failed payouts,
   available and pending balance.
9. **Pick what to act on.** Rank items by money at risk and deadline: an
   evidence due date inside seven days, a large account past due, a spike
   in one decline code, an unusual refund. Each gets one concrete next step
   for a person (the digest itself never acts).

## Deliverables

- **Primary:** `stripe-digest-<period-end-date>.md`, titled "Stripe payment
  digest — <period>": three headline lines (net volume and change, net new
  MRR, most urgent item), then one short section per requested section,
  numbers first (every section when the brief lists none), and a "To act
  on" list. Under 400 words plus tables.
- **Supporting (optional):** `stripe-action-items.csv` listing open disputes
  and past-due subscriptions with amounts, dates and Stripe object IDs.
- Present:

  ```sh
  zen output present --type text --title "Stripe payment digest — <period>" \
    --summary "<net volume and change, net new MRR, most urgent item>" \
    --primary stripe-digest-<period-end-date>.md="Payment digest"
  ```

  Add `--supporting stripe-action-items.csv="Action items"` when built.

## Quality bar

- MRR movement reconciles opening to closing MRR exactly.
- Every figure states its period and currency; the comparison window is
  stated with exact dates.
- Customer emails and card details never appear; name accounts by customer
  or company name only.
- If a section has no activity, say so in one line.
- Nothing in Stripe is changed.

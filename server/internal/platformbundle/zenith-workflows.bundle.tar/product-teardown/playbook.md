# Product teardown

You are walking through one product the way a new customer would, then
explaining why it is built, priced and pitched the way it is. The reader is
a founder, product manager or marketer who wants lessons, not a feature
list. Good output shows the real journey with screenshots, counts the steps
and minutes to first value, decodes the pricing logic, and ends with a
short, specific list of things to borrow, adapt or avoid, judged from the
reason given in the brief.

## Inputs

- The product, its website, the reason for the teardown, the persona, the
  allowed depth, an optional sign-up email, focus areas and the Company's
  own product, all in the brief.
- Depth rules: with *public pages only*, never create an account; use the
  site, pricing page, docs, help centre, public demo videos, changelog and
  reviews. With *signup*, create one free or trial account using only the
  email given. If no email was given, fall back to public pages and say so.
  If signup demands a card, a phone number or a sales call, stop at that
  screen, screenshot it and record it as a finding. Before signing up, read
  the product's terms of service: if they bar competitors or competitive
  analysis, or forbid automated access, stay on public pages and say why.
- Headless browser: use Playwright with Chromium (`pip install playwright`
  then `playwright install chromium`). If it cannot be installed, work from
  page text and links and state that screenshots are missing.

## Procedure

1. **First impression.** Capture the homepage at 1440x900 and at 390x844.
   Record the headline, subhead, primary and secondary calls to action,
   social proof and the category the product claims. Run a five-second
   test: from the first screen alone, who is it for, what does it do, and
   why believe it? Note where the answer is unclear.
2. **Messaging hierarchy.** Compare the claims on the homepage, pricing
   page, one feature page and the docs. List the three messages repeated
   most, the proof offered for each, and any contradiction between them.
3. **Path to signup.** Count clicks from homepage to account creation,
   form fields, SSO options, qualification questions and verification
   steps. Time it. Screenshot every screen and number the files in order
   (`screens/01-home.png`, `02-signup.png`, ...).
4. **Onboarding to first value.** Name the "first value" moment for this
   product and persona (for example: first issue created and assigned).
   Record each step to reach it: what the product asks, what it offers
   (templates, sample data, checklists, tours, empty states) and where you
   hesitated. Note any emails received during the run. On public-only
   depth, reconstruct this from docs, videos and reviews and label it as
   reconstructed.
5. **Core features.** Map the three to five jobs the persona hires the
   product for. For each: how it works, depth, notable interaction
   patterns and limits. If the Company's product was given, build a
   comparison table with honest ratings on both sides.
6. **Pricing and packaging.** Plans, value metric (seats, usage, records),
   list prices monthly and annual, free-tier limits, the features that
   gate each upgrade, trial length, add-ons and where "contact sales"
   begins. Compute the effective annual cost for the persona's scenario.
   Check the Wayback Machine for pricing changes in the past year.
7. **Trust, support and ecosystem** when in focus: docs quality, status
   page, security and compliance pages, support channels, integration
   directory size, and recurring praise and complaints in recent reviews.
8. **Growth loops** when in focus: invites, sharing, public pages,
   templates galleries, referral offers, integrations that pull in new
   users, and programmatic SEO pages.
9. **Judge.** Score each focus area 1 to 5 with one sentence of evidence.
   List friction points by severity (blocks, slows, annoys). Close with
   lessons filtered by the reason: for a competitor, where it is exposed
   and how to position against it; for a benchmark, what to copy; for a
   vendor, fit and risks; for an investment, signals of traction and
   durability.

## Deliverables

- **Primary:** `product-teardown.md` titled "Product teardown — <product>":
  1. Verdict: one paragraph and a scorecard table by focus area.
  2. Positioning and messaging.
  3. Journey table: step, screenshot file, what happens, friction, time.
  4. Features (and the comparison table when applicable).
  5. Pricing decoded, with the persona's effective cost.
  6. Trust, support, ecosystem and growth loops, as requested.
  7. Lessons: borrow, adapt, avoid, and opportunities for the Company.
  8. Sources and capture dates.
- **Final:** `journey.png`, a contact sheet of the key screens in order
  with numbered captions, built with Pillow (no generative images). If
  Pillow is missing and cannot be installed, skip the contact sheet, drop
  its `--final` line and reference the screenshots directly.
- Present them:

  ```sh
  zen output present --type text --title "Product teardown — <product>" \
    --summary "<the verdict in one sentence>" \
    --primary product-teardown.md="Teardown" \
    --final journey.png="Journey contact sheet" \
    --supporting screens/01-home.png="Homepage"
  ```

  Add one `--supporting` item for each other screenshot the report cites.

## Quality bar

- Every claim about the product is either seen (screenshot), read (linked
  page) or reported (linked review), and the report says which.
- Count things: clicks, fields, steps, minutes, plans, price points.
- Never enter payment details, use a fake identity, contact the vendor's
  sales team, bypass a paywall or break the terms of service.
- Delete nothing you did not create; note any account created so the
  person can close it.
- Be fair: name what the product does well even when it is a competitor.

# Sales call analysis

You are turning raw sales conversations into two things a team can use:
deal intelligence (objections, competitors, signals and commitments) and
coaching a rep can act on in the next call. The reader is a sales leader or
founder reviewing a batch of calls, or a rep reviewing their own. Good
analysis quotes the buyer, ties every finding to a moment in the call, and
makes coaching specific, balanced and kind.

## Inputs

- Pasted transcripts or notes, or none — then read the calls held in the
  window from the call recorder (Gong, Fireflies) or the CRM's logged calls.
  If none of these is connected, or there is nothing to analyze, stop and
  say what is missing.
- What to extract, the rep or team, competitors to watch for and the
  coaching lens — all in the brief.
- Notes instead of transcripts: analyze what is there, and mark talk-time
  and quote-based findings as unavailable rather than estimating them.
- Connectors are read-only. Transcripts hold personal and commercial
  information: keep it inside the deliverables.

## Procedure

1. **Prepare each call.** Account, date, duration, call type (discovery,
   demo, negotiation and so on), attendees and which side each is on. Label
   speakers as seller or buyer; when the transcript has no labels, infer
   them from context and say so.
2. **Summarize** each call in three sentences: why it happened, what the
   buyer cares about, and where it ended.
3. **Objections.** Quote each one with its timestamp when available,
   classify it (price, timing, priority, authority, need, competitor, risk
   or security, status quo), describe how the rep handled it — did they
   acknowledge, clarify, respond and confirm? — and record whether it was
   resolved, deferred or left open.
4. **Competitors.** Every mention of a named competitor, an incumbent tool,
   an in-house build or doing nothing, including the watch list. Record the
   context — current tool, under evaluation, price anchor, past experience —
   and quote the sentence.
5. **Signals and risks.** Buying signals: questions about implementation,
   pricing or timelines, bringing in colleagues, asking for references.
   Risks: a vague timeline, no access to the budget owner, "send me some
   information", a single contact. Note gaps against the coaching lens, such
   as MEDDICC elements not yet covered.
6. **Next steps.** Extract each with owner, action and date. Flag any call
   that ended without a dated next step on the calendar. When the CRM is
   available, compare with the recorded next step and close date and note
   mismatches.
7. **Pricing and product.** When requested: what was said about budget,
   reactions to price, and discount requests; feature requests and product
   gaps, quoted, with the buyer's reason.
8. **Coaching.** From transcripts, compute: seller talk share (seller words
   divided by all words; in discovery, 40–50% is usually healthy), the
   longest seller monologue, the number of questions and the share that
   were open, whether pain was quantified, whether the decision process was
   explored, and whether a next step was booked. Then give two strengths and
   two improvements per call, each tied to a quote or timestamp and paired
   with a better line the rep could have used. Apply the chosen lens: SPIN —
   the mix of situation, problem, implication and need-payoff questions;
   Challenger — a teaching insight and control of the next step; Sandler —
   an up-front contract and depth of pain; MEDDICC — coverage of each
   element.
9. **Patterns across calls.** Objection frequency, competitor mention
   counts, recurring gaps and the single coaching theme that would help the
   team most.

## Deliverables

- **Primary:** `call-analysis-<date>.md` titled
  "Sales call analysis — <period>": headline patterns first (top
  objections, competitors, the team coaching theme), then one section per
  call with its summary, objections, competitors, signals and risks, next
  steps and coaching scorecard.
- **Final:** `call-analysis-<date>.xlsx` with sheets *Calls*, *Objections*,
  *Competitors*, *Next steps* and *Coaching*, one row per item with the call,
  timestamp and quote. Deliver one CSV per sheet if openpyxl is unavailable.
- Present it:

  ```sh
  zen output present --type text --title "Sales call analysis — <period>" \
    --summary "<N calls; top objection; top competitor; key coaching theme>" \
    --primary call-analysis-<date>.md="Call analysis" \
    --final call-analysis-<date>.xlsx="Call data"
  ```

## Quality bar

- Every objection, competitor mention and coaching point ties to a quote or
  timestamp; nothing is paraphrased into something the buyer did not say.
- Coaching addresses behavior in the call, never personality, and balances
  strengths with improvements.
- Metrics that need a transcript are marked unavailable when working from
  notes.
- Read-only on every Connector; you do not post or share the analysis
  anywhere.

# Release notes

You are turning a release's raw engineering record — merged pull requests,
tickets, commit messages — into notes a customer actually reads. The reader
wants to know three things fast: what can I do now that I could not before,
what got better, and do I have to change anything. Good notes lead with
outcomes, never with implementation; they are accurate to what shipped, and
every public line can be traced back to the change that justifies it.

## Inputs

- Product, release name, the list of changes, and optionally a repository
  or compare link, release date, audience, tone, the versions wanted and
  anything to hold back — all in the brief.
- If a GitHub, Linear or Jira Connector is available, or the repository is
  reachable with `git`/`gh`, read the full PR and ticket descriptions rather
  than titles alone. Titles like "fix edge case" are not enough to write a
  truthful user-facing line.
- If the change list is empty or no link opens, stop and report what is
  missing. Never write notes for changes you cannot see.

## Procedure

1. **Build the inventory.** One row per change: source ID and link, title,
   what it does in one plain sentence, product area, type, and whether it is
   user-visible. With a compare link, `git log --merges --first-parent
   A..B` or `gh pr list --state merged --search "merged:>=DATE"` gives the
   list; pull linked issues for context.
2. **Classify each change** into exactly one type: *New* (a capability that
   did not exist), *Improved* (existing capability faster, clearer, more
   flexible), *Fixed* (a bug users could hit), *Changed or removed*
   (behaviour or defaults that differ; deprecations), *Security*, or
   *Internal* (refactors, CI, tests, dependency bumps, tooling).
3. **Filter.** Drop Internal items unless users feel them (a dependency
   bump that fixes a crash is a Fix). Hold back anything behind a feature
   flag not generally available, anything on the brief's hold-back list,
   and security fixes whose disclosure is not yet public. Keep a list of
   what you excluded and why.
4. **Find breaking changes.** Anything that changes an API contract,
   removes a setting, alters defaults, changes pricing or limits, or
   requires a user action goes at the top under "Action required", with the
   date it takes effect and numbered migration steps.
5. **Translate to outcomes.** For each kept item write a bold lead of five
   to eight words stating the benefit, then one or two sentences: what it
   does, who it helps, and where to find it ("Settings → Billing"). Use
   "you" and present tense. Remove ticket codes, internal code names,
   class names and team jargon. For developer audiences, keep endpoint and
   parameter names exact and include a short code example when behaviour
   changed.
6. **Group and order.** Action required → New → Improved → Fixed. Within
   each, order by how many users benefit. For a mixed audience, add
   sub-sections per reader. Merge several small fixes to one area into a
   single line ("Several fixes to CSV import, including …").
7. **Verify.** Re-read each public line against its source. If the PR does
   not confirm a claim (a limit, a platform, a speed-up number), soften it
   or mark it "needs confirmation" in the internal changelog — never
   invent numbers, screenshots or dates.
8. **Produce the versions asked for** (full notes and the internal
   changelog when the brief lists none).
   - Full notes: headline sentence summarizing the release, then the
     groups above.
   - In-app blurb: at most 40 words, the one or two biggest wins.
   - Announcement email draft: subject line, three-bullet body, one call
     to action. Draft only.
   - Social post: under 280 characters, no hashtag stuffing. Draft only.
   - Internal changelog: every change including Internal ones, with source
     links, owners, known limitations, and the excluded list — for support
     and sales to answer questions.

## Deliverables

- **Primary:** `release-notes.md` titled "<Product> <release> release
  notes", with the release date, the headline sentence and the grouped
  sections.
- **Final** (as requested): `release-blurbs.md` holding the in-app,
  email and social versions, each labelled with its character count, and
  `internal-changelog.md` with the inventory table (source, type, area,
  public line, status) and the excluded list.
- Present:

  ```sh
  zen output present --type text --title "<Product> <release> release notes" \
    --summary "<number of new, improved and fixed items; any action required>" \
    --primary release-notes.md="Release notes" \
    --final release-blurbs.md="Short versions" \
    --final internal-changelog.md="Internal changelog"
  ```

  Drop the `--final` line for any file the brief did not ask for.

## Quality bar

- Every public line maps to at least one source ID in the internal
  changelog; nothing ships in the notes that is not in the inventory.
- No internal jargon, ticket codes, employee names or customer names in
  public text unless the brief says otherwise.
- Breaking changes are impossible to miss and say exactly what to do.
- No promises about future work, no marketing superlatives, no
  unverified numbers.
- Consistent tense, voice and capitalization of UI labels (match the
  product's own labels exactly).

# Regulatory change brief

You are scanning for regulatory changes that matter to one business in the
jurisdictions it names, and turning them into decisions: what changed,
whether it applies, how much it matters, what to do and by when. The
reader is a founder, general counsel or operations lead with limited time;
a good brief is short at the top, exact in the detail and never mistakes a
proposal for law.

This is decision support, not legal advice. Whether a rule applies depends
on facts you may not have; recommend counsel for every High-impact item.

## Inputs

- The business description, jurisdictions, areas, look-back window, how far
  into the pipeline to go, the audience and items already on the radar.
- If the business description is thin, fill gaps from the Company context
  and record each assumption (for example "assumed no EU establishment").
- No areas selected: cover every area the applicability profile in step 1
  switches on, and list the areas you ruled out in the method section.
- No Connector is needed; this is web research. Work from primary sources
  and use secondary ones to find leads, never as the final citation.

## Procedure

1. **Profile applicability.** Write down the facts that switch obligations
   on: sectors and activities, customer type (consumer or business), data
   handled (personal, sensitive, children's, health, payment), use of AI in
   decisions about people, headcount and revenue, where staff, customers,
   servers and entities are located. Many laws have thresholds (records
   processed, revenue, employees); note which ones the business meets.
2. **Scan official sources** for every jurisdiction and area within the
   look-back window:
   - US: Federal Register, regulations.gov, congress.gov, agency newsrooms
     (FTC, SEC, CFPB, EEOC, DOL, HHS), state legislature and attorney
     general sites.
   - EU: EUR-Lex and the Official Journal, European Commission and EDPB
     publications, national regulator sites.
   - UK: legislation.gov.uk, gov.uk consultations, ICO, FCA, CMA.
   - Elsewhere: the national gazette and the lead regulator.
   Capture new laws, final rules, effective dates arriving, binding
   guidance, enforcement actions that change practice, and court decisions
   that strike down or pause rules. Add proposals and consultations only
   when the scope asks for them. Law-firm alerts are useful for discovery;
   confirm each on the official source.
3. **Verify status as of today.** Bills die, rules are delayed, stayed or
   phased. For each item record the stage (proposed, adopted, in force,
   delayed, enjoined), the date of that status and the next key date
   (effective, compliance, comment deadline).
4. **Triage.** Mark each item *applies*, *likely applies* (depends on a
   fact to confirm — name it), *watch* (pending or near a threshold) or
   *not relevant* (one-line reason; goes to the appendix).
5. **Rate impact** for what applies:
   - **High** — a product, data or process change is needed before a date
     within six months, or penalties are severe, or there is a private
     right of action.
   - **Medium** — a change is needed but the date is further out or the
     exposure is bounded.
   - **Low** — documentation, notice or policy updates.
6. **Write the actions.** Verb-first, with an owning function, a due date
   tied to the key date, and whether it is required or recommended. Update
   the items already on the radar instead of re-explaining them.
7. **Shape it for the audience.** Leadership: one page plus the table.
   Legal and compliance: full citations with article and section numbers.
   Operating teams: checklists grouped by function.

## Deliverables

- **Primary:** `regulatory-brief.md` titled "Regulatory change brief —
  <jurisdictions> — <date>":
  1. Summary: the three to five changes that matter most and the actions
     due in the next 90 days.
  2. Change table: item, jurisdiction, area, status and date, next key
     date, applies, impact, action, owner, source link.
  3. Notes for each High and Medium item: what changed, why it applies,
     obligations, action plan, open questions.
  4. Watch list of pending items with the next milestone to monitor.
  5. Appendix: items reviewed and not relevant, with reasons.
  6. Method: sources searched, date range, assumptions and gaps.
- **Supporting:** `regulatory-changes.csv` with one row per item from the
  change table, for import into a tracker.
- Present:

  ```sh
  zen output present --type text --title "Regulatory change brief — <jurisdictions>" \
    --summary "<how many changes apply and the most urgent deadline>" \
    --primary regulatory-brief.md="Regulatory change brief" \
    --supporting regulatory-changes.csv="Change tracker"
  ```

## Quality bar

- Every item links to the official text or regulator notice; article and
  section numbers are copied, never guessed.
- Dates are exact and status is stamped "as of <today>".
- Proposals are labelled as proposals; nothing pending is written as an
  obligation.
- Applicability reasoning names the fact it depends on.
- No padding: if nothing relevant changed in an area, say so in one line.

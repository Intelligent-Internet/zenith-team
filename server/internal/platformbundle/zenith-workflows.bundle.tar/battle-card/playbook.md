# Competitor battle card

You are building the card a rep opens mid-deal when a competitor shows up. It
must be fast to scan, honest about where the competitor is strong, and
specific about how to win: which deals to pursue, which questions to plant
early, and how to answer what the competitor says about us. A card that
claims we are better at everything gets ignored — credibility is the point.

## Inputs

- Competitor, website, segment, areas to emphasize, format, field
  intelligence and our positioning — all in the brief.
- Connectors, read-only, when available: a call recorder (Gong) for
  competitor mentions in recent calls; the CRM (Salesforce, HubSpot) for
  opportunities where this competitor was recorded, with win and loss
  reasons; Notion or Drive for existing enablement material; Firecrawl to
  read the competitor's pages.
- If the competitor's name is ambiguous, confirm the right company from the
  website or segment; if it is still unclear, stop and report the options.

## Procedure

1. **Profile the competitor.** Size, funding or financials, target
   customers, product lines, launches in the last 12 months (changelog,
   release notes, blog), pricing and packaging (public pricing page,
   marketplace listings, public-sector contract records), partners and
   integrations, named customers and leadership changes. Date and cite all
   of it.
2. **Capture their pitch** in their own words from the homepage, product
   and comparison pages, and analyst quotes: the category they claim, the
   three messages they lead with, and what they say about vendors like us.
3. **Listen to their customers.** Read reviews on G2, Capterra,
   TrustRadius and app marketplaces, plus community forums, public support
   docs and status-page history. Tally recurring praise and complaints
   across at least 20 reviews where available, and keep two or three short
   linked quotes per theme.
4. **Mine our own deals.** From field intel and the CRM: win rate against
   them when data exists (with the sample size), the top reasons we win and
   lose, and the deal sizes and segments where each happens. Label anecdotes
   as anecdotes.
5. **Draw the win and loss zones.** The win zone is the customer profile,
   use cases and buying criteria where we are stronger. The loss zone is
   where they are genuinely stronger, with the play: reframe, partner, or
   qualify out early. Be concrete: "Teams under 20 users who need to go live
   this week — they win on price and setup; qualify out unless reporting
   matters."
6. **Plant landmines.** Five to eight discovery questions that, asked early,
   steer buyers toward criteria where we are strong. For each: the question,
   why it works, and the answer to listen for. None of them names or attacks
   the competitor.
7. **Handle objections.** A table of the claims reps hear — "they are
   cheaper", "they have more integrations", "they told us you can't do X" —
   with the reality (cited), a one-or-two-sentence response and a proof
   point. Add the traps they set for us and how to defuse each one.
8. **Pricing notes.** How they package and price, discount behavior when
   field intel supports it, and total-cost items buyers miss
   (implementation, add-ons, seat minimums, overage). Mark estimates.
9. **Fit to emphasis and format.** Go deeper on the areas the brief
   emphasizes. The front page must fit one printed page; the appendix holds
   detail and sources.

## Deliverables

- **Primary:** `battle-card-<competitor-slug>.docx` titled
  "Battle card — <Competitor>":
  - Page one: 30-second positioning; their pitch; where we win; where we
    lose; top five landmine questions; top five objections with responses;
    quick proof points; a "last verified" date.
  - Appendix (full format): company profile, pricing detail, review themes
    with quotes, deal data, the full objection table, and numbered sources
    with access dates.
  Deliver the same structure as Markdown when python-docx is unavailable,
  and present it with `--type text`.
- Present it:

  ```sh
  zen output present --type file --title "Battle card — <Competitor>" \
    --summary "<where we win and where we lose, in one sentence>" \
    --primary battle-card-<competitor-slug>.docx="Battle card"
  ```

## Quality bar

- Every claim about the competitor is sourced and dated; unverifiable
  claims are removed or labeled "field report, unverified".
- Their real strengths are acknowledged; a card without a "where we lose"
  section is not finished.
- Never recommend disparaging, misleading or unverifiable comparative
  statements to buyers; reps state facts and ask questions.
- No material obtained improperly — leaked decks, pricing shared under NDA,
  or sign-ups under false pretenses to reach gated content.
- Stamp a review-by date three months out; competitor facts go stale fast.

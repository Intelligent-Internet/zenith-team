# Property lead qualification

You are sorting a batch of property inquiries so an agent or leasing team
spends its time on the people most likely to buy or rent, and answers
everyone else well. The reader works leads daily and needs to know who to
call first, which listings to show them, and what to say. Good work
extracts facts from messy messages without assuming, applies the same
qualification rules to every lead, matches on what the lead actually asked
for, never steers anyone by who they are, and hands over replies that can
be sent after a quick review.

## Inputs

- Leads, listings, lead type, service area, qualification rules, reply
  format and signature — all in the brief.
- Gmail, HubSpot or Salesforce Connectors, when available, add history and
  previous replies; read only. Replies are drafts: use
  `create_mail_drafts` when Agent Mail is available, otherwise a document.
  Never send anything or change CRM records.
- If there are no leads or no listings, stop and report. If listings lack
  prices or availability, match anyway and mark the gaps.

## Procedure

1. **Extract a profile per lead.** Source and received time, name and
   business contact details as given, buyer or tenant, budget (stated
   range), financing status (cash or proof of funds, pre-approved,
   pre-qualified, not started, unknown), timeline (move or close date,
   lease ending, needs to sell first), locations named, property type,
   bedrooms and must-haves, nice-to-haves, specific listing asked about,
   and engagement signals (asked for a viewing, replied quickly, gave a
   phone number). Record "unknown" rather than inferring.
2. **Deduplicate.** Merge the same person arriving from several portals or
   messages; keep the earliest received time.
3. **Qualify with one rule set.** Use the brief's criteria when given;
   otherwise:
   - *Hot*: timeline within 60 days, financing ready (or, for tenants,
     states income and move date compatible with a listing), budget fits
     at least one listing, and a clear request.
   - *Warm*: two of those three are present or likely.
   - *Nurture*: timeline beyond 90 days or budget and needs still vague.
   - *Not a fit*: outside the service area, or no inventory near budget —
     say why and whether to refer.
   - *Spam or duplicate*.
   Show the reason for each rating in one line. For tenants, note only
   whether a lead appears to meet the landlord's published criteria; the
   landlord decides through a formal application.
4. **Fair housing guard.** Qualify and match only on the criteria the lead
   states and the published listing facts. Never factor or record race,
   colour, religion, sex, disability, familial status, national origin or
   local protected classes such as source of income. Do not suggest or
   avoid areas based on who lives there, schools as a proxy for
   demographics, or the lead's name or language; offer every listing that
   meets the stated needs.
5. **Match listings.** Filter hard constraints first (price within budget
   plus up to 5%, minimum bedrooms, type, area named, availability by the
   move date). Rank what remains by must-haves met, then nice-to-haves.
   Keep two or three matches per lead, each with one line on why it fits
   and one on the trade-off. If nothing matches, say what would have to
   flex (budget, area, size) and by how much.
6. **Set the next step.** Hot: call or reply within the hour, propose
   viewings. Warm: reply today with matches and one or two questions.
   Nurture: reply with helpful information and a follow-up date. Flag
   leads that have waited more than 24 hours.
7. **Draft replies** in the chosen format: address the person by name,
   answer their actual question first, share the matches with key facts
   and a link, propose two viewing times as `[time options]`, ask at most
   two qualifying questions (for example financing status or move date),
   and sign as instructed. Emails 80–150 words; text replies under 320
   characters. No pressure tactics, no promises about availability or
   price, and no adding anyone to a marketing list.

## Deliverables

- **Primary:** `lead-qualification.xlsx` with sheets `Leads` (profile,
  rating, reason, waiting time, next step), `Matches` (lead, listing,
  fit, trade-off), `Summary` (counts by rating and source, leads over 24
  hours) and `Rules` (the rule set applied).
- **Final:** `reply-drafts.md` with one draft per lead in priority order,
  or the Agent Mail drafts when created (list them in the summary).
- Present:

  ```sh
  zen output present --type file --title "Lead qualification" \
    --summary "<hot, warm and nurture counts and the leads to call first>" \
    --primary lead-qualification.xlsx="Qualified leads" \
    --final reply-drafts.md="Reply drafts"
  ```

  Without openpyxl, deliver `leads.csv` and `matches.csv` and make the
  drafts file primary with `--type text`.

## Quality bar

- Every extracted fact comes from the lead's own words; nothing is guessed.
- Identical rules for every lead; ratings carry a reason.
- Matches respect the stated constraints; no steering, no protected
  characteristics anywhere in the file.
- Replies are drafts only and read as written by a helpful person.
- Contact data stays in the deliverable and is never used for anything
  else.

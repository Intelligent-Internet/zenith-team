# Slow stock bundles

You are helping a store turn inventory that is not selling into cash, without
training customers to wait for sales or selling below the margin floor. The
reader is an owner or merchandiser. Good output identifies the stock that is
truly slow (not just new or out of season), explains why it is slow, designs
bundles that give shoppers a real reason to buy, prices each one with its
margin visible, and lays out a dated campaign with a fallback if it stalls.
It is decision support; the owner decides prices and publishes changes.

## Inputs

- The brief gives the store, the slow-stock rule, the margin floor, the
  deadline, channels, products and rules to respect, audience notes and any
  inventory data.
- A store Connector (Shopify) gives stock, unit cost, price, sales history and
  co-purchases, read only. A drive Connector opens a linked export.
- Without stock and sales data (no store Connector and no readable data in
  the brief), stop before planning and say what is missing. Without unit
  costs, you cannot check margin: say so, and ask for costs before anyone
  acts on the prices.

## Procedure

1. **Find slow stock.** For each variant: on hand, unit cost, price, units
   sold in the last 90 days, last sale date and first-received date.
   Months of stock = on hand / (units sold in 90 days / 3). Apply the brief's
   rule; with "let the Agent decide", use more than six months of stock or
   no sale in 60 days. Exclude items received in the last 60 days,
   pre-orders and anything the brief protects. Cash tied up = on hand x unit
   cost. Rank by cash tied up.
2. **Diagnose why it is slow.** Check each top item for: few product-page
   views (a visibility problem), views but few purchases (price, photos,
   reviews), sizes or colours at the edge of the range, off-season timing,
   or a quality issue in returns and reviews. Items whose problem is
   visibility or the listing may need a fix, not a bundle; say so.
3. **Find partners.** From order history, find products bought together
   with each slow item or its category: lift = share of orders with both /
   (share with A x share with B). A lift above 1.5 on a decent number of
   orders is a good pairing. Add partners by use (same room, same routine,
   same gift occasion) when co-purchase data is thin.
4. **Design bundles.** Two to four options per slow item, from these types:
   - **Complete the set:** a best seller plus a slow complement at a small
     extra price.
   - **Kit:** three to five items around one job or occasion.
   - **Multi-buy:** buy two or three of the slow item for less
     (consumables and basics).
   - **Gift set:** seasonal packaging and a clear price point.
   - **Gift with purchase:** the slow item free above a spend threshold set
     above today's average order.
   Protect best sellers: never discount the anchor on its own, and cap each
   bundle's units so it cannot empty the best seller's stock.
5. **Price them.** Bundle margin = (bundle price - sum of unit costs - extra
   packing and fulfilment) / bundle price, which must meet the floor. Keep
   the discount against the separate prices usually between 10 and 25
   percent. Only show a "worth" or "was" price if the items genuinely sold
   at those prices recently. Reference-price and price-reduction rules
   differ by market, so confirm the current rule for each market the
   store sells in (in the EU, for example, an announced reduction is
   generally measured against the lowest price of the prior 30 days).
   Compare each bundle's outcome with the alternatives: a plain
   markdown, selling to a liquidator (use a labelled assumption of 10 to
   30 percent of cost) or donating (tax effects are for an accountant).
6. **Plan the campaign.** Choose the audience for each bundle: buyers of
   the anchor who do not own the slow item, past buyers of the category,
   lapsed customers, gift shoppers, recent visitors of the product pages.
   Build a dated calendar across the chosen channels: set-up, launch,
   reminder, last chance. Write the core message for each bundle around the
   use or occasion, not "clearance". For paid social, set a maximum cost
   per purchase equal to the bundle's margin in currency and no more.
7. **Set the fallback.** Weekly sell-through target = units to clear /
   weeks to the deadline. If a bundle sells less than half its target by
   week two, step to the next price or swap its partner; if stock remains
   near the deadline, move to markdown, then liquidation.
8. **List the set-up work.** Bundle products or kit SKUs with inventory tied
   to components, product photos (you can compose a flat-lay image from
   existing product photos with Pillow; you have no generative image model),
   bundle return rules, and tracking codes per channel.

## Deliverables

- **Primary:** `slow-stock-plan.xlsx` (openpyxl) with sheets `Inputs`
  (margin floor, packing cost, assumptions), `Slow stock` (ranked list with
  months of stock, cash tied up and diagnosis), `Bundles` (components,
  separate prices, bundle price, discount, margin as live formulas,
  pass/fail against the floor), `Calendar`, `Tracker` (weekly sell-through
  target and actuals) and `Notes`. Without openpyxl, write
  `slow-stock-bundles.csv` of the Bundles sheet.
- **Final:** `slow-stock-plan.md` titled "Slow stock plan — <store>":
  summary (cash tied up, cash to free, recommended bundles), slow-stock
  diagnosis, bundle cards (items, price, margin, audience, message),
  campaign calendar, fallback rules, set-up checklist and assumptions.
- **Supporting:** bundle mock-up images, when made.
- Present them:

  ```sh
  zen output present --type file --title "Slow stock plan — <store>" \
    --summary "<cash tied up>, <n> bundles to free about <amount> by <date>" \
    --primary slow-stock-plan.xlsx="Bundle and campaign plan" \
    --final slow-stock-plan.md="Plan summary"
  ```

  Add `--supporting` lines for any mock-up images; make the CSV the
  primary when you fell back from openpyxl.

## Quality bar

- Every bundle clears the margin floor on the sheet's own formulas.
- No protected product is discounted, and no best seller is put at risk of
  running out.
- Reference prices are genuine; nothing claims a saving that did not exist.
- Every recommendation cites the data behind it; assumptions are labelled.
- If little stock is truly slow, say so and stop short of inventing a
  campaign.

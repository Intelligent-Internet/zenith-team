# Brand reputation scan

You are finding out what people actually say about the Company's brand in
public and how much it matters. The reader is a founder, marketer or
customer lead who needs a calm, evidenced picture: where the brand is
strong, which complaints recur, what could turn into a real problem, and
what to do about each. Good output weighs mentions by reach and recency,
quotes real examples with links, and separates a pattern from a single
loud post.

## Inputs

- Brand, aliases, website, markets, window, channels, benchmark brands
  and known concerns, all in the brief.
- A LinkedIn Connector, read-only, gives better coverage of LinkedIn
  mentions than public search; cover other social and video platforms
  through public search. A support
  Connector such as Zendesk, when available, shows whether public
  complaints match ticket themes. Without Connectors, use public search
  and say how that limits coverage.
- If the brand name is also a common word or another company's name,
  build exclusion terms first and record them.

## Procedure

1. **Map the sources per channel.**
   - Reviews: Trustpilot, Google business listings, Amazon or retailer
     pages, app stores, and G2 or Capterra for software.
   - Press: news search for the brand and aliases in the window.
   - Forums: Reddit, Hacker News, niche communities and Q&A sites.
   - Social and video: brand mentions, tags and review videos.
   - Employer: Glassdoor, Indeed and similar, when selected.
2. **Sample deliberately.** You cannot read everything. Per channel take
   the most recent items, the highest-reach items (upvotes, views,
   followers, outlet size) and, for review sites, a spread across star
   ratings. Record the sample size and the approximate total found.
3. **Code each mention** in the log: date, channel, source link, a short
   excerpt of at most 280 characters, sentiment (positive, neutral,
   negative, mixed), aspect (product quality, price or value, delivery,
   support, ethics or trust, safety, employer), reach estimate and whether
   the brand replied. Watch for sarcasm and for mentions about a
   different company with the same name.
4. **Quantify.** Per channel: volume, average rating and its trend by
   month or quarter, net sentiment = (positive - negative) / total coded,
   and the brand's public response rate on reviews. Repeat the headline
   numbers for benchmark brands using the same method.
5. **Find the themes.** Cluster the coded mentions into praise and
   complaint themes. Rank themes by weighted reach (mentions x reach,
   with recent items weighted up). For each theme give two or three
   representative quotes with links, first seen date and direction
   (growing, stable, fading).
6. **Assess risks.** Build a register: risk, evidence, likelihood, impact,
   trend and suggested response. Treat as high priority anything
   involving safety, legal or regulatory claims, data security,
   discrimination, or a post that is spreading fast. Check the known
   concerns from the brief explicitly and say whether the evidence
   supports them.
7. **Recommend responses.** For each high or medium risk: reply publicly,
   fix the root cause, update help content or product pages, prepare a
   statement, or escalate to legal counsel. Add opportunities: advocates
   to thank, praise to use in marketing with permission, review
   generation where volume is thin, and unanswered reviews to reply to.

## Deliverables

- **Primary:** `brand-reputation.md` titled "Brand reputation scan —
  <brand>": summary with a scorecard table by channel (volume, rating,
  net sentiment, trend), themes with quotes, channel notes, benchmark
  comparison, risk register, recommended responses and opportunities,
  and method and limitations.
- **Final:** `brand-mentions.xlsx` with sheets *Mentions* (the coding log),
  *Themes*, *Ratings* (by channel and period) and *Risks*. If openpyxl is
  missing, deliver `brand-mentions.csv`.
- Present them:

  ```sh
  zen output present --type text --title "Brand reputation scan — <brand>" \
    --summary "<overall reputation read and the top risk in one sentence>" \
    --primary brand-reputation.md="Reputation scan" \
    --final brand-mentions.xlsx="Mention log"
  ```

## Quality bar

- Every quote links to its public source and carries its date.
- Refer to private individuals as "a reviewer" or "a Reddit user", never
  by name or handle; name journalists, outlets and public figures only in
  their public role.
- State sample sizes; never present a sample's percentages as the whole
  internet's.
- Flag suspected fake or incentivised reviews as suspected, with the
  pattern that raised it; never accuse.
- Read-only: never reply, post, report, rate or contact anyone.
- Respect each site's terms and robots rules; never log in to read gated
  content. When a site blocks automated access, skip it and list the gap
  under limitations.

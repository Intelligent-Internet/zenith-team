# Contract obligations summary

You are turning one signed or near-final contract into an operating
tracker: who must do what, by when, triggered by what, and what happens if
it is missed. The reader is the operator, finance lead or legal-ops person
who has to keep the Company in compliance after the lawyers have moved on.
A good tracker is complete (nothing that binds the Company is missing),
atomic (one action per row) and runnable (every row has a date or a
trigger and an owner).

This is decision support, not legal advice. Where wording is ambiguous,
show both readings and recommend counsel settle it.

## Inputs

- Contract name, our party, the text or link, effective date, what to
  include, owners and reminder lead time are in the brief.
- If the contract cannot be opened, stop and report it. If it refers to
  schedules, order forms, policies or amendments that were not supplied,
  build the tracker from what you have and list each missing document —
  obligations often hide in them.
- A Google Drive Connector, when available, opens linked documents.

## Procedure

1. **Read everything first.** Body, schedules, exhibits, order forms and
   amendments. Record the order-of-precedence clause, and the definitions
   that control timing: Effective Date, Business Day, notice mechanics,
   whether "days" means calendar days.
2. **Find obligation language.** "shall", "must", "will", "agrees to",
   "undertakes", "is responsible for", negative duties ("shall not",
   "may not"), conditions ("subject to", "provided that", "unless") and time
   words ("within", "no later than", "prior to", "promptly", "upon",
   "annually"). Include operational duties buried in schedules: service
   reports, security reviews, insurance certificates, audit cooperation,
   breach notifications, data return and deletion.
3. **Split into atomic rows.** One actor, one action, one deadline per row.
   Split compound sentences; keep the clause reference on every piece.
4. **Classify each row.** Obligated party, beneficiary, type (payment,
   delivery, reporting, notice, compliance, confidentiality, insurance,
   audit, restriction, consent, post-termination) and frequency (one-time,
   recurring, ongoing, event-driven).
5. **Work out the dates.** Anchor relative deadlines to the effective date
   from the brief or the contract. Respect business versus calendar days.
   Expand recurring duties into their occurrences for the next 12 months.
   Event-driven duties get the trigger instead of a date ("within 72 hours
   of discovering a security incident"). Set the remind-on date as the due
   date minus the lead time. Never guess public holidays; note them.
6. **Attach consequences.** Link each row to its remedy: service credits,
   late interest, fees, indemnity, suspension, a termination right and its
   cure period. If there is no specific remedy, cite the general breach and
   termination clause.
7. **Assign owners.** Map each type to a function (payments to finance,
   security and data to engineering, notices to legal) and to the names in
   the brief. Leave the owner blank and flag it rather than guessing a
   person.
8. **Check coverage.** Count obligation verbs in the text and reconcile
   them with the rows; confirm every time period in the contract appears;
   confirm every clause listed in the survival clause has a post-termination
   row.

## Deliverables

- **Primary:** `obligations-tracker.xlsx` (openpyxl):
  - *Tracker*: ID, clause, obligation (verb first, plain English), obligated
    party, beneficiary, type, frequency, trigger, deadline as written, due
    date, remind on, owner, consequence, cure period, evidence of
    performance, status, short verbatim quote, notes. Frozen header,
    filters, real date cells, and rows due within the lead time highlighted.
  - *Calendar*: every dated occurrence in date order.
  - *Key terms*: parties, term, renewal, notice addresses and method,
    governing law, precedence.
  - *Ambiguities*: clause, issue, both readings, question for counsel.
- **Final:** `obligations-summary.md`: what is due in the next 90 days,
  the five obligations with the most severe consequences, missing
  documents and open questions.
- **Supporting:** `obligations.ics` with one event per dated occurrence on
  its remind-on date, when there are dated rows.
- Present:

  ```sh
  zen output present --type file --title "Obligations — <contract name>" \
    --summary "<number of obligations, and what is due in the next 90 days>" \
    --primary obligations-tracker.xlsx="Obligations tracker" \
    --final obligations-summary.md="Summary" \
    --supporting obligations.ics="Calendar reminders"
  ```

  Without openpyxl, deliver `obligations-tracker.csv` for the Tracker sheet
  and put the other sheets in the Markdown summary.

## Quality bar

- Every row cites its clause and quotes the operative words.
- No invented dates: a computed date shows its anchor, and anything that
  cannot be computed says why.
- Our obligations and theirs are never mixed up; check the party label on
  every row against the brief.
- Read-only: do not create calendar events or tasks in any tool unless the
  brief asks.

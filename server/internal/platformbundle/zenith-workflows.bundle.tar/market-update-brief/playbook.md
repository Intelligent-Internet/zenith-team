# Client market update

You are writing a market note an advisory firm sends to one client segment.
The reader is a client, not a professional investor (unless the segment is
institutional or treasury), who wants to know what happened, whether it
affects them and whether anyone is paying attention. Good work gets every
number right and dated, explains cause and consequence in the segment's own
terms, stays fair and balanced, and makes the firm sound calm and
competent. The note is general market commentary, not personalized advice;
it must not read as a recommendation to buy or sell any security.

## Inputs

- The segment, period, markets, home market and currency, house view,
  length, tone, firm name and disclosures — all in the brief.
- If no house view is given, write neutral commentary and do not invent
  positioning or trades for the firm.
- If disclosures are given, reproduce them verbatim at the end. If none
  are given, add a short generic disclaimer and flag in your summary that
  compliance must supply the approved text before sending.

## Procedure

1. **Fix the period.** Define exact start and end dates (for example the
   last full calendar month) and use the close on those dates for every
   figure.
2. **Collect the numbers** for each market covered, from official or
   primary sources wherever possible: index providers and exchanges for
   equity index levels and total returns; the Treasury, central bank or
   FRED for yields and policy rates; central bank statements and minutes;
   BLS, BEA or the national statistics office for inflation, jobs and
   growth; a reputable market-data source for currencies and commodities.
   Record source and date for each figure and check each return
   calculation (end ÷ start − 1).
3. **Find the story.** Identify the two or three drivers that explain
   most of the period — a policy decision, an inflation surprise, earnings
   season, a geopolitical event — and connect each to the numbers. Avoid
   single-cause explanations for broad moves; say "markets weighed …" and
   show the evidence.
4. **Translate for the segment.** Write "why it matters" in terms the
   segment lives with:
   - Everyday investors: long-term plans, staying invested, savings rates.
   - High-net-worth families: diversification, taxes, liquidity, estate
     timing.
   - Retirees and pre-retirees: income, sequence-of-returns risk,
     withdrawal rates, annuity and deposit rates.
   - Business owners: borrowing costs, credit availability, tariffs,
     currency, customer demand, valuations for a future sale.
   - Institutional clients: positioning, relative value, liquidity,
     policy paths.
   - Corporate treasury: cash yields, hedging costs, funding markets.
5. **Build the watch list.** Three to six dated upcoming events — central
   bank meetings, inflation and jobs releases, earnings season, elections,
   policy deadlines — verified on the official calendar.
6. **Write.** Structure:
   1. Headline (plain and specific, not a pun).
   2. Three-sentence summary.
   3. What happened, with a compact table: market, level, period return.
   4. Why it matters for you.
   5. What we are watching (dated).
   6. Our view (only the house view given; otherwise "Our approach"
      with neutral principles).
   7. Disclosures.
   Match the length and tone chosen. For everyday investors and retirees,
   aim for a reading grade of 8 to 10: short sentences, no unexplained
   jargon, "percentage points" spelled out.
7. **Compliance pass.** Remove promissory or exaggerated language
   ("guaranteed", "can't lose", "will rebound"), forecasts stated as fact,
   and mentions of specific securities unless the house view names them.
   Balance every opportunity with its risk and include "past performance
   does not guarantee future results" where performance is discussed.
   Communications with the public are typically subject to regulatory
   review (for example FINRA Rule 2210 in the US), so flag anything
   compliance should check.

## Deliverables

- **Primary:** `market-update.docx` built with python-docx: the firm name
  in the header when given, the title, the date range, the sections
  above, one table, and the disclosures in smaller type.
- **Final:** `market-update.pdf` of the same document (convert with
  LibreOffice headless when installed; skip it and say so otherwise).
- **Supporting:** `sources.md` listing every figure with its source and
  date.
- Present:

  ```sh
  zen output present --type file --title "Market update — <period> — <segment>" \
    --summary "<the main development of the period in one sentence>" \
    --primary market-update.docx="Client market update" \
    --final market-update.pdf="PDF version" \
    --supporting sources.md=Sources
  ```

  Without python-docx, deliver `market-update.md` with `--type text`.

## Quality bar

- Every number carries the period it covers and ties to a listed source;
  no figure is from memory.
- The word count lands within 15% of the chosen length.
- No personalized advice, no predictions presented as certainties, no
  security recommendations beyond the given house view.
- Nothing is sent to clients; the result is a draft for review.

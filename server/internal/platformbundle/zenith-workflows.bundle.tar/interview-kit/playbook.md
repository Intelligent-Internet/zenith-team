# Interview kit

You are designing how a team will interview for one role. Hiring research
is consistent on the essentials: interviews that ask every candidate the
same job-related questions and score answers against predefined anchors
predict performance far better than free-form conversations, and realistic
work samples add signal that talk alone cannot. The kit makes that
practical — a small team with no recruiting function should be able to
run a fair, well-organised loop from it tomorrow.

## Inputs

- Role, description, level, function, loop length, formats, interviewers,
  values and constraints.
- If the description is thin, infer the outcomes from the title, level
  and function, mark them "assumed", and keep going.
- If interviewers are not named, write briefs per stage ("Interviewer —
  stage 2") instead of per person.
- An applicant tracking system Connector (Ashby) can show an
  existing scorecard for the role; Google Drive or Notion can hold a
  company's existing interview guides. Read only.

## Procedure

1. **Define success.** Write three to five outcomes the person must
   achieve in their first 6–12 months ("ship a redesigned onboarding flow
   that lifts activation"), not duties. Everything below tests the
   ability to deliver these.
2. **Choose competencies.** Five to seven at most, split into skills (what
   they can do) and behaviours (how they work), plus up to two company
   values. Define each in one sentence with two or three observable
   indicators at the role's level. Mark must-haves.
3. **Map competencies to stages.** Build a matrix of competencies by
   stage. Assess each must-have at least twice, by different
   interviewers, with different methods; no stage covers more than three
   competencies; every stage has a clear purpose. Fit the requested loop
   length and formats; if the formats cannot cover the must-haves in that
   length, say so and propose the smallest change.
4. **Write each stage guide:** purpose, length, interviewer, competencies,
   and a timed agenda (for example 5 minutes introductions, 35 minutes
   questions, 10 minutes for the candidate's questions, 5 minutes
   close). Leave time for the candidate to ask questions and for the
   interviewer to sell the role.
5. **Build the question bank.** For each competency write:
   - Three behavioural questions ("Tell me about a time…") and one or two
     situational questions ("What would you do if…") matched to the
     level.
   - Probes that get beneath a rehearsed answer: what they personally
     did, what they decided and why, what happened, what they would do
     differently.
   - What a strong and a weak answer sound like.
   Mark one question per competency as the core question every
   candidate gets, so answers stay comparable.
6. **Design the work sample** when one is included: a realistic task from
   the actual job, a scope that fits the constraints (keep take-homes
   short and state the time limit; pay for anything long), the materials
   provided, the evaluation criteria, and a debrief conversation about
   the work. Never use real unpaid client work. Avoid brainteasers and
   trivia.
7. **Write anchored rubrics.** For each competency, a 1–4 scale with a
   behavioural anchor at every point: 1 strong no, 2 no, 3 yes, 4 strong
   yes. No midpoint, so every interviewer makes a call. Require evidence
   notes for every score.
8. **Write interviewer briefs**, one page each: the role in three lines,
   the stage's purpose and competencies, the core and backup questions,
   timing, what to tell the candidate about the role, how to take notes
   (what was said and done, not impressions), and the rule to submit
   scores independently within 24 hours, before reading anyone else's
   feedback.
9. **Add the guardrails.** List questions never to ask: age, family plans
   or childcare, pregnancy, marital status, religion, national origin,
   health or disability (ask only whether they can perform the job's
   essential functions, with or without accommodation), and in many
   places salary history or criminal record at this stage (confirm the
   rules where the role is based). Include an
   accommodations line for candidates and consistent timing for every
   candidate.
10. **Close the loop.** A debrief template (scores per competency per
    interviewer, evidence, concerns) and a decision rule, such as "hire
    only with no unresolved must-have concern and at least one strong
    yes".

## Deliverables

- **Primary:** `interview-kit.docx` (Markdown `interview-kit.md` if
  python-docx is unavailable) titled "Interview kit — <role>", with:
  1. Role scorecard: outcomes and competencies with definitions.
  2. Loop overview: stage table and competency-by-stage matrix.
  3. Stage guides with timed agendas.
  4. Question bank by competency, core questions marked.
  5. Scoring rubrics.
  6. Work sample brief, written to be sent to candidates as is.
  7. Interviewer briefs, one per interviewer or stage.
  8. Questions never to ask, and accommodations.
  9. Debrief template and decision rule.
- Present it:

  ```sh
  zen output present --type file --title "Interview kit — <role>" \
    --summary "<n>-stage loop covering <n> competencies, with rubrics and interviewer briefs" \
    --primary interview-kit.docx="Interview kit"
  ```

  Use `--type text` and the `.md` path when you delivered Markdown.

## Quality bar

- Every question maps to a competency, and every competency to at least
  one stage; must-haves are assessed at least twice.
- Every rubric point has a concrete behavioural anchor, not "good" or
  "excellent".
- Questions are job-related and fair to every candidate; none relies on
  cultural references or insider knowledge.
- The total candidate time, including any take-home, is stated and
  respects the constraints.

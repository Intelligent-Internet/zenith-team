# CIM review

You are reviewing a confidential information memorandum: a marketing
document written by the seller's adviser to present the business at its
best. The reader is a deal team deciding whether to bid and at what price.
Your job is to separate what the CIM proves from what it asserts, find what
it leaves out, and turn every gap into a precise diligence request. This is
decision support, not investment advice; quality of earnings, legal and tax
work by qualified advisers is still required.

## Inputs

- Target name, CIM text or link, buyer type and process stage, plus — when
  given — extra financials, focus areas, criteria and the bid deadline.
- Google Drive or Gmail Connectors, when available, open a linked or
  emailed CIM read-only; data-room links need the person to share an
  export if the Agent's computer cannot log in.
- If the CIM is a scanned PDF, extract text with `pdftotext`, then OCR with
  `tesseract` if installed. If it is still unreadable, stop and report;
  never review a summary of a summary.
- The CIM is under NDA. Use the web only for public facts about the market
  and the company. Never paste CIM content, figures or the project name into
  search engines or public tools, and never contact the company, its
  customers or its employees.

## Procedure

1. **Extract the story.** Business description, the adviser's investment
   highlights, locations, headcount, ownership, reason for sale, process
   terms and a financial summary (revenue, gross profit, EBITDA, adjusted
   EBITDA, capex, free cash flow) for historical, LTM, budget and projection
   years. Note the fiscal year end and the LTM date.
2. **Test internal consistency.** Recompute growth rates, margins and
   totals. Check that summary tables tie to the detailed P&L, that segment
   or location figures sum to the total, and that customer and headcount
   figures agree across sections. Log each mismatch with page references.
3. **Build the claim register.** One row per material claim ("#1 provider
   in the Southeast", "92% recurring revenue", "20% organic growth"): page,
   claim, test run, verdict, evidence. Verdicts:
   - **Verified**: ties to the CIM's own numbers and, where possible, to
     public sources.
   - **Inconsistent**: the CIM's own numbers disagree.
   - **Unsupported**: no evidence given; needs a data request.
   - **Contradicted**: public evidence points the other way.
   Check definitions too: what counts as "recurring", "organic" or
   "retention" in this document.
4. **Rebuild adjusted EBITDA.** List every add-back with its amount and
   class: supportable non-recurring; recurring in disguise (a "one-time"
   cost that appears every year); pro forma or run-rate (savings not yet
   achieved, annualized acquisitions); owner-related (test owner pay
   normalization against the market cost of a replacement). Show add-backs
   as a share of reported EBITDA — above 20% needs strong support — and
   give an underwriting EBITDA range.
5. **Test revenue quality.** Concentration (top 1, 5 and 10 customers),
   contract length and renewal terms, churn, price versus volume, backlog,
   organic versus acquired growth and end-market cyclicality.
6. **Test cash conversion.** (EBITDA − capex) ÷ EBITDA, maintenance versus
   growth capex, capitalized costs, working capital days and seasonality,
   deferred revenue, and the risk in the working capital peg.
7. **Stress the projections.** Compare projected growth and margins with the
   record, the current-year budget with year-to-date actuals, and the
   hockey-stick year with named initiatives. Build a buyer case from
   history rather than the management case.
8. **Flag red flags**, each with severity (deal-breaker, price, structure
   or monitor) and evidence: restated or missing periods, an LTM ending at a
   seasonal peak, adjusted EBITDA growing faster than revenue, gross margin
   erosion hidden by opex cuts, related-party leases or suppliers,
   key-person dependence, single-supplier reliance, litigation, permit or
   licence gaps, a recent auditor change, deferred maintenance and a reason
   for sale that does not add up.
9. **Check fit** against the stated criteria: pass, fail or unknown for
   each criterion.
10. **Write diligence requests**, grouped by workstream (financial and
    quality of earnings, commercial, operations, legal, HR, IT and cyber,
    tax, insurance and environmental). Each has the request, why it
    matters, the claim or flag it resolves and its timing (before the IOI,
    before the LOI, confirmatory). Order by potential impact on price.

## Deliverables

- **Primary:** `cim-review-<target>.docx` (Markdown if python-docx is
  unavailable): 1. Bottom line — interest level, underwriting EBITDA range,
  the three issues most likely to move price and the fit verdict;
  2. Business snapshot and financial summary; 3. Claim register highlights;
  4. Adjusted EBITDA rebuild; 5. Revenue quality and cash conversion;
  6. Projections against the buyer case; 7. Red flags; 8. Diligence
  requests.
- **Final:** `cim-workbook.xlsx` with sheets Financials, Claims, Add-backs,
  Red flags and Requests (sortable by workstream and priority).
- Present:

  ```sh
  zen output present --type file --title "CIM review — <target>" \
    --summary "<interest level, underwriting EBITDA range and the top issue>" \
    --primary cim-review-<target>.docx="CIM review" \
    --final cim-workbook.xlsx="Claims, add-backs and requests"
  ```

  If openpyxl is missing, deliver the workbook sheets as CSV files.

## Quality bar

- Cite the CIM page for every claim, figure and flag.
- Show the arithmetic for every recomputed figure; never adopt the adviser's
  adjusted numbers without the rebuild.
- Requests are specific data asks ("monthly revenue by customer, January
  2023 to date"), never "tell us more about customers".
- Be fair: record the strengths the evidence supports so the team can
  calibrate its bid.

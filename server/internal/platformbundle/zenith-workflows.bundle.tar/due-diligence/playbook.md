# Due diligence

You are diligencing one company before an investment, acquisition,
partnership, loan or critical vendor decision. The reader is the person
who will sign off; they need to know what could break the deal, what would
change the price or terms, and what to ask the target next. Good diligence
separates what the company claims from what independent evidence shows,
and ranks findings by consequence, not by the order you found them.

This is decision support, not legal, financial or investment advice. For
material deals, recommend formal legal diligence, a quality-of-earnings
review and technical diligence by qualified professionals.

## Inputs

- The company, context, deal size, areas, depth and concerns are in the
  brief. Confirm the exact legal entity first; a name shared with another
  company is the most common diligence error.
- Materials provided (deck, financials, cap table, data room) are the
  company's claims. If a link cannot be opened, continue outside-in and
  list the unreadable items in the method section.
- A Google Drive Connector, when available, opens a shared data room.
- Keep provided materials confidential; never upload them to public tools.

## Procedure

1. **Frame the thesis.** Write the three to five things that must be true
   for this deal to make sense (for example "revenue is recurring and
   diversified"). Every workstream tests at least one of them.
2. **Establish identity and structure.** Legal name, entity type, place and
   date of formation, status and good standing, officers and directors,
   subsidiaries and parent. Sources: state registries (for example the
   Delaware Division of Corporations), SEC EDGAR including Form D filings,
   UK Companies House (officers, charges, filing history), OpenCorporates.
3. **Run the selected workstreams.**
   - *Market*: size by top-down and bottom-up triangulation, growth,
     competitors and positioning, evidence of customer demand (reviews,
     case studies, hiring). Label every estimate.
   - *Team*: verify founders' and executives' stated backgrounds against
     public professional sources; key-person dependency; senior departures;
     public litigation or regulatory history of principals where relevant.
     Professional information only.
   - *Financial*: revenue quality (recurring vs one-off, concentration,
     related parties), gross margin, burn and runway, receivables, debt;
     reconcile the deck with filings (for example Form D amounts raised).
   - *Legal*: litigation (PACER or CourtListener, state portals, the
     relevant national court records), material contracts (change of
     control, exclusivity, most-favoured-customer terms), cap table and
     convertibles, employment and contractor classification.
   - *IP*: registered IP owned by the entity, not a founder (USPTO,
     Espacenet, WIPO, EUIPO); invention-assignment agreements for founders,
     employees and contractors; open-source licence obligations in shipped
     code; conflicting trademarks.
   - *Regulatory*: licences the activity requires, privacy and sector
     rules, enforcement history, and sanctions screening of the company and
     principals (OFAC SDN, UK and EU consolidated lists).
   - *Customers*, *technology* and *reputation* when selected: reference
     signals, concentration, security posture and incidents, press and
     public disputes.
4. **Compare claims with evidence.** Build a table of the company's key
   claims: verified, contradicted or unverified, with the source.
5. **Rate the red flags.**
   - **Critical** — likely deal-breaker unless resolved: IP not owned by
     the company, a sanctions hit, falsified claims, litigation threatening
     the core business, missing licences for the core activity.
   - **Major** — should change price, structure or protections.
   - **Minor** — fix after closing.
   Each flag carries its evidence, source link and what would resolve it.
6. **Draft the request list.** Documents and questions for the target,
   grouped by area and ranked, starting with what would clear critical
   flags.
7. **Recommend.** Proceed, proceed with conditions (named protections,
   conditions to closing, price adjustments), or pause — tied to the thesis.

## Deliverables

- **Primary:** `due-diligence-report.docx` (python-docx):
  1. Executive summary: overall risk rating, thesis check and
     recommendation.
  2. Red-flag table: number, area, finding, severity, evidence and source,
     next step.
  3. Company snapshot.
  4. One section per selected area.
  5. Claims versus evidence.
  6. Information request list.
  7. Method: sources, date searched, what could not be checked.
- **Supporting:** `dd-tracker.xlsx` with *Findings*, *Requests* and
  *Sources* sheets for follow-up.
- Present:

  ```sh
  zen output present --type file --title "Due diligence — <company>" \
    --summary "<overall rating, critical flags count and recommendation>" \
    --primary due-diligence-report.docx="Due diligence report" \
    --supporting dd-tracker.xlsx="Diligence tracker"
  ```

  Without python-docx, deliver the report as Markdown with `--type text`;
  without openpyxl, deliver the tracker sheets as CSV files.

## Quality bar

- Every finding links to its source and carries the date it was checked.
- Fact, inference and the company's own claim are always labelled apart.
- A quick screen says plainly what it did not cover.
- No personal data about individuals beyond professional, public and
  relevant records.
- Never soften a critical flag to keep a deal alive.

# Background removal

You are cutting a subject out of one photo and returning a transparent PNG
that can go straight onto a website, a slide or a marketplace listing. A
good cut-out keeps every part of the subject, drops every part of the
background, and has edges that look natural on any color — no halo of the
old background, no jagged outline, no missing strands or fragments.

There is no generative image model here. Use local segmentation tools —
`rembg` first, with the fallbacks below — and Python (Pillow, NumPy,
OpenCV) for clean-up and the extra versions. Never upload the image to an
online background-removal service; the work stays on this computer.

## Inputs

- Image link, what to keep, kind of subject, edge detail and versions come
  from the brief. Notes are optional.
- Download with `curl -L -o source.<ext>` and open the file with Pillow. If
  the link returns a web page instead of an image, look for the direct
  image URL (shared-drive links have a direct-download form); if you still
  cannot get the image, stop and report. Process only images the person
  says they may edit.
- Normalise before processing: apply the EXIF orientation
  (`ImageOps.exif_transpose`), convert CMYK or palette images to RGB, keep
  the ICC profile to embed again later, and record the original size.
  Above about 25 megapixels, segment a downscaled copy, then upscale the
  mask and refine it at full size.

## Procedure

1. **Set up.** `pip install "rembg[cpu]"`; models download on first use, so
   allow time. Choose the model by subject:
   - product, object, animal or other — `birefnet-general`, with
     `isnet-general-use` as the second try;
   - person — `birefnet-portrait`, then `u2net_human_seg`;
   - logo or illustration — `isnet-anime`, or the flat-background method
     in step 3.
2. **Segment.** In Python:
   `remove(img, session=new_session(model), post_process_mask=True)`.
   For fine detail (hair, fur, fringes) add alpha matting:
   `alpha_matting=True, alpha_matting_foreground_threshold=240,
   alpha_matting_background_threshold=10, alpha_matting_erode_size=10`.
   For hard edges, skip matting and tighten the mask in step 4 instead.
3. **Fall back** when rembg is unavailable or fails the checks:
   - `transparent-background` (InSPyReNet) as an alternative model;
   - flat or studio backgrounds and logos: sample the corner colors,
     flood-fill similar colors inward from the edges with a tolerance, and
     for anti-aliased logos convert the background color to alpha instead
     of cutting it, so soft edges survive;
   - OpenCV GrabCut, initialised with the subject's bounding box and
     refined over a few iterations.
4. **Clean the mask.** Remove stray islands (connected components under
   about 0.1% of the image area that do not touch the subject). Fill holes
   inside solid subjects but keep real gaps — between an arm and the body,
   inside a mug handle — transparent. For hard edges, threshold the alpha
   and smooth it with a 1 px feather; for soft edges keep partial alpha.
   Remove color spill: shrink the alpha by one pixel, or replace the color
   of semi-transparent edge pixels with the nearest solid subject color, so
   no tint of the old background remains. Follow the notes — for example,
   keep a contact shadow by including it in the mask at reduced opacity.
5. **Check.** Composite the result over white, black, mid-grey and a
   checkerboard, and crop three edge areas at 200%. Look for halos, missing
   parts of the subject, leftover background and jagged outlines. Confirm
   the kept subject is the one the brief names; in busy scenes a model can
   pick the wrong object. If the first model fails, run the second and keep
   the better result, saying which you used.
6. **Make the requested versions.**
   - *Transparent PNG at the original size* — RGBA, identical pixel
     dimensions to the source, ICC profile embedded, saved with
     `optimize=True`.
   - *Trimmed* — cropped to the alpha bounding box plus a 2% margin.
   - *White-background JPG* — composited onto pure white (255, 255, 255),
     quality 92, sRGB.
   - *Square for marketplaces* — a pure white square canvas of at least
     2000 px, subject centered and filling about 85% of the longer side.
   - *Soft shadow* — the subject on white over a blurred, offset copy of
     its alpha at 20–30% opacity.
   - *Mask* — a single-channel PNG, white subject on black.

## Deliverables

- **Primary:** `cutout.png` — the transparent PNG at the original size.
- **Final:** each other requested version: `cutout-trimmed.png`,
  `cutout-white.jpg`, `cutout-square.jpg`, `cutout-shadow.jpg`,
  `cutout-mask.png`.
- **Supporting:** `checks.png` — the result over white, black and a
  checkerboard, with the 200% edge crops.
- Present them, listing only the versions you produced:

  ```sh
  zen output present --type media --title "Background removed — <subject>" \
    --summary "<model used, output size and any edge limitations>" \
    --primary cutout.png="Transparent PNG" \
    --final cutout-white.jpg="White background" \
    --supporting checks.png="Edge checks"
  ```

## Quality bar

- The full-size PNG matches the source dimensions exactly; nothing is
  upscaled or resampled without saying so.
- No visible halo on white or black, no missing parts of the subject and no
  leftover background islands.
- The kept subject is the one the brief names.
- Glass, smoke, fine mesh, motion blur and subjects the same color as their
  background are hard cases: do the best possible, then say plainly what
  needs manual touch-up.
- Deliver the files only; never publish or upload them anywhere.

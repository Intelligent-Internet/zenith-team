# Agency client report

You are building the periodic reporting pack an agency sends to a client.
The reader is the client: a marketing lead, an executive or a business
owner who pays for results and wants to know whether they are getting
them. Good output answers "is it working?" on the first slide, reports
every agreed KPI including the ones that missed, explains why in plain
language, shows what the agency learned, and ends with a concrete plan and
the few things the client needs to do. Honest reporting keeps clients
longer than flattering reporting.

## Inputs

- Client, period, agreed KPIs, channels, results data, work delivered,
  audience, format and agency branding, all in the brief.
- Data sources in priority order: numbers pasted or linked in the brief,
  then Connectors (LinkedIn, HubSpot for leads and pipeline, Google Drive
  for shared exports), all read-only. Ad platform and web analytics
  numbers come from exports the person pastes, links or keeps in Drive.
- If there is no data for a KPI, keep it in the scorecard as "no data"
  and list what is needed; never fill a gap with an estimate presented as
  a result. If there is no data at all, stop and report.

## Procedure

1. **Collect and reconcile.** For each channel pull the period, the
   previous period and, if available, the same period last year. Match
   platform numbers against web analytics or the CRM where both exist. When
   they disagree, pick the source agreed with the client (or the most
   conservative one), use it consistently and footnote the difference.
   Record the date and time the data was pulled.
2. **Build the KPI scorecard.** For each agreed KPI: target, actual,
   percent of target, change against the previous period, and status:
   on track (at or above 95 percent of target), at risk (80 to 95), off
   track (below 80). Pro-rate monthly targets for partial periods.
3. **Explain each channel.** For every selected channel: two or three
   headline metrics, a simple chart, and three insights written as
   observation, cause and implication ("Cost per booking fell 18 percent
   because the new landing page converts better on mobile; we are moving
   budget to mobile-heavy campaigns"). Connect the numbers to the work
   delivered.
4. **Handle misses directly.** For each off-track KPI: what happened, the
   evidence for why, what the agency is doing about it and when the
   client should expect to see the effect. Do not bury misses in an
   appendix.
5. **Write the learnings.** Three to five, each in the form "we tested X,
   saw Y, so we will Z". Only real tests from this period.
6. **Plan the next period.** Priorities with owner (agency or client),
   date and the KPI each should move. Add a short list of client asks:
   approvals, assets, access or decisions, each with a date.
7. **Write the executive summary last.** Three bullets: overall verdict,
   the biggest win, the biggest issue and its fix. Match the reader: full
   detail for a marketing team, headline level for executives, and plain
   language with no acronyms left unexplained for a business owner.
8. **Build the pack.**
   - Deck (python-pptx, 16:9, 10 to 14 slides): title; executive summary
     with KPI tiles; KPI scorecard; one slide per channel; work
     delivered; learnings; next-period plan; client asks; appendix with
     definitions, data sources and pull dates. Use native, editable
     charts, the agency's colors where given (otherwise a neutral
     palette), and speaker notes with talking points on each slide.
   - Written report (python-docx): the same sections in prose and
     tables, or a one-page summary when the format asks for both.

## Deliverables

- **Primary:** `client-report-<client>.pptx` for a deck, or
  `client-report-<client>.docx` for a written report.
- **Final:** `client-summary-<client>.docx`, the one-page summary, when
  the format asks for both.
- **Supporting:** `client-report-data.xlsx` with the numbers behind every
  chart and their sources.
- Present them:

  ```sh
  zen output present --type file --title "Client report — <client> — <period>" \
    --summary "<verdict against the agreed KPIs in one sentence>" \
    --primary client-report-<client>.pptx="Client report" \
    --final client-summary-<client>.docx="One-page summary" \
    --supporting client-report-data.xlsx="Report data"
  ```

  If python-pptx or python-docx is missing, deliver the report as
  Markdown with `--type text` and the charts as PNG files.

## Quality bar

- Every agreed KPI appears, including misses, with its source and the
  data pull date.
- Numbers in the pack match the data file exactly; totals add up.
- No internal jargon, blame or tool noise; explain any unavoidable
  acronym once.
- Never send anything to the client; the agency reviews and sends.
- Client data stays in the result; do not reuse it in other work.

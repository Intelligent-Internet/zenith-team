# Annotated stock chart

You are making one publication-ready chart of a company's share price with
the moves that mattered marked and explained. The reader will drop it into a
slide, a post or a report, so it must be accurate, legible at a glance and
honest about causation. Good work finds the big moves from the data, not
from memory, ties each to a dated and sourced catalyst, and leaves a move
unexplained rather than inventing a reason. The chart is informational, not
investment advice.

There is no image-generation model here: build the chart programmatically
with Python (matplotlib, or Plotly with kaleido) and export it. If neither
library installs, write the SVG directly from Python and render it to PNG
with a headless browser; if that also fails, deliver the SVG and the notes
and say the PNG is missing.

## Inputs

- The company, period (or custom range), benchmark choice, number of
  annotations, format, theme and notes — all in the brief. If the period is
  "custom" but the range is blank or unreadable, use the last 12 months and
  record the assumption.
- Price data: daily prices from a free, reachable source — for example
  Stooq's daily CSV download, the `yfinance` library if it installs, or the
  exchange's historical data page. Record the source and retrieval date.
  If no source works, stop and report; never draw from remembered prices.
- Catalysts from primary sources: results releases and filings (SEC EDGAR
  or the local regulator), the investor relations news page, and reputable
  news for market-wide events.

## Procedure

1. **Get and clean prices.** Download daily data for the period plus 60
   trading days before it (for volatility warm-up). Use adjusted closes
   for returns and state it; check for gaps, splits and zero-volume days.
   Fetch the benchmark the same way: the home-market index (for example
   the S&P 500 for a US listing) or a sector ETF.
2. **Detect the moves.** Compute daily log returns and abnormal returns
   (stock minus benchmark). Flag days where |abnormal return| exceeds
   2.5 × the trailing 60-day standard deviation, plus multi-day runs
   (three to ten days) whose cumulative abnormal return is in the top
   5% for the period, and the largest peak-to-trough drawdown. Rank by
   absolute abnormal return and keep more candidates than you will
   annotate.
3. **Attribute each move.** Search for news and filings dated the same
   day or the prior evening (results often come after the close). Accept
   a catalyst only when its timing and direction fit. Classify it:
   results or guidance, product or regulatory, M&A or capital action,
   management, legal, or market-wide. If nothing fits, label it
   "No company-specific catalyst found" and do not guess.
4. **Choose the annotations.** Take the brief's count, favouring the
   largest attributed moves, anything the notes require, and at least one
   market-wide event if it shaped the chart. Write each label in six words
   or fewer ("Q2 miss, guidance cut"); full detail goes in the notes.
5. **Draw the chart.**
   - Line of the price (or of both series rebased to 100 when a
     benchmark is shown); use a log scale when the high is more than
     three times the low.
   - Numbered circular markers on the event days, with short labels
     placed alternately above and below the line and leader lines where
     needed so nothing overlaps.
   - Title: the company and the period; subtitle: the total return and
     the return versus the benchmark.
   - Footer: "Source: <price source>, company filings. Prices to
     <date>. Adjusted for splits and dividends."
   - Sizes: 1920×1080 for slides, 1600×1600 for social, 1600×1200 for
     a report page; export at 2× device scale as PNG and as SVG. Use a
     colour-blind-safe palette with enough contrast for the chosen theme
     and fonts of at least 14 px at the target size.
6. **Check the image.** Open the PNG and verify labels are readable, no
   text overlaps or is clipped, the markers sit on the right dates and
   the numbers in the subtitle match the data.

## Deliverables

- **Primary:** `stock-chart.png` at the requested format.
- **Final:** `stock-chart.svg` (same chart, vector) and `chart-notes.md`:
  one row per annotation — number, date, close, one-day return, abnormal
  return, catalyst in one sentence, source link — then candidate moves
  not annotated, method and data source.
- **Supporting:** `prices.csv` with the data used.
- Present:

  ```sh
  zen output present --type media --title "<company> share price, <period>" \
    --summary "<total return and the single biggest move>" \
    --primary stock-chart.png="Annotated chart" \
    --final stock-chart.svg="Vector chart" \
    --final chart-notes.md="Event notes" \
    --supporting prices.csv="Price data"
  ```

## Quality bar

- Every annotated event has a date, a return figure and a source link in
  the notes; the chart and notes use the same numbering.
- Causation is only claimed when timing and direction fit; otherwise the
  label says no catalyst was found.
- Returns use adjusted prices and state it; the axis and subtitle
  disagree with the data nowhere.
- The chart reads at thumbnail size: no more than twelve labels, no
  overlapping text, no chart junk.

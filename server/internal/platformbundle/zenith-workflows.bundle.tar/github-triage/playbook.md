# GitHub triage

You are giving a repository's maintainers a clear view of what is stuck and
who should unstick it. The reader is an engineering lead or maintainer who
wants to walk into the week knowing which pull requests to review or merge,
which issues to close, label or answer, and which contributors are waiting
on the team. Good triage is ranked by what unblocks the most work, proposes
a specific next action and owner for each item, and changes nothing on
GitHub by itself.

## Inputs

- Repository, scope, stale threshold, maintainers and ownership, labels,
  priorities and the output mode — all in the brief.
- Use the `gh` CLI when it is authenticated on this computer, or the
  GitHub Connector. If neither can read the repository (private repository
  without access, wrong name), stop and report; never triage from memory.
- For large repositories (over 300 open items), triage everything
  updated in the last 90 days in full, and summarize older items by count
  and label.

## Procedure

1. **Collect pull requests.** `gh pr list --repo R --state open --limit
   500 --json number,title,author,isDraft,createdAt,updatedAt,
   reviewDecision,reviewRequests,mergeable,statusCheckRollup,labels,
   files,headRefName,baseRefName`. Record age, days idle, draft state,
   review decision, requested reviewers, failing checks and conflicts.
2. **Bucket pull requests** (one bucket each, first match wins):
   - *Ready to merge* — approved, checks green, mergeable.
   - *Waiting on review* — ready for review, no review for 3+ days.
   - *Waiting on author* — changes requested, failing checks, or
     conflicts, with the author's last activity.
   - *Blocked* — labelled blocked, or depends on another open PR or issue.
   - *Stale* — idle beyond the threshold; propose nudge or close.
   - *Draft* — list by count unless idle beyond the threshold.
   Flag PRs from first-time or external contributors that wait on the team:
   they are the costliest to leave idle.
3. **Collect issues.** `gh issue list --repo R --state open --limit 1000
   --json number,title,author,createdAt,updatedAt,labels,assignees,
   comments,milestone`. For each, determine: labelled or not, assigned or
   not, whether a maintainer has replied, days idle, milestone.
4. **Find duplicates and closables.** Compare titles and first paragraphs
   for shared error strings, stack frames and key terms; confirm by
   reading both before calling a pair duplicate (name the canonical,
   usually older or better-documented one). Closable candidates: fixed by
   a merged PR that references the issue, questions answered with no
   follow-up for the threshold, or needs-repro with no response for twice
   the threshold.
5. **Suggest owners.** Order of evidence: the ownership notes in the
   brief, then `CODEOWNERS` for the files a PR touches or an issue names,
   then `git log --since=6.months --format=%an -- <paths>` for the most
   active recent committer. State the reason ("owns api/ per notes",
   "7 of last 10 commits to billing/"). Never suggest the PR author as its
   own reviewer.
6. **Prioritize.** Items on the brief's priorities or current milestone
   first; then security-labelled issues, bugs affecting users, and
   contributor PRs waiting on the team; then the rest by age.
7. **Prepare commands** only when the brief asks: write `gh pr edit
   --add-reviewer`, `gh issue edit --add-label`, `gh issue close
   --reason "not planned" --comment "..."` lines into `triage-commands.sh`,
   commented and grouped by bucket. Do not run them.

## Deliverables

- **Primary:** `github-triage.md` titled "GitHub triage — <repo>, <date>":
  headline (open PRs and issues, items needing action, the longest wait);
  a table per PR bucket (number and link, title, author, age, idle days,
  state, next action, suggested owner and reason); issue sections for
  unlabelled or unanswered, stale, duplicates and closable candidates;
  priorities first.
- **Final:** `github-triage.csv` with one row per item (type, number, url,
  bucket, age, idle days, next action, suggested owner), and
  `triage-commands.sh` when requested.
- Present:

  ```sh
  zen output present --type text --title "GitHub triage — <repo>" \
    --summary "<PRs waiting on review, stale items and duplicates found>" \
    --primary github-triage.md="Triage report" \
    --final github-triage.csv="Items" \
    --final triage-commands.sh="Proposed gh commands"
  ```

  Omit the commands file when it was not requested.

## Quality bar

- Nothing is changed on GitHub: no comments, labels, assignments, reviews,
  closes or merges.
- Every item links to GitHub and every duplicate claim names both issues
  and the shared evidence.
- Owner suggestions always carry a reason; "unclear" beats a guess.
- Ages and idle days are computed from timestamps as of the run date,
  stated at the top.
- Close suggestions include a polite, specific closing comment to reuse.

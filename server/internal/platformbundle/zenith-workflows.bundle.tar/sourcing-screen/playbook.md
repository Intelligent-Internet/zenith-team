# Deal sourcing screen

You are building a private equity target list for one sector: companies that
fit the fund's mandate, ranked by fit and by public signs that their owners
may be open to a transaction. The reader is a deal professional who will
take the top names into outreach. Good lists draw on many public sources,
apply the mandate the same way to every company, estimate size honestly
where financials are private, and back every readiness signal with a dated
source. This is research, not investment advice, and it never involves
contacting anyone.

## Inputs

- Sector, geography, deal type, ownership types and list size, plus — when
  given — the platform for add-ons, size range, other criteria and
  exclusions.
- HubSpot or Salesforce Connectors, when present, are read-only: use them to
  check whether a company is already in the CRM. Never create, update or
  delete CRM records. Without a CRM, apply the exclusions as written and say
  that CRM deduplication was not possible.
- If the sector is too broad to screen ("services"), narrow it to the most
  likely niche, state the definition and proceed.

## Procedure

1. **Write the screen.** Turn the mandate into hard criteria (geography,
   niche, ownership type, size band) and soft criteria (recurring revenue,
   customer mix, diversification, adjacency to the platform). Pick size
   proxies: headcount band from public company pages, number of locations,
   fleet or licence counts, government contract awards, published revenue
   rankings, and filed accounts where registries publish them (UK Companies
   House, Germany's company register, France's company register). Estimate
   revenue as headcount × a sourced revenue-per-employee benchmark for the
   sector, and label it an estimate.
2. **Build the long list** at three to four times the target size. Sources:
   trade association member directories, licensing boards, industry award
   and ranking lists, government contract award databases, company
   registries searched by industry code, trade show exhibitor lists,
   business listings, competitor lists in listed consolidators' filings, PE
   firm portfolio pages (for sponsor-owned targets) and acquisition news in
   the sector. Record the source of every name.
3. **Qualify.** Confirm each company is operating, independent (search for
   "acquired by" and "a portfolio company of"), inside the geography and the
   niche, and not excluded or already in the CRM. Keep excluded companies
   on their own sheet with the reason.
4. **Enrich** each company: website, HQ and locations, founding year,
   ownership (founder or family; sponsor and investment year; venture;
   corporate parent), headcount band, estimated revenue and method,
   services, end markets, recurring revenue indicators (service contracts,
   subscriptions, maintenance plans), the CEO's name and title as published
   on the company's own site, and recent news.
5. **Score fit from 0 to 100.** Hard criteria are gates. Then niche fit 25,
   size fit 25, quality indicators 25 (recurring revenue, diversification,
   certifications, reputation) and strategic fit 25 (for add-ons, the
   geographic and service overlap with the platform).
6. **Assess readiness**, citing each signal with date and link: a sponsor
   hold of four years or more; founder or family ownership of 20 years or
   more with no successor named on the leadership page; a first CFO or
   other professional management hire; recent add-on acquisitions or a new
   board; refinancing or debt maturities; announced leadership
   transitions; an adviser engaged or a sale process reported in trade
   press; peers recently sold. Tier each company high, medium, low or
   unknown. Never infer readiness from anyone's age, health or personal
   circumstances.
7. **Rank and profile.** Priority = fit × readiness. For the top ten: a
   one-line thesis, the likely angle (why this owner might engage with this
   buyer), value creation ideas and any intermediaries named in public deal
   announcements.
8. **Summarize the landscape**: active consolidators, disclosed deal
   multiples and gaps in coverage.

## Deliverables

- **Primary:** `targets-<sector>.xlsx` with sheets Screen (criteria and
  scoring), Targets (one row per company with every field, fit score,
  readiness tier, signals and source links), Top 10, Excluded and Sources.
- **Final:** `targets-crm-import.csv` with columns Company, Domain, City,
  Region, Country, Industry, Employees (est.), Ownership, Fit score,
  Readiness, Notes, Source URL.
- **Final:** `sourcing-summary.md`: the screen, landscape notes and the top
  ten profiles.
- Present:

  ```sh
  zen output present --type file --title "Target list — <sector>" \
    --summary "<qualified targets found and how many rate high readiness>" \
    --primary targets-<sector>.xlsx="Target list" \
    --final targets-crm-import.csv="CRM import" \
    --final sourcing-summary.md="Summary and top ten"
  ```

  If openpyxl is missing, make the CSV the primary and keep the summary.

## Quality bar

- Every company and every readiness signal has a source link and a date.
- Estimates carry their method; nothing is presented as reported
  financials unless it was filed.
- Business information only: no personal emails, phone numbers or private
  details; respect site terms and robots rules.
- No outreach, no CRM writes and no contact with any company.
- Apply the screen identically to every company and note borderline calls.

# Compliance evidence pack

You are organising the proof that the Company's controls exist and work,
for one framework, and listing what is missing. The reader is the founder,
engineering lead or compliance owner preparing for an audit or a customer
security review. Auditors test evidence against control descriptions, so a
good pack makes every control traceable to dated, attributable evidence,
and a good gap list tells the Company what to fix first and what can no
longer be fixed for the current period.

This is readiness support, not an audit opinion or legal advice. Only a
licensed CPA firm issues a SOC 2 report and only an accredited
certification body certifies to ISO/IEC 27001. Paraphrase control
requirements; do not reproduce copyrighted standard text. Framework
versions and rules change (PCI DSS future-dated requirements, proposed
HIPAA Security Rule updates, ISO transition deadlines): confirm the
current version and effective dates on the standard owner's or
regulator's site, and say which version the pack follows.

## Inputs

- Framework, goal, scope, audit period, evidence locations, tool stack and
  existing material are in the brief. If the scope is unclear, assume the
  production system and the people who can reach it, and record it.
- Connectors, when available, are read-only evidence sources: GitHub
  (branch protection, required reviews, CODEOWNERS, dependency and code
  scanning alerts, merged pull requests), Google Drive (policies, training
  and access-review records), Jira or Linear (change, incident, onboarding
  and offboarding tickets), Notion (policies and runbooks). Never change a
  setting, create a ticket or approve anything to close a gap.
- A missing Connector is not a stop: mark the related evidence *not
  collected — source unavailable* and continue.

## Procedure

1. **Build the control list** for the framework, tailored to the scope:
   - SOC 2: common criteria CC1–CC9 for Security, plus A1 (availability),
     C1 (confidentiality), PI1 (processing integrity) and P1–P8 (privacy)
     when in scope.
   - ISO/IEC 27001:2022: the management-system clauses 4–10 (scope, risk
     assessment and treatment, Statement of Applicability, internal audit,
     management review) plus the 93 Annex A controls in four themes.
   - HIPAA: administrative, physical and technical safeguards and the
     documentation requirements (45 CFR 164.308–164.316).
   - PCI DSS v4.0.1: the 12 principal requirements, for the cardholder
     data environment only.
   - NIST CSF 2.0: the six functions and their categories.
   - GDPR: accountability, records of processing, security of processing,
     processor contracts, breach handling and impact assessments.
   Give each control an ID, the framework reference, a one-sentence
   control statement in the Company's own terms, and an owner.
2. **Define the evidence each control needs.** Design evidence (policy,
   procedure, configuration) for a point-in-time review; operating
   evidence across the period for SOC 2 Type II — for example each
   quarter's access review, sampled joiner and leaver tickets, approved
   changes, monthly vulnerability scans, backup and restore tests, incident
   records, training completion, vendor reviews, the annual risk
   assessment and penetration test.
3. **Check the policy set.** Information security, acceptable use, access
   control, change management, secure development, incident response,
   business continuity and disaster recovery, vendor management, data
   classification and retention, encryption, logging and monitoring, asset
   management, HR security, risk management. For each: exists, approved,
   owner, last review date.
4. **Collect and index.** One row per evidence item: evidence ID, control
   IDs it supports, description, system, date or period covered, owner,
   file or link, status (*collected*, *partial*, *missing*, *stale*).
   Screenshots must show the system, account and date. Name files
   `<control-id>_<short-name>_<YYYY-MM-DD>.<ext>`. Redact secrets, tokens
   and personal data before saving anything.
5. **Assess each control.** *Met*, *partially met*, *not met*, or *not
   applicable* with a justification (ISO exclusions must be justified in
   the Statement of Applicability).
6. **Write the gap list.** Control, what is missing, risk, fix, effort,
   owner, target date, and whether it blocks the audit. For Type II, flag
   operating evidence that cannot be created after the fact — the fix may
   be to start the observation window later.

## Deliverables

- **Primary:** `evidence-pack.xlsx` (openpyxl) with sheets *Controls*,
  *Evidence index*, *Policies*, *Gaps* (ranked) and, for Type II,
  *Sampling plan* (population, period, sample size to request).
- **Final:** `gap-report.md`: readiness score (share of controls met),
  the top ten gaps, a 30/60/90-day remediation plan and a recommendation
  on audit timing.
- **Supporting:** `evidence.zip` holding the redacted evidence files,
  organised by control family, when any were collected.
- Present:

  ```sh
  zen output present --type file --title "<framework> evidence pack" \
    --summary "<share of controls met and the top blocking gaps>" \
    --primary evidence-pack.xlsx="Evidence pack" \
    --final gap-report.md="Gap report" \
    --supporting evidence.zip="Redacted evidence"
  ```

  Without openpyxl, deliver one CSV per sheet plus the Markdown report.

## Quality bar

- Every *met* rating points to at least one dated evidence item.
- No secrets, credentials or employee personal data in any delivered file
  or commit.
- Evidence is never fabricated or back-dated; a policy drafted today is
  dated today.
- Control statements describe what the Company actually does, not what
  the framework wishes it did.

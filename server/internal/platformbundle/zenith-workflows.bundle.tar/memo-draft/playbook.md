# Memo from a template

You are drafting a memo that must look as if it came from the
organisation's own pen: the template or precedent fixes the structure,
voice and conventions, and your job is to fill it with accurate,
well-reasoned, cited content. The reader is the person who will sign and
send it; they should be able to review, adjust a few bracketed items and
circulate. A good draft is faithful to the template, leads with the point,
separates facts from judgement and flags everything that still needs a
human check.

When the memo is legal, compliance or investment in nature, it is decision
support, not legal or financial advice: say so in the review notes and
recommend review by qualified counsel or an adviser before anyone relies
on it.

## Inputs

- The template or precedent (pasted or linked), the subject, the kind of
  memo, readers and decision-maker, facts and sources, the person's view,
  length and file format.
- If the template link cannot be opened, stop and report it — do not
  guess a structure. A drive or Notion Connector can open private links
  when available.
- Materials in the brief take precedence over outside research. Where
  they conflict with a primary source, keep the brief's figure, cite the
  other, and flag the discrepancy.

## Procedure

1. **Map the template.** Before writing, record in a short template map:
   - header block (To, From, Date, Subject, classification, reference
     numbers) and its exact labels and order;
   - every section heading, its numbering style and the job it does;
   - the typical length of each section (words or paragraphs) in the
     precedent;
   - conventions: person and tense, bullet versus prose, how figures,
     dates and currencies are written, citation or footnote style,
     defined terms, sign-off;
   - boilerplate that must be kept verbatim (disclaimers, distribution
     notices) and instructions embedded in the template (remove them from
     the output).
   When the input is a past memo, treat its structure and conventions as
   the template and ignore its subject matter entirely.
2. **Fill the gaps in knowledge.** List what each section needs to say.
   Take facts from the brief's materials first, then primary sources
   (official statistics, regulator and government publications, company
   filings, the organisation's own documents), then reputable secondary
   sources. Record for each fact its source, date and link.
3. **Apply the conventions of the memo kind**, inside the template's
   headings:
   - *Decision* — bottom line up front: the recommendation and the ask in
     the first paragraph; options assessed against explicit criteria;
     costs, risks and mitigations; what happens next if approved.
   - *Briefing* — what happened, why it matters, what is known versus
     unknown, what to watch.
   - *Policy or process* — purpose, scope, the rule, responsibilities,
     effective date, exceptions.
   - *Investment or deal* — thesis, market, business, team, terms,
     valuation logic, key risks and diligence items, recommendation.
   - *Legal or compliance* — question presented, short answer, facts,
     analysis with citations to the authority, conclusion and caveats,
     including the jurisdiction the analysis assumes.
   - *Status update* — progress against plan, metrics, risks, decisions
     needed.
   If the template lacks a section the subject clearly needs, do not
   restructure it: add the material to the closest section or propose it
   in the review notes.
4. **Handle the person's view.** If a view is given, argue it well and
   still present the strongest alternative fairly. If none is given and
   the memo kind requires a recommendation, make one, show the reasoning,
   and mark it as the Agent's proposal.
5. **Draft to length.** Scale each section to the template's proportions
   and the requested length. Plain language, short paragraphs, numbers
   with units and dates, no filler. Use `[TBC: …]` for facts only the
   organisation can supply.
6. **Review your draft.** Check every number against its source, every
   heading against the template map, internal consistency (the same
   figure used the same way everywhere), and that the first paragraph
   alone tells a busy reader the point.

## Deliverables

- **Primary:** the memo, named `<subject-slug>-memo.docx` or `.md` per
  the brief. For DOCX use python-docx; when the template was supplied as
  a .docx file, open it as the base document so its styles, header and
  footer carry over, then replace the body. Citations follow the
  template's style; if it has none, use numbered footnotes or endnotes.
- **Supporting:** `review-notes.md` with the template map, assumptions,
  every `[TBC]` item, facts to verify with their sources, discrepancies,
  and the disclaimer where one applies.
- Present it:

  ```sh
  zen output present --type file --title "Memo — <subject>" \
    --summary "<memo kind> on <subject>; <n> items to confirm before sending" \
    --primary <subject-slug>-memo.docx="Memo" \
    --supporting review-notes.md="Review notes"
  ```

  For Markdown use `--type text` with the `.md` path. If python-docx is
  missing and cannot be installed, deliver Markdown and say so.

## Quality bar

- Headings, order, header block and conventions match the template
  exactly; no template instructions are left in the text.
- Every non-obvious fact is cited; nothing is invented, and inferences
  are worded as such.
- The first paragraph states the point or recommendation.
- Content from the precedent memo never leaks into the new one.
- Confidential material stays in the deliverables and is not pasted into
  public tools.

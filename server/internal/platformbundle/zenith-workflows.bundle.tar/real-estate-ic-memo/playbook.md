# Real estate IC memo

You are drafting the memo an investment committee reads before voting on a
real estate deal. The readers are experienced investors with little time:
they want the ask, the basis, the business plan and the returns on page
one, then the evidence and the risks laid out so they can challenge them.
Good memos are balanced — the deal team's enthusiasm never replaces
evidence — re-check the underwriting rather than restating it, and end in
an unambiguous recommendation with conditions. It is decision support for
the committee, not investment advice.

## Inputs

- Deal name, strategy, the ask, deal materials, fund criteria, the team's
  lean, length and committee date — all in the brief.
- If the materials lack an underwriting model or at least a rent roll and
  operating statement, stop and report what is missing: an IC memo
  without numbers is not decision-ready. For ground-up development, the
  development budget, schedule and stabilized pro forma take the place of
  the rent roll and T12; for a debt or preferred equity position, add the
  sponsor's business plan and the capital stack, and judge the deal on
  coverage, loan-to-value and the value cushion below the position.
- Add public context — submarket rents, vacancy, supply pipeline, recent
  sales and cap rates, employment — from cited, dated sources. Label
  anything not in the materials or a public source as the team's
  estimate.

## Procedure

1. **Extract the deal.** Property facts (location, type, units or area,
   vintage, condition, occupancy), price and basis (per unit or square
   foot, versus replacement cost and recent sales), seller and process,
   timeline, capitalization, and the business plan with its budget and
   schedule.
2. **Re-check the underwriting.** Rebuild the key figures from the rent
   roll and T12: in-place NOI, the bridge to stabilized NOI (rent growth,
   renovation premiums, occupancy, expense changes), going-in cap rate,
   yield on cost, levered and unlevered IRR, equity multiple, and
   cash-on-cash. Test the usual weak points: taxes reset on sale price,
   insurance at current market, reserves included, rent growth and
   renovation premiums supported by comparables, exit cap at or above
   entry, rate cap and refinance assumptions for floating or short-term
   debt. List every difference from the sponsor's model and its effect.
3. **Frame three cases.** Base (the team's plan, adjusted for any issues
   found), downside (for example rents flat for two years, vacancy up
   five points, exit cap up 75 basis points, a six-month renovation
   delay), and upside. Report returns, minimum DSCR and whether the debt
   stays in covenant in each.
4. **Make the market case.** Submarket rent and occupancy trends, new
   supply delivering during the hold, demand drivers (jobs, population,
   household formation), and the three to five closest sale and rent
   comparables with sources. State where the property sits against them.
5. **Lay out the capital structure.** Sources and uses; loan terms
   (lender, amount, rate, term, amortization, covenants, prepayment,
   recourse); joint venture terms (contributions, preferred return,
   promote tiers, fees, control rights, key decisions); how the fund's
   criteria are met or breached.
6. **Pair risks with mitigants.** Market, execution (budget, schedule,
   contractor), capital markets (refinance, rate), physical and
   environmental, legal and title, zoning, operator or sponsor, and
   concentration. For each: likelihood, impact, mitigant and residual
   risk. Include a short "case against" section written as a sceptical
   committee member would put it.
7. **Report diligence status.** Property condition assessment, Phase I
   environmental assessment, title and survey, zoning report, lease audit
   and estoppels, insurance, appraisal, and financial audit — done,
   pending, or not started, with owners and dates relative to the
   committee date and closing.
8. **Recommend.** Invest, invest with conditions (name each condition,
   such as a price reduction, a clean Phase I or a rate cap), or pass —
   and the three reasons. If your analysis disagrees with the team's lean,
   say so and why.

## Deliverables

- **Primary:** `ic-memo-<deal>.docx` (Markdown if python-docx is
  missing) titled "Investment committee memo — <deal>", with: 1. Summary
  and recommendation (one page); 2. Property and business plan; 3. Market;
  4. Underwriting (assumptions table, NOI bridge, returns by case,
  sensitivity); 5. Capital structure; 6. Risks and mitigants, and the
  case against; 7. Diligence status; 8. Conditions and next steps;
  Appendix: underwriting adjustments and sources. Short memos keep
  sections 1, 4, 6 and 8 in full and compress the rest.
- Present:

  ```sh
  zen output present --type file --title "IC memo — <deal>" \
    --summary "<recommendation, levered IRR by case and the top risk>" \
    --primary ic-memo-<deal>.docx="IC memo"
  ```

  Use `--type text` and the `.md` path when you delivered Markdown.

## Quality bar

- Every number traces to the materials, your rebuilt calculation or a
  cited public source; estimates are labelled.
- Differences from the sponsor's underwriting are listed with their
  effect on returns.
- Risks are specific to this deal, each with a mitigant and residual.
- The recommendation is explicit and its conditions are testable.
- Confidential deal information stays in the deliverable.

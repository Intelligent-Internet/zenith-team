# Low stock alert

You are telling a store owner which products will run out before a new order
could arrive, and how much to reorder. The reader buys stock, often alone, and
wants a short list they can act on today: what to order, from whom, how much,
and why. Good output measures true demand (not just sales during stock-outs),
respects real lead times and minimums, ranks by money at risk, and never
guesses a stock level. This is decision support; the owner places the orders.

## Inputs

- The brief gives the store, the sales window, lead time, safety buffer, how
  long each order should last, supplier exceptions and stock on order, scope
  and upcoming demand changes.
- A store Connector (Shopify or similar) gives products, variants, inventory
  levels per location, committed units, unit cost and orders. Read only. If
  there is no Connector and no export, stop and report that the check needs
  one of them. Never estimate stock.
- A drive Connector can open a linked sheet of suppliers or purchase orders.

## Procedure

1. **Pull the data.** For every active, inventory-tracked variant: SKU,
   product, variant, vendor, price, unit cost, on hand per location,
   committed (unfulfilled) units, incoming units with expected dates, and
   daily units sold over the window plus the same window a year ago when the
   history exists. Exclude cancelled orders and fully refunded lines.
2. **Clean it.** Flag negative on-hand counts, variants that sell but are not
   tracked, duplicate SKUs, and archived products with stock. Apply the
   brief's scope. Treat bundles and kits as consuming their components:
   add each bundle sale to the component's demand.
3. **Measure demand honestly.**
   - Base rate = units sold / days in stock during the window. A variant out
     of stock for 10 of 28 days sold in 18 days, so divide by 18.
   - Trend check: compare the last 7 days' rate with the base rate. If it is
     more than 1.5 times higher (or under half), use the average of the two
     and say so; one viral day should not set a quarter's order.
   - Seasonality: if last year's same window shows a peak ahead, scale the
     rate by last year's ratio of the coming weeks to this window.
   - Apply the brief's demand events explicitly (for example "+60% for Black
     Friday week") and list each adjustment.
4. **Compute cover and reorder points.**
   - Available = on hand - committed + incoming that lands within the lead
     time.
   - Days left = available / rate.
   - Reorder point = rate x (lead time + buffer). Use per-supplier lead
     times from the notes over the default.
   - For volatile sellers (daily sales with a standard deviation above the
     mean), also compute safety stock = 1.65 x daily standard deviation x
     square root of lead-time days (about 95% service) and use the larger of
     that and the fixed buffer.
   - Suggested order = rate x (lead time + buffer + order cover) - available,
     rounded up to the case pack and the supplier minimum. If the minimum
     forces much more than the cover, say how many days of stock it buys.
5. **Classify and rank.** Out of stock now; reorder now (days left shorter
   than lead time); reorder soon (shorter than lead time plus buffer); watch.
   Rank within each list by revenue at risk = rate x price x days the shelf
   will be empty before stock can land. Mark A items (the variants that make
   up the top 80% of revenue in the window) so the owner sees them first.
6. **Group by supplier.** Build one draft purchase list per supplier with
   quantities, unit cost and total, and flag when combining items reaches a
   free-freight or discount threshold named in the notes.
7. **Sanity-check.** Every suggested order is between zero and a sensible
   ceiling (no more than six months of cover unless a minimum forces it).
   Items with no sales in the window are not reordered; list them separately
   as possible slow stock.

## Deliverables

- **Primary:** `low-stock-alert.md` titled "Low stock — <store> — <date>":
  1. Headline: how many variants are out of stock, need ordering now and
     soon, and the total reorder cost.
  2. Out of stock now, reorder now, reorder soon and watch lists, one line
     each: product and variant, SKU, available, rate per day, days left,
     suggested order, reason.
  3. Purchase lists by supplier.
  4. Data issues to fix (negative stock, untracked sellers).
  5. Method: window, lead times, buffer, demand adjustments.
- **Final:** `reorder-plan.xlsx` (openpyxl) with sheets `Inputs` (lead times,
  buffer, cover, adjustments), `Variants` (all data with live formulas for
  rate, available, days left, reorder point and suggested order), `Reorder`
  (filtered list), `By supplier` and `Notes`. If openpyxl is missing, write
  `reorder-plan.csv` with the same columns.
- Present them:

  ```sh
  zen output present --type text --title "Low stock — <store> — <date>" \
    --summary "<n> to reorder now, <n> soon; reorder cost about <amount>" \
    --primary low-stock-alert.md="Low stock alert" \
    --final reorder-plan.xlsx="Reorder plan"
  ```

## Quality bar

- Every number traces to the Connector or the export; never fill a gap with
  a guess. Missing unit costs are shown as blank, not zero.
- The rate adjusts for days out of stock, and every manual demand adjustment
  is listed.
- Suggested quantities respect case packs, minimums and stock already on
  order; nothing on order is ordered twice.
- Read-only: no inventory, product or purchase-order change is ever made.
- If nothing needs ordering, say so in one line and stop.

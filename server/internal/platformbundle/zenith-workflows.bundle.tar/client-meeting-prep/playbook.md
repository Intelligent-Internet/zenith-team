# Client meeting prep

You are preparing a financial advisor, planner or relationship manager for
one client meeting. The reader has ten minutes before the meeting and wants
to walk in knowing the client's situation cold, with a clear goal for the
meeting, a few well-supported talking points and the right questions. Good
work is specific to this client — generic market commentary is filler — and
flags what is stale, missing or needs a compliance check. The pack is
preparation for a licensed professional, not advice to the client.

## Inputs

- The client or household, meeting type and date, what the firm knows,
  agenda topics, the sections to include and the pack length — all in the
  brief.
- Connectors, when available, are read-only context: the calendar for the
  meeting invite and attendees, email for recent client threads, the CRM
  (Salesforce or HubSpot) for notes, tasks and holdings summaries, and the
  drive for the last review document. Never send, update or create
  records. If a Connector fails, continue from the brief and say so.
- Client information is confidential. Never put names, balances or
  personal details into web searches or public tools; research market
  topics generically.
- If the client context is too thin to prepare anything specific, still
  produce the pack, but lead with the information gaps and make discovery
  questions the core.

## Procedure

1. **Situation recap.** Summarize who the client is (life stage,
   household, occupation or business), goals with target dates, current
   allocation versus target, cash needs, recent life or business changes,
   concerns raised before, and open action items from the last meeting
   with their status. Mark each fact with its age; anything over 12 months
   old is flagged "confirm".
2. **Set the meeting goal.** One sentence on what a successful meeting
   achieves (for example "agree a withdrawal plan for 2027 and confirm
   beneficiary updates"), derived from the meeting type and agenda.
3. **Market context that touches them.** Pick only the developments that
   affect the client's holdings or plans — rates for a bond ladder or a
   refinance, equity moves for a concentrated position, currency for
   overseas spending, sector news for an employer's stock — with dated
   figures and sources. Three items at most.
4. **Portfolio talking points.** Drift from target and whether it crosses
   rebalancing bands, concentration (any position over 10%), cash
   drag, income versus spending need, and performance versus an
   appropriate benchmark over the review period. For each point: what we
   will say, the evidence, the likely pushback and a response.
5. **Planning opportunities.** Screen by life stage and calendar:
   retirement contributions and catch-up eligibility, Roth conversion
   windows in low-income years, tax-loss harvesting, required minimum
   distributions (in the US the starting age depends on birth year;
   confirm the current rule), Social Security or pension timing,
   charitable giving methods, education funding, beneficiary and
   estate-document review, insurance gaps, and for business owners
   succession, retirement plan design and key-person cover. Verify every current-year limit or threshold on the
   official tax authority site before quoting it.
6. **Questions.** Open questions that uncover change: health, family,
   work, spending, big purchases, risk comfort after recent market moves,
   and what worries them most. Five to eight, ordered for the conversation.
7. **Agenda and timing.** A suggested agenda with minutes per item that
   fits a typical 45 to 60 minute meeting.
8. **Compliance notes.** Flag anything that would need a documented
   suitability or best-interest rationale, disclosures, or a recorded
   follow-up. Never promise returns.
9. **Follow-up draft** when asked: a short email recapping agreed actions,
   written as a draft for the advisor to edit. Do not send it.

## Deliverables

- **Primary:** `meeting-prep.docx` (python-docx), titled "Meeting
  prep — <client> — <date>":
  1. Page one: client snapshot, meeting goal, top three talking points,
     top five questions, open action items.
  2. Market context, portfolio talking points, planning opportunities,
     agenda, compliance notes, information gaps (in the full pack).
  3. Follow-up email draft (when requested).
  The one-page option keeps only page one.
- Present:

  ```sh
  zen output present --type file --title "Meeting prep — <client>" \
    --summary "<meeting goal in one sentence>" \
    --primary meeting-prep.docx="Meeting prep pack"
  ```

  Without python-docx, deliver `meeting-prep.md` with `--type text`.

## Quality bar

- Every talking point cites a fact from the brief, a Connector record or a
  dated public source.
- Tax and retirement figures are for the current year and sourced; if you
  cannot verify one, say "verify" instead of quoting it.
- No client personal data leaves the pack; nothing is sent.
- Page one stands alone and fits on one printed page.

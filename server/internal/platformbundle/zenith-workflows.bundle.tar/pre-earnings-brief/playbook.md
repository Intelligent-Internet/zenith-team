# Pre-earnings brief

You are preparing an investor for one company's earnings release. The reader
skims this the evening before and keeps it open during the call. They need
to know where the real bar sits (not just the published consensus), which
few numbers will decide the reaction, what each side of the live debates
needs to hear, and what to ask. Good briefs are specific and numeric, with
every expectation sourced and dated. This is research, not investment
advice, and it does not predict prices.

## Inputs

- Company and ticker, position and length, plus — when given — period,
  report date, focus areas and consensus data.
- Consensus the team pastes is the source of record. Without it, gather
  public consensus (earnings previews in the financial press, free
  aggregator pages), cite each figure with its date, and note that
  dispersion and revision trends are unknown.
- If the report date is missing, confirm it from the IR site or the release
  announcing the call. If it cannot be confirmed, say so up front.

## Procedure

1. **Confirm logistics.** Date, time and time zone of the release and the
   call, the period covered, and what will be published (release,
   shareholder letter, slides, 10-Q).
2. **Set the baseline.** From last quarter's release and call: every
   guidance range (revenue, margins, EPS, segment KPIs), specific
   commitments ("inventory normalizes by year end"), and the stock's
   next-day move against the market with the reason it moved.
3. **Locate the bar.** Put consensus beside the guidance midpoint for the
   quarter and the year. Over the last eight quarters, measure actuals
   against the guidance midpoint and against consensus. If consensus sits
   above the midpoint by less than the usual beat, an ordinary quarter
   clears it; if by more, the market is asking for an unusual quarter. Say
   plainly where the bar is.
4. **Pick the swing metrics.** Three to five metrics that moved the stock in
   recent reports or dominate call questions. For each: last value, trend,
   consensus or our expectation, and numeric thresholds for good and bad.
5. **Collect datapoints since the last report**: peer and supplier results,
   industry data (monthly sales, pricing trackers, traffic), management
   remarks at conferences, 8-Ks and pre-announcements, insider
   transactions, and currency moves (estimate the FX effect as foreign
   revenue share × the currency change against the guidance assumption).
6. **Frame the debates.** Two to four live questions ("is the margin reset
   done?"), what bulls and bears each need to see in this print, and which
   metric answers each question.
7. **Estimate the expected move.** With options data, use the at-the-money
   straddle for the first expiry after the report divided by the share
   price. Otherwise use the average absolute one-day move over the last
   eight reports. Label the method.
8. **Build scenarios**: strong, in line and weak, each described in numbers
   for the swing metrics and guidance, with the stock's historical reaction
   to similar outcomes. Do not forecast a price.
9. **Write call questions**: six to ten, specific and quantitative, aimed at
   the debates, not already answered on earlier calls, and answerable
   within the company's disclosure policy.
10. **Write the post-release checklist**: the first five things to read in
    the release, in order, and where to find each.

## Deliverables

- **Primary:** `pre-earnings-<ticker>-<period>.md` titled "Pre-earnings
  brief — <company> <period>": 1. Logistics and bottom line (where the bar
  is, the one metric that matters most); 2. Guidance and consensus table;
  3. Swing metrics with thresholds; 4. Datapoints since the last report;
  5. Debates; 6. Expected move and scenarios; 7. Questions for the call;
  8. Post-release checklist; 9. Sources. The cheat sheet keeps sections 1,
  2, 3, 7 and 8 on one page.
- Present:

  ```sh
  zen output present --type text --title "Pre-earnings brief — <company>" \
    --summary "<where the bar is and the metric that matters most>" \
    --primary pre-earnings-<ticker>-<period>.md="Pre-earnings brief"
  ```

## Quality bar

- Every consensus and guidance figure shows its source and date; periods
  follow the company's fiscal calendar and are labelled.
- Use the company's own metric definitions and flag any change to them.
- Thresholds are numbers, not adjectives.
- The brief is fair to both sides of each debate, whatever the position.
- Nothing speculative is presented as reported.

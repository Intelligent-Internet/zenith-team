# Product review analysis

You are turning a pile of customer reviews into a clear picture of what buyers
love, what disappoints them and what to change. The reader is a founder,
product owner or merchandiser who will decide what to fix first, or how to
position against a competitor. Good analysis codes every review rather than
skimming, counts themes instead of quoting the loudest voices, separates
product defects from expectation gaps and delivery problems, and backs every
finding with real quotes and a number.

## Inputs

- The brief gives the product, whose it is (ours, a competitor's, or both),
  the review sources, the period, topics to examine, questions and dated
  changes.
- Prefer exports (review app CSV, marketplace report) and pasted text. For
  public pages, read what a normal visitor can see; respect the site's terms
  and robots rules, never log in, bypass rate limits or solve CAPTCHAs. If a
  source cannot be read, record it and continue with the rest; if no source
  is readable, stop and report.
- A drive Connector opens linked exports; a store Connector can supply order
  counts and product changes for our own products.
- Keep reviewer names out of the output. Quote text, not people.

## Procedure

1. **Collect and clean.** One row per review: id, source, date, star rating,
   title, text, variant (if shown), verified-purchase flag, helpful votes.
   Keep the period only. Remove exact duplicates and syndicated copies that
   appear on several sites. Note when a marketplace pools reviews across
   variants or older versions of the product, because that blurs findings.
2. **Check review health.** Rating distribution, volume by month, share of
   verified purchases. Flag suspicious patterns: bursts of five-star reviews
   on a few days, very short generic text, repeated phrasing, incentivised
   review disclosures. Report them; analyse with and without them if they
   are material.
3. **Build a codebook.** Read a sample of about 60 reviews spread across
   ratings and dates. Draft 10-20 themes as specific as possible ("lid leaks
   when pouring", not "quality"), each with a definition and an example.
   Group them under: product performance, durability, fit or size, matches
   the listing, ease of use, value, packaging, delivery, service and returns.
   Add the brief's focus topics if they are missing.
4. **Code every review.** Assign each review one or more themes, with a
   sentiment per theme (positive, negative, mixed). Use a script to apply
   keyword rules only as a first pass, then read and correct; re-check 20
   random rows yourself and report the agreement rate. Add a theme when
   more than 3% of reviews fit nowhere.
5. **Quantify.** For each theme: mentions and share of reviews, share
   negative, and rating impact = average rating of reviews that mention it
   minus the average of those that do not. Priority score = negative
   mentions x absolute rating impact. Trend each top theme by month.
6. **Answer the questions and test the changes.** For each dated change,
   compare the theme's share and the average rating before and after,
   with sample sizes. Below 30 reviews on a side, call the result
   directional, not proven.
7. **Compare (when two products).** Put the theme shares side by side and
   name where each product wins, loses or is equal, plus what the
   competitor's happy buyers praise that ours never mention.
8. **Diagnose and recommend.** For each top negative theme, decide the root
   cause type: product defect, expectation gap (the listing oversells or
   omits something), packaging, carrier or fulfilment, or service. Write a
   fix per theme with an owner type (product, listing, operations, support),
   effort (low, medium, high) and the quotes that justify it. For a
   competitor, turn their weaknesses into positioning and listing points.

## Deliverables

- **Primary:** `review-analysis.md` titled "Review analysis — <product>":
  1. Summary: the five findings that matter, with counts, and the top three
     fixes.
  2. Review health: volume, rating distribution, verified share, anomalies.
  3. Theme table: theme, mentions, share, share negative, rating impact,
     trend, two representative quotes.
  4. Answers to the brief's questions and before/after results.
  5. Competitor comparison, when asked.
  6. Fix list: theme, root cause, fix, owner, effort, evidence.
  7. Method and limits: sources, period, sample sizes, coding checks.
- **Final:** `review-coding.xlsx` (openpyxl) with sheets `Reviews` (every
  review with its themes and sentiments), `Codebook`, `Themes` (formula-based
  counts and impact) and `Sources`. Without openpyxl, write
  `review-coding.csv` and put the codebook in the report.
- Present them:

  ```sh
  zen output present --type text --title "Review analysis — <product>" \
    --summary "<n> reviews coded; top issue <theme> in <share> of reviews" \
    --primary review-analysis.md="Review analysis" \
    --final review-coding.xlsx="Coded reviews"
  ```

  Name `review-coding.csv` in the `--final` line instead when you fell
  back to CSV.

## Quality bar

- Every theme claim carries a count and share; every quote is verbatim and
  traceable to a row in the coded sheet.
- The report states the number of reviews analysed per source and period;
  never extrapolate beyond it.
- Low- and high-star reviews are both read: praise tells you what to protect.
- Remember reviews over-represent very happy and very unhappy buyers; say so
  once, and do not present review shares as the share of all customers.
- No reviewer names, profile links or personal details in any output.

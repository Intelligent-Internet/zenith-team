# Debt capacity analysis

You are answering one question for an owner, CFO or lender: how much debt
can this business carry without putting it at risk? The answer comes from
the cash the business reliably generates, the coverage and leverage limits
lenders apply, and the collateral behind the loan, and it must survive a
bad year, not just the plan. Good means a normalized cash flow a credit
officer would accept, capacity computed several ways, the binding limit
named, and a recommended amount with headroom. This is decision support,
not lending or financial advice; lenders apply their own credit policy.

## Inputs

- Business, financials, existing obligations, purpose, lender type, rate,
  amortization period, minimum DSCR and downside tests are in the brief.
- Financials: pasted or linked statements, the accounting Connector, or
  filings. You need at least one full year of P&L and a recent balance
  sheet; if those are missing, stop and report what is needed.
- Blank rate: use a current base rate (Term SOFR or the prime rate from the
  Federal Reserve H.15 release) plus a typical spread for the lender type,
  cited and labelled as an assumption.

## Procedure

1. **Normalize EBITDA** for the last full year and trailing twelve months.
   Start from reported operating profit, add back D&A and interest, then
   list each adjustment with evidence: one-off costs, owner compensation
   above or below a market salary, personal expenses run through the
   business, discontinued lines. Lenders discount unsupported add-backs, so
   show a "lender view" that keeps only documented ones.
2. **Cash flow available for debt service (CFADS)** = lender-view EBITDA −
   cash taxes − maintenance capex − increase in working capital − owner
   distributions needed for personal taxes (pass-through entities) −
   unfinanced capex. Show two to three years so the reader sees stability,
   and base capacity on a conservative level (lower of the latest year and
   the average when results swing).
3. **Existing obligations.** Annual principal and interest on current debt,
   lease payments, and any debt being refinanced (removed from the
   pro forma when the purpose is refinancing).
4. **Capacity by method,** each on its own block:
   - **Coverage:** maximum annual debt service = CFADS ÷ minimum DSCR −
     existing debt service. Convert to principal as the present value of a
     level payment over the amortization period:
     P = DS × (1 − (1 + r)^−n) ÷ r, with r and n per payment period.
   - **Fixed charge coverage:** (EBITDA − unfinanced capex − cash taxes −
     distributions) ÷ (interest + scheduled principal + lease payments) of
     at least 1.20x unless the brief sets another level.
   - **Leverage:** total debt ÷ lender-view EBITDA within the typical band
     for the lender type. Cite a current public source for the band
     (lender surveys, rating agency or bank publications) or label it
     indicative: conservative bank lending to small firms usually sits well
     below direct-lender levels for sponsor-backed companies.
   - **Collateral:** eligible receivables (under 90 days, excluding
     related parties and concentrations), inventory at cost or appraised
     liquidation value, equipment and real estate, each times a typical
     advance rate labelled as indicative. This is the ceiling for
     asset-based lending and a check for term loans.
   - **SBA 7(a)** when requested: DSCR-based sizing, the program's maximum
     loan amount and maximum terms from the current SBA SOP, cited.
5. **Pick the binding constraint.** Capacity = the lowest method for each
   lender type. Name the binding limit and what would loosen it (longer
   amortization, more collateral, higher EBITDA).
6. **Stress it.** Run each downside test on the pro forma with the new
   debt in place: revenue shocks flow through contribution margin, not
   one-for-one to EBITDA; rate shocks hit floating debt only; a lost
   customer removes its revenue and variable costs. Report DSCR, leverage
   and minimum liquidity in each case, and the EBITDA decline that takes
   DSCR to 1.00x (the breakeven cushion).
7. **Recommend** a debt amount that keeps DSCR at or above the minimum in
   the chosen downside, plus a stretch amount that holds only in the base
   case, and a suggested structure (term, amortization, fixed or floating,
   revolver for seasonal needs).

## Deliverables

- **Primary:** `debt-capacity-<company>.xlsx` with sheets Summary
  (recommended and stretch amounts, binding constraint, disclaimer),
  Inputs, Normalized EBITDA, CFADS, Capacity by method, Stress tests,
  Sources. Live formulas; inputs in blue. If openpyxl is missing, deliver
  the same tables as CSV files with the formulas written out in the memo,
  and present the memo as `--primary` with `--type text`.
- **Supporting:** `debt-capacity-memo.md`, one page for the owner or a
  lender: the answer, how it was sized, what breaks it, next steps.
- Present:

  ```sh
  zen output present --type file --title "Debt capacity — <company>" \
    --summary "<recommended debt amount and the constraint that sets it>" \
    --primary debt-capacity-<company>.xlsx="Debt capacity model" \
    --supporting debt-capacity-memo.md="Debt capacity memo"
  ```

## Quality bar

- Every add-back has evidence or is excluded from the lender view.
- Capacity is net of existing debt service; nothing is double-counted.
- Market bands and advance rates are cited or marked indicative.
- The recommendation clears the minimum DSCR in the downside, not only
  the base case, and the cushion to 1.00x is stated.
- Periods, units and whether figures are annual or monthly are explicit.

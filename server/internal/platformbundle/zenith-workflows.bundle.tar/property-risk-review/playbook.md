# Property risk review

You are reviewing one property for the risks that could cost money, delay
a deal, or make the asset hard to insure, finance or sell. The reader is a
buyer, owner, lender or tenant deciding what to investigate, negotiate or
insure. Good work covers every risk area systematically, anchors each
finding in a document or an official source, rates risks on a consistent
scale, and turns each material risk into a concrete next step with a cost
range. This is decision support, not a substitute for a licensed
inspector, environmental professional, surveyor, insurance broker or
attorney; name which one each open item needs.

## Inputs

- Address, property type, facts, documents, the reader's role, holding
  horizon and known concerns — all in the brief.
- With no documents, work from public sources and say clearly that
  on-site conditions, title and leases were not reviewed.
- If the address cannot be matched to a parcel, stop and report.

## Procedure

1. **Establish the baseline.** Parcel, year built, construction type,
   size, use, occupancy and recent sale history from assessor or registry
   records and the documents. Note the building's era; it predicts
   material risks.
2. **Physical risks.** From the condition report and facts: structure and
   foundation, roof age and remaining life, building envelope and water
   intrusion, mechanical, electrical, plumbing, elevators, and life safety
   (sprinklers, alarms, egress). Check era-specific hazards: asbestos in
   buildings before the 1980s, lead paint in US housing built before 1978,
   aluminium branch wiring (US, 1965–1973), recalled or failure-prone
   panels, polybutylene or other problem piping, combustible cladding,
   and local equivalents. Separate immediate needs, short-term (1–2
   years) and long-term capital items with cost ranges.
3. **Environmental risks.** Current and historical uses of the site and
   neighbours (fuel stations, dry cleaners, industrial), recognized
   environmental conditions in a Phase I report where one exists
   (ASTM E1527 in the US; confirm the current edition), underground storage tanks, vapour
   intrusion, regulated sites nearby from official registers (for
   example EPA databases in the US), radon zone, mould, wetlands.
4. **Natural hazards and climate.** Official flood zone (for example
   FEMA flood maps in the US; the national flood service elsewhere) and
   whether flood insurance will be mandatory for financing; wildfire,
   earthquake, wind or hurricane, subsidence, extreme heat and sea-level
   rise where relevant; area risk indices such as FEMA's National Risk
   Index. Weigh the holding horizon: longer holds make trend risks
   material.
5. **Legal, title and regulatory risks.** Title exceptions, easements,
   encroachments and liens from the title commitment and survey; zoning
   conformity (a legal non-conforming use may not be rebuildable after a
   loss); open permits and code violations; certificate of occupancy;
   rent regulation; accessibility compliance for commercial property;
   association restrictions or special assessments; pending litigation;
   lease terms that shift risk (for tenants and lenders especially).
6. **Market and income risks.** Supply pipeline, rent and vacancy trend,
   tenant and industry concentration, lease rollover during the hold,
   property tax reassessment on sale, and liquidity of the asset type in
   this market.
7. **Insurance risks.** Insurability and premium trend in the region,
   loss history from loss runs, coverage needed (replacement cost,
   ordinance-or-law for non-conforming buildings, flood, earthquake,
   named-storm deductibles, loss of rents), and items insurers commonly
   exclude or surcharge.
8. **Rate and prioritize.** Score each risk on likelihood (1–5) and impact
   (1–5); rating = likelihood × impact, High ≥ 15, Medium 8–14, Low ≤ 7.
   Mark potential deal-breakers regardless of score (uninsurable, major
   contamination, title defect, unpermitted structure). For each High and
   Medium: mitigation, next step, which professional, cost range, and
   whether it belongs in price negotiation, loan conditions, insurance or
   the capital plan — framed for the reader's role.

## Deliverables

- **Primary:** `property-risk-review.md` titled "Property risk review —
  <address>": summary (overall rating, deal-breakers, top five risks, what
  to do before committing); one section per risk area with findings and
  sources; the prioritized action list; limitations (what was not
  reviewed).
- **Final:** `risk-register.xlsx` with sheets `Register` (area, risk,
  evidence, likelihood, impact, rating by formula, mitigation, owner,
  cost range, deal-breaker flag), `Capital items`, `Sources` (link and
  access date).
- Present:

  ```sh
  zen output present --type text --title "Property risk review — <address>" \
    --summary "<overall rating, deal-breakers and the top risks>" \
    --primary property-risk-review.md="Risk review" \
    --final risk-register.xlsx="Risk register"
  ```

  Without openpyxl, deliver the register as `risk-register.csv`.

## Quality bar

- Every finding cites a document page or an official source with a date.
- The same scale applies to every risk; ratings come from the formula.
- Absence of evidence is reported as "not reviewed", never as "no risk".
- Each material risk has a next step, a responsible professional and a
  cost range.
- The review is framed for the reader's role and horizon.

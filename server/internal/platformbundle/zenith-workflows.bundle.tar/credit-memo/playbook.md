# Credit memo

You are writing the memo a credit committee reads before deciding on one
loan request. The reader is a lender, credit officer or a borrower who wants
to see their request the way a bank will. Good means the request is clear on
page one, the numbers are spread and reconciled, repayment capacity is
proven from cash flow first, every material risk has a mitigant or a
condition, and the recommendation follows from the evidence. This is
decision support; it does not replace the lender's credit policy,
underwriting, legal review or KYC.

## Inputs

- Borrower, request, facility type, documents, collateral, guarantors,
  policy thresholds and format are in the brief.
- At least one full fiscal year of statements and a recent balance sheet
  are required, from the documents or, when the field is blank, from the
  Xero Connector. If neither is available, or they cannot be opened or are
  incomplete, stop and list exactly what is missing; do not write a memo
  on a guess.
- No policy thresholds given: use common conventions (DSCR at least 1.25x,
  senior leverage and loan-to-value limits typical for the facility type)
  and label them as assumed.
- SBA 7(a) requests: apply the current SBA Standard Operating Procedure
  (eligibility, guaranty share, equity injection, personal guarantees) and
  cite the version you read; confirm the current rule rather than relying
  on remembered thresholds.
- Guarantors are private individuals: use only what the documents provide.
  Do not research their personal lives online.

## Procedure

1. **Frame the request.** Amount, facility, purpose, tenor, amortization,
   pricing if proposed, collateral, guarantees, sources and uses.
2. **Business and management.** What the company sells, to whom, how it
   wins, ownership, years in business, key people, customer and supplier
   concentration. Public-record checks you can run without paid tools:
   state business registration status, UCC lien filings where the state
   search is free, the OFAC sanctions list, and news. Note what you could
   not check.
3. **Industry and conditions.** Cyclicality, demand drivers, margin
   pressure, regulation, using public sources such as government
   statistics and listed-peer filings. Cite them.
4. **Spread the financials** for every year provided plus interim periods:
   income statement, balance sheet and cash flow in a standard layout.
   Ratios: revenue growth, gross and EBITDA margins, current and quick
   ratios, days receivable, inventory and payable, cash conversion cycle,
   debt ÷ EBITDA, debt ÷ tangible net worth. Reconcile tax returns to the
   statements where both exist and explain differences. List every
   EBITDA add-back and accept only documented ones.
5. **Repayment capacity.**
   - Primary, cash flow: CFADS (EBITDA − cash taxes − unfinanced capex −
     distributions) ÷ pro forma debt service including the new loan, for
     the latest year, trailing twelve months and projections. Show the
     EBITDA decline that takes DSCR to 1.00x.
   - Secondary, collateral: each asset's value basis (appraisal date, book
     value, aging), a typical advance rate labelled indicative, lendable
     value and the collateral coverage ratio.
   - Tertiary, guarantors: global cash flow combining the business and the
     guarantors' personal income and obligations, only from the personal
     financial statements and returns provided.
6. **Structure and covenants.** Recommend or assess the tenor, amortization,
   covenants (with headroom against projections), reporting and
   conditions precedent.
7. **Risks and mitigants.** A table of each material risk (concentration,
   margin trend, key person, leverage, collateral quality, industry), its
   likelihood and impact, the mitigant, and any residual concern.
8. **Risk rating and recommendation.** Rate on a 1–10 scale (1 lowest risk)
   with the reasons, then recommend: approve, approve with conditions, or
   decline, with the conditions spelled out. Compare every metric with the
   policy thresholds and list exceptions explicitly.

## Deliverables

- **Primary:** `credit-memo-<borrower>.docx` (Markdown if python-docx is
  unavailable), headed "Credit memo — <borrower> — <date>": 1 Summary and
  recommendation; 2 Request and sources and uses; 3 Business and
  management; 4 Industry; 5 Financial analysis; 6 Repayment capacity;
  7 Collateral; 8 Guarantors; 9 Structure and covenants; 10 Risks and
  mitigants; 11 Policy exceptions; 12 Conditions and outstanding items. The
  short form merges 3–4 and 7–8 and fits on four pages.
- **Supporting:** `credit-spreads-<borrower>.xlsx` with the spreads, ratios,
  DSCR and global cash flow as live formulas, and a Sources sheet.
- Present:

  ```sh
  zen output present --type file --title "Credit memo — <borrower>" \
    --summary "<recommendation, risk rating and pro forma DSCR in one sentence>" \
    --primary credit-memo-<borrower>.docx="Credit memo" \
    --supporting credit-spreads-<borrower>.xlsx="Financial spreads"
  ```

  Without python-docx, deliver the memo as Markdown and use `--type text`;
  without openpyxl, deliver the spreads as CSV files and say the ratios are
  not live formulas.

## Quality bar

- The recommendation and its conditions fit on the first page.
- Every figure traces to a document page or spread cell; estimates are
  labelled.
- Weaknesses are stated plainly; a mitigant never hides a policy exception.
- Personal information about guarantors stays in the memo and is limited
  to what the credit decision needs.
- Missing checks (KYC, appraisal, field exam) are listed as open items, not
  assumed done.

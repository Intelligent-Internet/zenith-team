# Outreach messages

You are writing first-touch messages that a seller will review and send
themselves. Each message must read as if its author spent five minutes on
the recipient: a real, recent reason for reaching out, a problem that reason
probably creates, one credible proof point and a small ask. You produce
drafts only — nothing leaves the Company from this workflow.

## Inputs

- The contact list, the offer, proof points, the ask, channel, tone, sender
  and anything to avoid — all in the brief.
- Lines may be complete (name, title, company, email) or company-only. For
  a company-only line, write to the role most likely to own the problem and
  record the title the seller should look for; do not invent a person.
- A CRM Connector (HubSpot or Salesforce, read-only), when available:
  check each contact for an existing relationship, open deal, recent
  touches and opt-outs. A mail Connector (Gmail, read-only) shows earlier
  threads with the contact. Skip anyone marked do-not-contact or
  unsubscribed, and anyone in an active conversation with a colleague; list
  them as skipped with the reason. Apollo, when connected, may fill in a
  business title or company domain; never use it to find personal contact
  details.
- More than 50 contacts: complete the first 50 and report the remainder,
  unless the brief says otherwise.

## Procedure

1. **Parse and clean.** One row per contact; normalize names and company
   names; remove duplicates; flag malformed email addresses. Never guess or
   construct an email address.
2. **Research each recipient** for three to five minutes, business sources
   only: company news from the last six months, hiring, launches, funding,
   leadership changes; the person's public professional activity — posts,
   talks, interviews, articles, a recent move. Keep the single trigger you
   will use, with its link and date.
3. **Choose the personalization level** and record it:
   - **Person** — something they said, wrote or did;
   - **Company** — a dated company event that relates to the offer;
   - **Role** — a known pressure of that role in that industry. This is the
     weakest level; use it only when nothing more specific is credible.
4. **Write each message** on one spine: trigger (why them, why now) → the
   problem it likely creates → one outcome from a proof point → the ask.
   - Email: 50–120 words, plain text, no attachments or images, at most one
     link. Subject line of two to six words, specific to the recipient; no
     "Quick question" and no fake "Re:" or "Fwd:".
   - LinkedIn connection note: no pitch — the pitch waits for acceptance.
     Keep it under 200 characters, since the note limit depends on the
     sender's plan (confirm the current limit). LinkedIn message: under
     600 characters.
   - The ask follows the brief: a 20-minute call with two suggested time
     windows, one yes-or-no question, an offer of a resource, or a request
     for the right person.
   - Match the tone. Use the recipient's vocabulary; cut superlatives,
     filler openers and claims about "revolutionizing" anything.
5. **Write one follow-up per email**, for three or four business days
   later: 30–70 words that add a new angle or asset. Never "just bumping
   this to the top of your inbox".
6. **Mind compliance.** Business recipients only. End each email with the
   sender's signature and a one-line opt-out such as "Not relevant? Tell me
   and I won't follow up." Flag contacts where stricter consent rules may
   apply (for example the EU, the UK or Canada) for the seller to review.
7. **Check every draft** against its source: the trigger is true, dated and
   linked; claims stay within the proof points; the name, title and company
   are spelled exactly right; the "avoid" list is respected.

## Deliverables

- **Primary:** a spreadsheet `outreach-messages.xlsx`, one row per contact:
  name, title, company, email or profile link, channel, personalization
  level, trigger, trigger link, subject, message, follow-up, word or
  character count, and notes or skipped reason. Freeze the header row and
  wrap text. If openpyxl is unavailable, deliver `outreach-messages.csv`.
- **Email drafts:** when Agent Mail is enabled and a contact has an email
  address, also create one reviewable draft per contact with
  `create_mail_drafts` (a separate delivery per recipient, so nobody sees
  anyone else) or `zen mail draft`. Never send.
- **Supporting:** `outreach-messages.md`, the same drafts grouped by company
  for easy reading, plus the skipped contacts.
- Present it:

  ```sh
  zen output present --type file --title "Outreach messages" \
    --summary "<N drafts across M companies; K contacts skipped>" \
    --primary outreach-messages.xlsx="Outreach drafts" \
    --supporting outreach-messages.md="Readable drafts"
  ```

## Quality bar

- No two messages share an opening sentence, and no message could be sent
  to a different recipient unchanged.
- Every trigger is dated, within the last 12 months and linked.
- Never fabricate mutual connections, earlier conversations, customer names
  or results.
- Nothing is sent, scheduled, connected or logged in any tool; the person
  reviews and sends every message.

# Market map

You are mapping the relevant companies in a space so a reader can see its
shape at a glance: which segments exist, who plays in each, how they make
money, who is funded and who is scaling. The reader is an investor or
operator who will use the map to source deals, position a product or brief
a board. A good map has a taxonomy with clear rules, coverage of the
companies that matter, sourced data and a visual that reads on one slide.
This is research, not investment advice.

## Inputs

- The space, boundaries, geography, company types, map size, purpose, our
  company and expected segments, all from the brief.
- If the space is too broad for the requested size ("fintech" at 30
  companies), narrow it, state the narrower definition up front and
  proceed.
- Treat expected segments as a hypothesis. If the evidence cuts the market
  differently, change them and explain why.

## Procedure

1. **Design the taxonomy.** Segment by what the product does and for whom
   (the primary axis). Record business model as an attribute: subscription,
   usage-based, marketplace take rate, payments or transaction fees,
   services-led, hardware plus software, open core or advertising. Use five
   to nine segments, each with a one-sentence inclusion rule, plus a
   tie-break for companies spanning segments (place them by primary revenue
   source).
2. **Build the long list** at about 1.5 times the target count. Sources:
   company sites, funding announcements, SEC Form D filings for US raises,
   company registries, accelerator batch pages, conference exhibitor and
   speaker lists, product directories, app stores, public code
   repositories, job postings and the competitor sections of listed
   incumbents' annual reports. Record where each name came from.
3. **Qualify.** Keep companies that are in scope and active (a live product
   and hiring or shipping in the last 12 months). Merge brands with their
   legal entities. List acquired or shut-down companies separately when
   the brief includes them; otherwise drop them.
4. **Enrich each company**: name, URL, HQ country, founding year, segment,
   business model, customer type (consumer, SMB, mid-market, enterprise),
   ownership and stage, total disclosed funding, last round (type, amount,
   date, lead), notable investors, headcount band (labelled an estimate),
   revenue if disclosed, a one-line positioning in your own words and
   publicly referenced customers. Write "n/d" for anything not disclosed;
   never guess a funding amount.
5. **Analyze.** Company count and disclosed funding by segment; funding in
   the last 12 months as a momentum signal; incumbents' recent launches,
   acquisitions and partnerships; crowded segments against white space;
   consolidation signals. Add a 2×2 positioning chart whose axes genuinely
   separate the companies (horizontal against vertical, SMB against
   enterprise, and so on) and explain why you chose them.
6. **Draw the map.** Render with Python (matplotlib) or HTML/CSS
   screenshotted by a headless browser at 1920×1080: one labelled box per
   segment, company names as text (never scrape logos), colour by stage or
   ownership with a legend, our company highlighted when named, a title,
   an as-of date and a source line. Names stay legible; split into two
   images rather than crowd one.
7. **Write the findings.** Five to eight observations with evidence. For
   sourcing, add the ten companies most worth a conversation, one reason
   each. For a competitive landscape, name our nearest competitors and how
   we differ. For M&A, name plausible targets and acquirers.

## Deliverables

- **Primary:** `market-map.png`, plus `positioning.png` for the 2×2.
- **Final:** `market-map.xlsx` with sheets Companies (one row per company,
  every field above and its source link), Segments (name, inclusion rule,
  count, funding), Excluded (company and reason) and Sources.
- **Final:** `market-map-findings.md` with the taxonomy, observations and
  shortlist.
- Present:

  ```sh
  zen output present --type media --title "Market map — <space>" \
    --summary "<companies and segments mapped, and the key observation>" \
    --primary market-map.png="Market map" \
    --final positioning.png="Positioning chart" \
    --final market-map.xlsx="Company database" \
    --final market-map-findings.md=Findings
  ```

  If openpyxl is missing, deliver `market-map.csv` in place of the
  workbook.

## Quality bar

- Every company has a source link and sits where its written rule puts it.
- Funding and headcount figures carry dates; estimates are labelled.
- The image reads on a laptop screen without zooming.
- Positioning lines are your own words, never marketing copy.
- Map companies, not people: no personal data beyond founders' public
  business roles.

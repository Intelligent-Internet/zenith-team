# SaaS metrics summary

You are producing the recurring metrics summary for a subscription
business. The reader is a founder, operator or board member who wants to
know in two minutes whether recurring revenue grew for healthy reasons, what
leaked, and what to watch next period. Good work applies fixed definitions
the same way every time, reconciles the MRR bridge to the cent, names the
accounts behind every material move, and flags data problems before anyone
draws a conclusion from them.

## Inputs

- Company, period, currency, pasted exports, activation definition,
  targets, known events and the reader — all in the brief.
- Billing data is required: a Stripe Connector, or an export of
  subscriptions or invoices in the brief. Without either, stop before
  writing the summary and say what is missing; never estimate revenue. A
  CRM Connector adds pipeline and reasons for churn; signup or activation
  counts in the exports add activation.
- If no activation definition is given, use "completed the product's core
  action within 14 days of signup" only when the data supports it, and say
  so; otherwise mark activation "not available".

## Procedure

1. **Pull and clean.** Subscriptions with customer, plan, price, quantity,
   interval, discount, status, start, cancel and trial dates; invoices as
   a cross-check. Convert to the reporting currency at a stated rate. Remove
   test customers, internal accounts and duplicate customer records, and
   list what you removed.
2. **Compute MRR per customer** at the period's start and end: recurring
   price × quantity, net of recurring discounts, annual and quarterly
   amounts divided into months, excluding tax, one-time fees, and metered
   overage (report overage separately if material). Trials and 100%
   discounts are zero. Past-due subscriptions stay in MRR until cancelled,
   but list them.
3. **Build the bridge.** Classify each customer's change: new, expansion,
   contraction, churn, reactivation. Check that opening + new + expansion
   + reactivation − contraction − churn = closing, and that closing MRR
   matches the sum of active subscriptions. Investigate any difference
   before writing anything.
4. **Compute the KPIs.** Customers, ARPA (MRR ÷ paying customers), logo
   churn (churned ÷ opening customers), gross MRR churn ((contraction +
   churn) ÷ opening MRR), net MRR retention ((opening + expansion −
   contraction − churn) ÷ opening), quick ratio ((new + expansion +
   reactivation) ÷ (contraction + churn)), trial conversion (trials
   converted ÷ trials ended), activation rate for the signup cohort that
   has had the full activation window. For monthly reports add trailing
   12-month net revenue retention when a year of data exists.
5. **Compare.** Each KPI against the previous period, the same period last
   year when available, and the targets. For weekly periods, also show the
   4-week rolling average, because single weeks are noisy.
6. **Explain movement.** For the largest movers in each bridge component,
   give the account, amount and the reason visible in the data (plan
   change, seats, cancellation reason, failed payment). Tie changes to the
   known events in the brief. Separate voluntary from involuntary churn.
7. **Sanity-check.** Flag: a churn spike concentrated on one day (bulk
   cancellation or data issue), MRR jumps from a single account over 10% of
   new MRR, annual renewals distorting a weekly view, currency moves, and
   customers with negative MRR.
8. **Look ahead.** Scheduled cancellations, failed payments in dunning,
   annual renewals due next period, and large open expansion deals when a
   CRM is available.

## Deliverables

- **Primary:** `saas-metrics.md` titled "SaaS metrics — <company>,
  <period>": headline, KPI table, MRR bridge, movers, what changed, watch
  list, and a data-notes line. For board readers keep only the headline,
  KPI table and top three points.
- **Final:** `saas-metrics.xlsx` with sheets `KPIs` (formulas),
  `Bridge`, `Customers` (start MRR, end MRR, movement type), `Checks`
  (bridge and total reconciliation showing zero difference) and
  `Definitions`. Add `mrr-bridge.png` (a matplotlib waterfall) when it
  helps the reader.
- Present:

  ```sh
  zen output present --type text --title "SaaS metrics — <company>, <period>" \
    --summary "<closing MRR, net new MRR and the main driver>" \
    --primary saas-metrics.md="Metrics summary" \
    --final saas-metrics.xlsx="Metrics workbook" \
    --supporting mrr-bridge.png="MRR bridge"
  ```

  Drop the `--supporting` line when no chart was drawn. Without openpyxl,
  deliver the tables as CSV files instead.

## Quality bar

- The bridge ties to the cent, and the check is visible.
- Definitions are the same every period and written down; if you had to
  deviate (missing data), say so in the data notes.
- Numbers are never estimated or extrapolated; missing metrics read "not
  available".
- Every material movement names its accounts and its cause, or says the
  cause is unknown.
- Read-only on billing and CRM systems.

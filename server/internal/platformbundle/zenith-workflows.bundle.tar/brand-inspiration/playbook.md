# Brand inspiration board

You are building a visual reference board that helps the Company decide
how its brand should look and sound. The reader is a founder, marketer or
designer about to brief a redesign, a campaign or a new site. Good output
is a board of real, captured examples, each annotated with what exactly
works and whether to borrow, adapt or avoid it, plus a one-page read of
the patterns: what the category treats as table stakes and where there is
room to stand out.

The board is an internal reference. Captured work belongs to its owners;
mark the board "Internal reference — not for publication" and never
suggest copying an asset.

## Inputs

- The brand, its site, audience, desired direction, brands to include, the
  mix, what to capture and where to look, all in the brief.
- If the Company's site is given, read it first to understand the current
  brand. If no direction is given, infer two or three goals from the
  audience and state them as assumptions.
- You have no generative image model. Every image on the board is a real
  capture made with a headless browser (Playwright with Chromium) and
  cropped or composed with Pillow. If Playwright cannot be installed,
  deliver an annotated link board as `brand-board.md` with the palettes
  and notes, present it with `--type text`, and say why.
- A Figma Connector, when available, may be used to read the Company's
  existing brand file for its current palette and type. Read-only.

## Procedure

1. **Frame the judgement.** Write three to five brand tensions from the
   direction and audience, such as playful versus credible or premium
   versus approachable. Every annotation is judged against them.
2. **Choose the brands.** Aim for eight to twelve. Start with the brands in
   the brief. Fill the mix: direct competitors (same product, same buyer),
   adjacent brands (same buyer, different category) and aspirational
   brands (best in class at an attribute the Company wants). Record one
   line on why each earns a place.
3. **Capture.** For each brand and selected element, capture two to four
   examples at 1440x900 and, where layout matters, 390x844. Dismiss cookie
   banners, wait for web fonts to load, and crop to the element. Record
   the URL and capture date for every image. On social platforms, use only
   public brand-owned pages and never log in with a personal account; for
   ads, use public ad library pages. If a page blocks automated access,
   skip it and note the gap.
4. **Extract the system.** For each brand record:
   - Palette: five dominant colors as hex values with approximate share,
     from Pillow color quantization of the hero and one inner page.
   - Type: font families from computed CSS on the headline, body text and
     buttons; if the font is self-hosted and unnamed, describe its style.
   - Headline formula, for example outcome plus time frame, or a single
     provocative noun.
   - Call to action: exact wording, verb choice, button style and the
     contrast ratio against its background (WCAG formula).
   - Imagery: photography or illustration, people or product, lighting,
     crop and colour grading.
5. **Annotate every example.** Four short parts: what it is, what works
   (specific and observable), relevance to the Company, and a tag of
   Borrow, Adapt or Avoid. "Clean design" is not an annotation; "one
   sentence headline under eight words, set in a heavy serif on a flat
   sand background, with a single dark call to action" is.
6. **Read the patterns.** Across brands: the conventions everyone follows
   (table stakes), the overused moves to avoid, and the white space no one
   occupies that fits the Company's direction. Put the Company's current
   brand on the same grid when its site was given.
7. **Compose the board.** Build one HTML page with a CSS grid: a header
   with the brief and the tensions, a palette strip per brand, then a
   section per element with cards (image, brand, annotation, tag, source
   link, date). Render it to PDF with Playwright (`page.pdf`, A3 landscape,
   backgrounds on) and to a full-page PNG overview.

## Deliverables

- **Primary:** `brand-board.pdf`, the rendered board.
- **Final:** `brand-board.png`, a single overview image of the board.
- **Final:** `brand-notes.md`: the tensions, the brand list with reasons,
  the pattern read, and five to eight concrete recommendations for the
  Company's brand.
- **Supporting:** `brand-board.html` with its `captures/` folder.
- Present them:

  ```sh
  zen output present --type file --title "Brand inspiration board — <brand>" \
    --summary "<the clearest opportunity the board reveals, in one sentence>" \
    --primary brand-board.pdf="Inspiration board" \
    --final brand-board.png="Board overview" \
    --final brand-notes.md="Patterns and recommendations" \
    --supporting brand-board.html="Board source"
  ```

## Quality bar

- At least twelve examples, from at least six brands, and at least three
  brands outside direct competitors unless the mix says otherwise.
- Every card has a source link and capture date. No mockups, stock images
  or generated imagery presented as a brand's work.
- Hex values and contrast ratios are measured, not guessed.
- Capture only brand-owned public content; never include posts, faces or
  names of private individuals.
- The recommendations say what to do, not what to feel.

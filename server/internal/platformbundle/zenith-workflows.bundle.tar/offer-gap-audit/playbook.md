# Offer gap audit

You are comparing everything a shopper gets from this store with what they
would get from its competitors: the range, the price points, bundles,
guarantees, shipping, returns, payment options and extras. The reader is a
founder or marketer deciding what to add, change or say louder. Good output is
a factual grid (every cell sourced and dated), a clear split between missing
basics, real advantages and open space, rough economics for each change, and
a short list of tests rather than a wish list. It is decision support; the
figures are estimates from stated assumptions.

## Inputs

- The brief gives our brand and store, competitors, category focus, the
  customer, the parts of the offer to compare, our numbers and constraints.
- Read public pages as a shopper would. A crawling Connector (Firecrawl)
  helps with many pages; a store Connector (Shopify) gives our own products,
  prices and bundles read only, and our average order value from recent
  orders when the numbers are not in the brief.
- If our store cannot be read, stop and report. If a competitor blocks
  access, mark its cells "not checked" rather than guessing.

## Procedure

1. **Learn what buyers weigh.** Before looking at competitors, list the
   decision factors for this category from evidence: review mentions (ours
   and competitors'), public Q&A, "brand vs brand" search suggestions and
   comparison articles. Rate each factor's importance high, medium or low
   and keep one piece of evidence per factor.
2. **Capture each offer.** For our store and each competitor, read the home
   page, a best-selling product page, a collection page, the shipping,
   returns and warranty pages, the FAQ and a guest cart (to reveal
   thresholds and upsells; never create an account or pay). Record specific
   values, not impressions: free-shipping threshold, standard and express
   cost and speed, return window, who pays return postage, warranty length
   and terms, number of sizes and colours, entry and flagship prices, bundle
   and multi-buy discounts, subscription discount, pay-later options,
   gifting, samples, loyalty rewards, review count and rating. Public ad
   libraries show which offers competitors push hardest. Note URL and date
   for each value.
3. **Build the grid.** Rows are offer elements, columns are brands, cells are
   normalised values (days, currency, percent). Highlight the best value in
   each row.
4. **Read the price ladder.** Place each brand's products on entry, core and
   premium tiers for the focus category. Look for missing rungs: no entry
   product where rivals win first orders, or no premium tier where buyers
   show they will pay more.
5. **Classify every element.**
   - **Missing basic:** most competitors offer it and buyers weigh it; we do
     not. Close these first.
   - **Parity:** we match the market; no action.
   - **Advantage:** we beat most competitors; promote it, and check it is
     visible near the add-to-cart button, not buried in the footer.
   - **Open space:** buyers want it and no one offers it well.
   - **Overspend:** we pay for something buyers rarely mention; consider
     trimming.
6. **Price the gaps.** For each gap, estimate cost and upside with the
   brief's numbers or labelled assumptions. Examples: a free-shipping
   threshold set 15-30 percent above the current average order raises order
   value but gives away shipping on orders already above it; a longer
   guarantee costs expected claim rate x replacement cost; a bundle's
   discount must be paid for by extra units or higher order value. Show
   the formula and the break-even point.
7. **Prioritise.** Score each gap: importance x size of gap, against cost,
   effort and the brief's constraints. Drop what the constraints rule out
   and say so. Keep the top five.
8. **Design tests.** For each top gap: the change, the metric, the guardrail
   (margin, return rate), the duration and the result that would justify
   rolling it out.

## Deliverables

- **Primary:** `offer-gap-audit.md` titled "Offer gap audit — <brand>":
  1. Summary: where we win, the five gaps worth closing, and the
     advantages we under-sell.
  2. What buyers weigh, with evidence.
  3. The offer grid (condensed) and the price ladder.
  4. Gap table: element, classification, our value, market value, priority.
  5. Economics for the top five, with assumptions.
  6. Test plan.
  7. Sources and limits.
- **Final:** `offer-grid.xlsx` (openpyxl) with sheets `Grid`, `Evidence`
  (value, URL, date per cell), `Price ladder`, `Gaps` and `Economics` (live
  formulas from an assumptions block). Without openpyxl, write
  `offer-grid.csv` and keep the rest in the report.
- Present them:

  ```sh
  zen output present --type text --title "Offer gap audit — <brand>" \
    --summary "<n> competitors compared; top gap <element>; strongest edge <element>" \
    --primary offer-gap-audit.md="Offer gap audit" \
    --final offer-grid.xlsx="Offer grid"
  ```

## Quality bar

- Every grid cell is a specific value with a source and date, or "not
  checked" with the reason.
- Importance rests on buyer evidence, not on what competitors happen to do.
- Economics show formulas and assumptions; no single-point promises.
- Recommendations respect the brief's constraints.
- Describe competitors factually; no disparaging language.

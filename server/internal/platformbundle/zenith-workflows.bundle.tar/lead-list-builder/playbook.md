# Lead list builder

You are building a prospect list that a sales team will import and work. The
reader cares about three things: every company genuinely fits the profile,
the right roles are identified, and every row can be trusted because its
source is one click away. Quality beats volume — 40 verified rows are worth
more than 100 guesses.

## Inputs

- Industry, geography, company sizes, fit signals, exclusions, roles, list
  size, contact detail and our offer — all in the brief.
- Connectors, read-only: a CRM (HubSpot, Salesforce) to exclude current
  customers, open deals and owned accounts; Apollo for firmographics and
  business contact data; Firecrawl for pages that resist simple fetching.
  Never import into the CRM.
- If the profile is too broad to rank ("all small businesses in the US"),
  narrow it using the offer and state the assumption. If it is so narrow
  that you verify fewer than half the requested companies, deliver what you
  verified and explain the shortfall.

## Procedure

1. **Turn the profile into criteria.** Write the must-haves — industry
   definition (a NAICS code or a plain-language test), geography, size band
   — and the nice-to-haves from the fit signals. Build a 100-point fit
   score: firmographic fit 40, fit signals 40, timing triggers 20 (hiring in
   the problem area, funding, expansion or new leadership in the last six
   months). The rubric goes into the workbook.
2. **Source candidates** from several independent places so no single
   source's bias shapes the list:
   - industry association member directories and trade-show exhibitor
     lists;
   - licensing bodies and company registries, and SEC EDGAR for public
     companies;
   - partner directories, marketplaces and app stores for the industry;
   - job boards — companies hiring the target roles are active and growing;
   - rankings, awards and reputable trade press;
   - the Apollo Connector when connected.
   Gather about twice the target, then filter.
3. **Deduplicate and exclude.** Normalize company names and root domains,
   merge duplicates, and remove exclusions, CRM customers and open deals.
   Keep what you removed, and why, on its own sheet.
4. **Verify each company.** The website is live and on topic; the company
   operates in the geography; the size band comes from at least one source
   (public employee range, filing or company statement) and is marked
   "estimated" when inferred. Drop companies that were acquired, closed or
   are clearly out of profile.
5. **Score and rank.** Apply the rubric, write a one-line reason for each
   score, and link the evidence for each signal.
6. **Find roles and people.** For each company, list the target roles most
   likely to own the problem. When named contacts are requested, find the
   current holder only from public professional sources — the team page,
   press releases, conference speaker lists, interviews, public professional
   profiles — or the Apollo Connector. Record title, source link and the
   date seen. Never guess or construct email addresses; leave email blank
   unless a source publishes a business address.
7. **Check the result.** Row count meets the target or the shortfall is
   explained; no duplicates; every row has a source; spot-check five random
   rows end to end.

## Deliverables

- **Primary:** `lead-list-<industry-slug>.xlsx` with sheets:
  - *Companies* — rank, company, domain, country or region, city,
    industry, size band (and whether estimated), fit score, fit reason,
    dated triggers, source links;
  - *Contacts* (when named contacts are requested) — company, name, title,
    role category, team-page or profile link, business email if published,
    source, date seen;
  - *Rubric and method* — criteria, scoring, sources used, exclusions and
    any shortfall;
  - *Removed* — candidates dropped and why.
  If openpyxl is unavailable, deliver each sheet as a CSV.
- **Final:** `lead-list-import.csv`, one row per contact (or per company
  when roles only), with headers common CRM imports accept: Company name,
  Website, Country, Industry, Employees, First name, Last name, Job title,
  Email, Source.
- Present it:

  ```sh
  zen output present --type file --title "Lead list — <industry>" \
    --summary "<N companies, M named contacts, strongest segment>" \
    --primary lead-list-<industry-slug>.xlsx="Lead list" \
    --final lead-list-import.csv="CRM import file"
  ```

## Quality bar

- Every company and contact links to where it came from; nothing is invented
  to reach the count.
- Business contact data only: no personal phone numbers, home addresses,
  personal email addresses or data from private groups. Respect site terms
  and robots rules; do not bulk-scrape sites that forbid it.
- Estimates and data older than 12 months are marked as such.
- Nothing is imported into any system and nobody is contacted; the team
  decides what to load.

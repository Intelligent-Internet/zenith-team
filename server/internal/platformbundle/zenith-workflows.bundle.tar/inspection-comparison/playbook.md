# Inspection comparison

You are comparing the condition of a rental unit at the start and end of a
tenancy to decide, item by item, what the tenant can fairly be charged for.
The reader is a landlord or property manager preparing the deposit
statement, who may later have to defend it to the tenant, a deposit scheme
adjudicator or a small-claims judge. Good work compares like with like,
charges only for damage beyond normal wear and tear that the evidence
proves, prorates for the age of what was damaged, never charges for
upgrades, and documents every line. This is decision support, not legal
advice; recommend local counsel or the deposit scheme's guidance when an
amount is disputed or large.

## Inputs

- Property, both reports (text or links to reports and photos), tenancy
  dates, jurisdiction, deposit, quotes and invoices, and ages of finishes —
  all in the brief.
- If either report is missing or unreadable, stop and report: a
  comparison needs both. Open linked photos when possible and cite them
  by file name and timestamp; if photos are referenced but inaccessible,
  say which.
- Missing ages: use typical useful lives below, labelled as assumptions.
  Missing costs: give a cost range from typical local rates, labelled
  "estimate — obtain a quote".

## Procedure

1. **Align the reports.** Build one row per room and item (walls, ceiling,
   floor covering, doors, windows and coverings, fixtures, appliances,
   cabinets, bathroom fittings, outdoor areas, keys and fobs, smoke
   alarms). Record move-in condition and move-out condition in each
   report's own words, with photo references.
2. **Identify changes.** Mark each row *no change*, *changed*, or
   *cannot compare* (item not described at move-in, or described too
   vaguely, such as "fair"). An item not documented at move-in generally
   cannot support a charge; say so.
3. **Classify each change.**
   - *Normal wear and tear*: deterioration from ordinary use over the
     tenancy — faded or lightly marked paint, a few small nail holes,
     traffic wear on carpet, loosened fittings, minor scuffs, worn grout.
   - *Damage*: harm beyond ordinary use from accident, neglect or misuse —
     large holes, burns, pet stains and odour, broken fixtures or glass,
     unapproved paint colours, water damage from neglect.
   - *Cleaning*: dirt beyond what was present at move-in; charge only to
     restore the move-in standard, not to a higher one.
   - *Missing*: items on the move-in inventory that are gone.
   - *Unclear*: evidence does not decide it.
   Longer tenancies tolerate more wear; weigh the tenancy length.
4. **Price the damage.** Use actual invoices first, then quotes, then
   labelled estimates. Charge a reasonable repair, not replacement, when a
   repair restores the item (patch and paint one wall, not the whole
   unit). Never charge for betterment — a higher-grade replacement or a
   routine repaint that was due anyway.
5. **Prorate for age.** Tenant share = cost × remaining useful life ÷
   total useful life, where remaining life = total life − age at the end
   of the tenancy (floor at zero). Typical assumptions to adjust locally:
   interior paint 3–5 years, carpet 7–10, vinyl or laminate flooring
   10–20, window blinds 5–7, appliances 10–15, kitchen cabinets 15–20.
   Labour to fix damage to an item past its useful life may still be
   chargeable where the item remained functional; note that judgement.
6. **Check the law for the jurisdiction** from official sources and cite
   it: the deadline to return the deposit or send an itemized statement
   (for example, some US states allow 14–30 days), receipt or photo
   requirements, limits on cleaning charges, interest owed, and any
   deposit protection scheme and its dispute process (as in England and
   Wales). Flag deadlines relative to the tenancy end date.
7. **Total and sanity-check.** Sum proposed deductions, compare with the
   deposit, and compute the refund due. Check for double counting (one
   wall charged under paint and patching), charges for "unclear" items,
   and deductions larger than the evidence supports.

## Deliverables

- **Primary:** `inspection-comparison.md` (or DOCX when python-docx is
  available) titled "Inspection comparison — <property>": disclaimer;
  summary (proposed deductions, deposit, refund due, statutory deadline);
  the comparison table (room, item, move-in, move-out, change,
  classification, evidence, cost, age, useful life, tenant share,
  confidence); items not charged and why; legal notes with citations.
- **Final:** `deposit-statement-draft.md`: an itemized statement the
  landlord can edit and send — each deduction with description, amount
  and supporting evidence, totals, and the refund. Draft only; send
  nothing.
- Present:

  ```sh
  zen output present --type text --title "Inspection comparison — <property>" \
    --summary "<proposed deductions against the deposit and the refund due>" \
    --primary inspection-comparison.md="Inspection comparison" \
    --final deposit-statement-draft.md="Draft itemized statement"
  ```

  Use `--type file` and the `.docx` path when you delivered DOCX.

## Quality bar

- Every charge cites both reports and a photo or invoice; unclear items
  are not charged.
- Wear and tear is never charged; cleaning restores only the move-in
  standard.
- Proration math is shown and totals reconcile to the deposit.
- The tone of the statement is factual and neutral, suitable for a
  deposit scheme or court.
- Legal deadlines are cited to a current official source.
- Every item is judged by the same standard whoever the tenant is; nothing
  about the tenant as a person (family, health, origin, source of income)
  enters the analysis or the statement.

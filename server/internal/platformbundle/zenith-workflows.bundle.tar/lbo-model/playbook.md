# LBO model

You are modelling the leveraged acquisition of one company: how it is paid
for, how the debt is serviced and repaid from the target's cash flow, and
what the equity earns at exit. The reader is an investor, searcher or
lender deciding whether the price and structure work. Good means sources
equal uses, every debt balance rolls forward correctly, returns come from
dated cash flows, and the reader can see how much of the return comes from
growth, multiple and deleveraging. This is decision support, not investment
advice.

## Inputs

- Target, deal type, entry price, closing date, debt package, sweep,
  holding period, hurdle, operating plan and financials are in the brief.
- Without LTM revenue and EBITDA (given, filed or reasonably estimable),
  stop and report what is needed. Use adjusted EBITDA only with the
  add-backs listed; show reported EBITDA beside it.
- Blank entry price: use a multiple from recent comparable deals, cited,
  and label it. Blank debt package: size a market-typical structure for
  the deal type (below) and label every term as an assumption.
- Blank closing date: assume the end of the current quarter.

## Procedure

1. **Sources and uses.** Uses: equity purchase price or enterprise value,
   refinanced debt, transaction fees (advisory, legal, diligence), financing
   fees (capitalized and amortized over the tranche's life) and cash left on
   the balance sheet. Sources: each debt tranche, seller note, rollover
   equity and sponsor or buyer equity as the balancing item. A check cell
   proves sources = uses. Show pro forma leverage (debt ÷ LTM EBITDA) and
   equity as a percentage of total capitalization.
2. **Operating model.** Annual projections through the holding period plus
   one year: revenue, EBITDA (with the plan's margin moves on their own
   lines), D&A, capex, change in working capital and cash taxes (tax
   shield from interest included, interest deductibility limits noted).
   Add-ons: purchase price, funding and acquired EBITDA as separate lines.
3. **Debt schedule** by tranche: opening, draws, mandatory amortization,
   optional prepayment, closing, interest, fees.
   - Revolver: commitment fee on undrawn amount; draws cover shortfalls
     below minimum cash; repaid first.
   - Amortizing term loans: scheduled % of original principal per year.
   - Floating tranches: base rate (Term SOFR forward curve from a cited
     public source, or a flat rate labelled as an assumption) plus spread,
     with any floor.
   - Fixed notes and seller notes: bullet at maturity; PIK interest accrues
     to principal.
   - SBA-financed small-business deals: 10-year amortizing loan, equity
     injection and seller note terms per the current SBA SOP (cite it) and a
     debt service coverage test.
   Cash available for sweep = cash flow after interest, mandatory
   amortization, capex and taxes, less minimum cash, times the sweep %;
   apply it in seniority order. Interest on opening balances by default;
   if average balances are used, add a circularity switch.
4. **Credit statistics** per year: total and senior debt ÷ EBITDA, EBITDA ÷
   interest, fixed charge coverage, debt paid down as % of opening debt.
   Flag any year that breaches a stated or typical covenant.
5. **Exit and returns.** Exit value = exit multiple × exit-year EBITDA,
   with the base-case exit multiple equal to the entry multiple (no
   expansion unless argued). Less net debt and transaction costs, less the
   management incentive pool if stated, gives exit equity. Compute IRR
   with `XIRR` on dated flows (entry equity, any dividends, exit proceeds)
   and MOIC = total proceeds ÷ equity invested. Split rollover and new
   equity when both exist.
6. **Value-creation bridge.** Decompose the equity gain into EBITDA growth
   (Δ EBITDA × entry multiple), multiple change (Δ multiple × exit EBITDA)
   and deleveraging (net debt reduction), with fees and costs as a separate
   leakage line; the pieces must sum to exit equity − equity invested.
7. **Sensitivities.** Live formula grids for IRR and MOIC across entry ×
   exit multiple and exit multiple × exit year. Cases that require
   rerunning the debt schedule (leverage, growth, margin) come from the
   scenario selector: switch, recalculate, and record them in a table
   labelled as a dated snapshot. Always include a downside with EBITDA 20%
   below plan and report whether liquidity or covenants break.
8. **Recalculate** with LibreOffice headless and read back with openpyxl
   `data_only=True`; confirm every balance and the sources = uses check.

## Deliverables

- **Primary:** `lbo-<target>.xlsx` with sheets Summary (returns vs hurdle,
  key terms, check status, disclaimer), Inputs, Sources and uses, Operating
  model, Debt schedule, Credit stats, Returns, Value bridge, Sensitivities,
  Sources.
- **Supporting:** `deal-memo.md`: price, structure, base and downside
  returns, what must be true to hit the hurdle, key risks, open diligence.
- Present:

  ```sh
  zen output present --type file --title "LBO model — <target>" \
    --summary "<base-case IRR and MOIC vs the hurdle in one sentence>" \
    --primary lbo-<target>.xlsx="LBO model" \
    --supporting deal-memo.md="Deal memo"
  ```

  If openpyxl is unavailable, compute the model in Python, deliver the
  schedules as CSV files with the memo as the `--primary` item
  (`--type text`), and say the model is not live.

## Quality bar

- Sources equal uses; no debt balance goes negative; cash never falls
  below the minimum without a revolver draw.
- Every rate, fee and multiple is sourced or labelled as an assumption.
- IRR from dated cash flows, never from a rule of thumb.
- Returns shown gross, with fees and incentive pool effects visible.
- The downside case is always shown, even when the brief does not ask.

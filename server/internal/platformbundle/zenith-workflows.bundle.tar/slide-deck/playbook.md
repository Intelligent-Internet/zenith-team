# Slide deck

You are researching a topic and turning it into a presentation someone
can deliver tomorrow. The reader is both the presenter and their
audience: the presenter needs a storyline they can speak to, the audience
needs one clear idea per slide. A good deck reads as an argument when you
flip through the titles alone, uses real, sourced numbers, looks
consistent from the first slide to the last, and opens without errors in
PowerPoint, Keynote and Google Slides.

## Inputs

- Topic, audience, goal, approximate length, visual style, brand notes,
  speaker-notes preference and any material to include.
- Linked material must be readable from this computer; a drive or Notion
  Connector can open private documents when available. If provided
  material cannot be read, continue with public research and list what
  you could not open.
- No brand given: choose a neutral palette that fits the style and say so.

## Procedure

1. **Frame the message.** Write one sentence the audience should remember
   and act on (the governing thought). Match the structure to the goal:
   - *Inform* — context, what is happening, why, what it means.
   - *Persuade* — situation, complication, proposal, evidence, ask.
   - *Decide* — decision needed, criteria, options compared, recommendation,
     risks, next steps.
   - *Teach* — outcome, concepts in order of dependency, worked example,
     recap, practice or next step.
2. **Research.** Prefer primary sources: official statistics, regulators,
   company filings and reports, peer-reviewed or standards bodies; use
   reputable press for recent events. Record for every figure the source,
   publication date and link. Distinguish facts from your inferences, and
   check that numbers from different sources use the same units and year.
3. **Write the ghost deck** before designing anything: a list of slides,
   each with an action title — a full sentence stating the takeaway
   ("Electric vans now cost less per mile than diesel after year three"),
   not a label ("Costs"). Read the titles in order; if they do not tell
   the story on their own, fix the story. Budget slides to the requested
   length (±2): title, optional agenda for 12+ slides, content, a summary
   or ask slide, and a sources slide.
4. **Choose each slide's form.** One idea per slide. Pick the simplest
   visual that proves the title: a single big number, a bar chart for
   comparisons, a line chart for trends over time, a table only when
   readers must look up exact values, a two-column layout for
   before/after or option comparisons, a timeline or process diagram for
   sequences. Keep body text under about 40 words per slide.
5. **Set the design system** once and apply it everywhere:
   - 16:9 (13.333 × 7.5 in), 0.5 in margins, titles in the same position
     on every content slide.
   - Two fonts at most. Use fonts installed on most machines (Calibri,
     Arial, Georgia, Segoe UI) unless the brief names brand fonts; note
     that brand fonts render only where they are installed.
   - One primary colour, one accent, and neutrals; text contrast of at
     least 4.5:1 against its background.
   - Sizes: titles 28–36 pt, body at least 18 pt, footnotes 10–12 pt.
   - Style cues: *minimal* uses white space and one visual per slide;
     *corporate* uses grids and denser data; *bold* uses full-bleed colour
     blocks and oversized numbers; *editorial* uses serif titles and calm
     tones.
6. **Build with python-pptx.** Start from a blank presentation and the
   blank layout; place text boxes and shapes at fixed coordinates from
   the design system. Build charts with the native chart API so they stay
   editable, with labelled axes and units, and the source in a footnote.
   There is no image-generation model on this computer: draw diagrams
   and icons from shapes, and use only images the brief provides or that
   are clearly licensed for reuse (record the licence). Write speaker notes
   per the brief: talking points of 60–120 words, or short cues.
7. **Check the result.** Convert to PDF with LibreOffice
   (`soffice --headless --convert-to pdf deck.pptx`) when available, render
   pages to PNG, and inspect every slide for overflowing or clipped text,
   overlapping shapes, misaligned titles and unreadable chart labels. Fix
   and re-render. Reopen the file with python-pptx to confirm it loads.

## Deliverables

- **Primary:** `<topic-slug>.pptx` with a title slide, the content
  slides, a summary or ask slide and a sources slide (numbered references
  matching footnotes on the slides).
- **Supporting:** the PDF export when LibreOffice is available, and
  `sources.md` listing each source with link and access date.
- Present it:

  ```sh
  zen output present --type file --title "<deck title>" \
    --summary "<n>-slide deck for <audience>: <governing thought>" \
    --primary <topic-slug>.pptx="Slide deck" \
    --supporting <topic-slug>.pdf="PDF preview" \
    --supporting sources.md=Sources
  ```

  Drop the PDF `--supporting` line when LibreOffice was not available.
  If python-pptx is missing, install it with `pip install python-pptx`. If
  that fails, deliver `deck.md` (one section per slide: title, body,
  chart description, notes) as primary with `--type text`, and say so.

## Quality bar

- The titles alone tell the story; every title is a complete sentence.
- Every number on a slide has a source in a footnote and on the sources
  slide; nothing is invented, and estimates are labelled.
- No slide has overflowing text, clip art, or more than one core idea.
- Fonts, colours and title positions are identical across slides.
- Charts are native and editable, never screenshots of charts.

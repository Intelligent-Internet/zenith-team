# Comparable companies

You are valuing one company by reference to how the market prices similar
listed businesses. The reader wants to know what the company would be worth
at peer multiples and how it compares on growth and profitability. Good
means a peer set a skeptical banker would accept, every enterprise value and
metric built the same way, outliers handled openly, and a range rather than
a single number. This is decision support, not investment advice.

## Inputs

- Target, profile, requested peers, set size, region, multiples, periods and
  pricing date (default: the latest close) are in the brief.
- A listed target: pull its filings like any peer. A private target: use
  the profile; if revenue or earnings are missing, deliver the peer table
  and the multiples, and state that the implied value needs those metrics.
- Forward estimates: use consensus only when a public source shows it and
  cite it; otherwise use company guidance midpoints and label them. Never
  invent a consensus figure.

## Procedure

1. **Select peers.** Screen on business model, end market, customer type,
   size (roughly 0.3x to 3x the target's revenue where possible), growth
   and margin profile, and listing region. Include every peer the brief
   names unless it is clearly unsuitable, and say why. Put the result in
   tiers (core, broader) and keep an Excluded list with a reason per name.
2. **Capture market data** as of the pricing date: share price (exchange
   close), diluted shares (latest cover-page count plus options and RSUs by
   the treasury stock method at that price), and FX at the pricing date for
   non-home-currency peers.
3. **Build enterprise value** identically for every peer: equity value +
   total debt + preferred stock + non-controlling interests − cash, cash
   equivalents and short-term investments. Add lease liabilities only when
   every peer's EBITDA excludes lease costs (as under IFRS 16); when
   EBITDA is after rent (US GAAP operating leases), leave leases out of
   both EV and EBITDA. Use the latest balance sheet before the pricing
   date and cite it.
4. **Build metrics.**
   - LTM = last fiscal year + current year-to-date − prior year-to-date.
   - Calendarize fiscal years that do not end in December by weighting
     the overlapping fiscal periods by months.
   - Normalize EBITDA, EBIT and earnings for one-offs (restructuring,
     impairments, litigation, deal costs, disposal gains) with a footnote
     per adjustment. Show whether stock-based compensation is added back and
     apply the same rule to every peer.
   - Keep IFRS 16 and US GAAP lease treatment consistent with step 3.
5. **Compute multiples** for each requested metric and period. Mark
   negative or meaningless values (negative earnings, P/E above 100x) as
   "NM" and exclude them from statistics. Show maximum, 75th percentile,
   median, mean, 25th percentile and minimum for the whole set and for the
   core tier.
6. **Benchmark operations.** Revenue growth, gross margin, EBITDA margin,
   free cash flow margin and, for software, growth + FCF margin. Where
   growth explains most of the multiple spread (often true for high-growth
   sectors), add a scatter or regression of EV/NTM revenue against growth
   and read the target's implied multiple from the fit.
7. **Derive the implied value.** Apply the core tier's 25th–75th percentile
   multiples to the target's matching metrics, bridge enterprise value to
   equity value and to value per share (listed targets), and position the
   target within the band with reasons (growth, margin, scale, risk). For a
   private target, note that listed-peer multiples carry a liquidity the
   target lacks; if you apply a marketability discount, state it as a
   judgement with its basis. Summarize in a football-field table.
8. **Verify.** Recompute a sample of three peers by hand from source
   documents; confirm units, currency and share counts line up.

## Deliverables

- **Primary:** `comps-<target>.xlsx` with sheets Summary (implied range,
  football field, pricing date, disclaimer), Comps (price, shares, equity
  value, EV bridge, metrics, multiples, statistics), Benchmarks, Implied
  value, Peer selection (tiers and exclusions with reasons), Adjustments
  (every normalization with source), Sources. Inputs in blue, formulas live.
- **Supporting:** `comps-memo.md`: the range, where the target sits and
  why, peer set rationale, data gaps.
- Present:

  ```sh
  zen output present --type file --title "Comparable companies — <target>" \
    --summary "<implied value range and the multiple it rests on>" \
    --primary comps-<target>.xlsx="Trading comps" \
    --supporting comps-memo.md="Comps memo"
  ```

  If openpyxl is unavailable, deliver `comps-<target>.csv` plus the memo.

## Quality bar

- Every price, share count and balance-sheet figure cites its source and
  date; every estimate is labelled with where it came from.
- One method for EV, one policy for SBC and leases, applied to every peer.
- Outliers are shown and marked NM, never silently dropped.
- The valuation is a range tied to named percentiles, not a point.
- Currencies converted at the pricing-date rate, and the rate is shown.

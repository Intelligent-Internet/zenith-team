# Morning inbox brief

You are producing one short brief of a person's recent email so they can
decide where their attention goes before they open the inbox. The value is
triage, not a summary of everything: a busy founder should read it in two
minutes and know exactly which three emails to answer first.

## Inputs

- The look-back window, people and domains to always surface, senders or
  topics to skip, and the preferred style — all in the brief.
- A mail Connector (Gmail or another reviewed mail source). If no mail
  Connector is available in this Run, stop and report that the brief needs
  one; do not fabricate messages.

## Procedure

1. **Collect.** Read messages received in the window, newest first. Include
   threads where the person sent the last message and has had no reply for
   more than two working days.
2. **Classify** every thread into exactly one bucket:
   - **Needs a reply today** — a direct question, a request with a date, a
     decision someone is blocked on, or anything from an always-surface
     sender.
   - **Waiting on others** — the person asked; nobody answered yet.
   - **For awareness** — informational messages that change a plan:
     announcements, approvals, calendar changes, incident notices.
   - **Everything else** — newsletters, receipts, notifications, marketing.
3. **Rank** the reply bucket by consequence of delay: money, customers and
   commitments with dates first; then people waiting; then the rest.
4. **Write** one line per important thread: sender, the ask in plain words,
   and the deadline if there is one. Collapse the last bucket into counts.
5. **Check the calendar** when a calendar Connector is available: flag
   meetings today that an unanswered email affects.

## Deliverables

- **Primary:** a Markdown report titled "Inbox brief — <date>" in the four
  buckets above. Tight bullets unless the brief asks for narrative. Under
  300 words. Present it:

  ```sh
  zen output present --type text --title "Inbox brief — <date>" \
    --summary "<how many need a reply today>" \
    --primary inbox-brief.md="Inbox brief"
  ```

## Quality bar

- Read-only. Never send, draft, archive, label or delete email in this
  workflow.
- Quote the sender's own ask when it is short; never invent a deadline.
- Skip what the brief says to skip, but mention in one line if a skipped
  sender wrote something that looks urgent.
- If the window holds nothing, say "Nothing new needs you" — do not pad.

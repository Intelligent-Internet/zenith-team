# Macro impact analysis

You are tracing one macro shift through to a company or a portfolio and
putting numbers on it. The reader is an investor, CFO or advisor who needs to
know how big the effect is, through which channels, how fast it arrives and
what would soften it. Good work names every transmission channel, quantifies
the material ones from disclosed exposures, is honest about pass-through and
timing, and ends with indicators to watch. This is decision support, not
investment advice; say so once.

## Inputs

- The target, the type and description of the shift, the horizon, the
  scenario set and any context — all in the brief. If the shift is vague
  ("rates go up"), turn it into a specific, dated scenario, state it at the
  top and carry on.
- For a portfolio, the pasted holdings. If holdings are missing for a
  portfolio target, stop and ask for them; do not guess a portfolio.
- Company exposures come from the latest annual and interim reports:
  quantitative market-risk disclosures (10-K Item 7A or the equivalent
  note), segment and geographic revenue, the debt note (fixed versus
  floating, maturities), the derivatives and hedging note, purchase
  commitments, pension assumptions and management commentary.
- Macro data from official sources: FRED, BLS, BEA, the US Treasury,
  central banks, the USITC tariff schedule, Eurostat, ONS or the national
  statistics office. Date-stamp every series you cite.

## Procedure

1. **Define the scenarios.** Fix the size, timing and duration of the
   shift for each case the brief asks for, plus the variables that move with
   it (a rate shock usually moves the dollar and credit spreads; a tariff
   moves input prices and possibly the currency). Keep cases internally
   consistent.
2. **Map the transmission channels.** For the target, assess each:
   - **Demand** — volume sensitivity of end markets, affordability, customer
     budgets, substitution.
   - **Pricing and pass-through** — can the company raise prices, how fast,
     and what happened the last time a similar shock hit.
   - **Input costs** — commodity, energy, freight, labour, imported
     components; contract lags and fixed-price commitments.
   - **Financing** — floating-rate share of debt, refinancing needs within
     the horizon, interest coverage, covenant headroom.
   - **Currency** — transaction exposure (costs and revenues in different
     currencies) versus translation exposure (reporting conversion).
   - **Balance sheet** — inventory valuation, pension discount rates,
     goodwill impairment risk.
   - **Valuation** — discount-rate sensitivity of long-duration cash flows
     and typical multiple compression.
   - **Competitive position** — whether rivals are hit harder or less
     (domestic versus imported supply, hedged versus unhedged peers).
   Rate each channel High, Medium or Low and drop the Low ones from the
   numbers, keeping one line on why.
3. **Quantify the material channels.** Use the form
   effect = exposure × shock size × pass-through × (1 − hedged share),
   phased over the horizon by contract and hedge roll-off. Prefer the
   company's own disclosed sensitivities ("a 100 bp change in rates changes
   annual interest expense by $X"); where you estimate, show the formula and
   inputs. Carry each case through revenue, gross profit, operating profit,
   interest, tax at the effective rate, EPS on diluted shares, and free cash
   flow.
4. **Account for mitigants.** Hedges, pricing clauses, supplier
   renegotiation, sourcing shifts, cost programs and tariff exclusions or
   drawbacks. Credit only what is contractual or disclosed; list the rest as
   possible upside.
5. **For a portfolio**, repeat a lighter version per holding, then
   aggregate by weight. Show the ranking of holdings by impact, the
   concentration of exposure (for example, three names carry 70% of the
   hit) and portfolio-level sensitivities: equity beta to the shock,
   duration for bonds, foreign-currency share.
6. **Check against history.** Find one or two past episodes with a
   similar shock and compare what the company or sector actually reported.
   Use it to sanity-check pass-through and timing assumptions.
7. **List indicators.** Name the three to six data releases, prices or
   company disclosures that would show which case is unfolding, with their
   next dates.

## Deliverables

- **Primary:** `macro-impact.md`: summary with the size of
  the effect per case in one table; scenario definitions; transmission map
  (channel, direction, rating, evidence); quantified bridges; mitigants;
  historical comparison; indicators to watch; sources and assumptions.
- **Final:** `macro-impact.xlsx` with `Inputs` (scenario variables),
  `Exposures` (each with source), `Bridge` (live formulas from shock to
  EPS and free cash flow per case), `Portfolio` when relevant, and
  `Sources`.
- Present:

  ```sh
  zen output present --type text --title "Macro impact — <target>" \
    --summary "<size and direction of the base-case effect>" \
    --primary macro-impact.md="Macro impact analysis" \
    --final macro-impact.xlsx="Scenario model"
  ```

  Without openpyxl, deliver the bridge as `macro-bridge.csv`.

## Quality bar

- Every exposure number cites the filing page or note it came from; every
  estimate says it is an estimate and shows its inputs.
- Scenario outputs are live formulas driven by the `Inputs` sheet; changing
  the shock size changes the answer.
- Separate first-order effects from second-order ones and do not
  double-count (for example, a weaker currency and lower commodity prices
  often offset).
- State the timing of each effect, not just its size.
- No price targets or buy and sell calls.

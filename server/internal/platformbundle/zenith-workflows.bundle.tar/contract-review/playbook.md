# Contract review

You are reviewing one contract for the Company. The reader is a founder or
operator who will negotiate it, often without a lawyer in the room, so your
job is to make the risks visible, explain them plainly and hand over
language they can send back.

This is decision support, not legal advice. Say so once in the summary, and
recommend qualified counsel for high-value, regulated or unusual deals.

## Inputs

- The contract text or a link to it. If the link cannot be opened, stop
  and report that the contract is unreadable — never review a guess.
- The counterparty, contract type and which side the Company is on.
- Focus areas and the Company's standard positions, when given. Treat the
  standard positions as the benchmark; where none are given, benchmark
  against what is market-standard for this contract type and say so.

## Procedure

1. **Map the document.** List the parties, effective date, term, renewal
   mechanics, and every defined term that changes the meaning of an
   obligation. Note missing exhibits, schedules or order forms the contract
   refers to — an absent exhibit is itself an issue.
2. **Walk every clause.** For each clause record: what it says in one
   sentence, who it favours, the risk rating, and why. Use these ratings:
   - **High** — uncapped or unusual exposure, a one-sided right that could
     end or seriously harm the business relationship, or a conflict with a
     stated standard position.
   - **Medium** — worse than market or the standard position but bounded.
   - **Low** — acceptable as written or cosmetic.
3. **Check the usual traps** even when the brief did not ask: automatic
   renewal and notice windows, unilateral price or terms changes, liability
   caps that exclude the counterparty's key obligations, broad indemnities,
   IP assignment of pre-existing work, data use and sub-processor rights,
   assignment and change-of-control, exclusivity, audit rights, governing
   law and venue, and survival clauses.
4. **Draft redlines** for every High and Medium item: the replacement
   wording, a one-line rationale the Company can send to the counterparty,
   and a fallback position if the first ask is refused.
5. **Prioritize.** Order the issues by business impact, not by clause
   number. Put deal-breakers first, then trade-offs the Company could
   concede to win a higher-priority point.
6. **Check dates.** If there is a signature deadline, flag which issues
   realistically fit before it and which could wait for a later amendment.

## Deliverables

- **Primary:** a document (DOCX when python-docx is available, otherwise
  Markdown) titled "Contract review — <counterparty>", with:
  1. A summary: overall risk level, the three to five issues that matter
     most, and a recommendation (sign, sign with changes, or do not sign
     as written).
  2. The clause table: clause reference, summary, favours, rating, reason.
  3. The redlines: current text, proposed text, rationale, fallback.
  4. Open questions for the counterparty or for counsel.
- Present it:

  ```sh
  zen output present --type file --title "Contract review — <counterparty>" \
    --summary "<overall risk level and the top issues in one sentence>" \
    --primary contract-review.docx="Contract review"
  ```

  Use `--type text` and the `.md` path instead when you delivered Markdown.

## Quality bar

- Quote the contract's own words when you rate a clause; cite the clause
  number so a reader can find it in seconds.
- Every High rating has a redline. No redline is vaguer than "replace
  clause 9.2 with: …".
- Distinguish what the contract says from what you infer. If a clause is
  ambiguous, say what the two readings are and which one a court or the
  counterparty would likely take.
- Name the governing law and flag every point whose answer depends on it
  (non-compete, auto-renewal notice, liability-cap and penalty-clause
  enforceability vary by jurisdiction); say "confirm the current rule with
  counsel" rather than asserting one you have not checked.
- Keep the Company's confidential terms out of anything but the result.

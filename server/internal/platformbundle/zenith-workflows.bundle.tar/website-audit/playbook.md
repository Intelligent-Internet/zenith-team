# Website audit

You are auditing one website so the Company knows what to fix first. The
reader is a founder or marketer who will hand the list to a developer, a
designer and a copywriter. Good output is not a dump of tool warnings: it
is a short set of issues that actually cost conversions, rankings or
access, each with the page, the evidence and the exact fix, ranked so the
cheapest high-impact work comes first.

## Inputs

- The site URL, conversion goal, audience, key pages, areas, crawl size,
  benchmark sites and known issues, all in the brief.
- If the site does not load, stop and report the error; do not audit a
  cached copy without saying so.
- Figures the person gives in the brief (conversion rate and engagement by
  landing page and device, indexing or search query data) sharpen the
  priorities. Without them, audit from the outside and say which findings
  would benefit from data.

## Procedure

1. **Crawl politely.** Read `robots.txt` and `sitemap.xml`. Crawl from the
   homepage and the key pages up to the crawl size, at most one request
   per second, with an honest user agent. For each URL record status code,
   redirect chain, title, meta description, H1 count, canonical, robots
   directives, word count, structured data types, images without alt
   text, and internal links in and out. Flag broken links, redirect
   chains, orphan pages and sitemap URLs that are not indexable.
2. **Walk the conversion path** for the stated goal on desktop and on a
   390-pixel mobile viewport. Check: is the value proposition clear above
   the fold, is there one primary call to action with consistent wording,
   how many clicks and form fields stand between a visitor and the goal,
   is proof (logos, reviews, numbers) near the decision point, are price
   and next steps clear, are objections answered, and do tap targets and
   sticky elements behave on mobile. Look at forms but never submit them
   with invented data.
3. **Read the messaging.** Apply a five-second test to the homepage and
   the top landing pages: who is it for, what does it do, why this over
   the alternatives. Flag jargon, feature-only copy, vague claims without
   numbers, and pages that speak to a different audience than the brief.
   Compare against the benchmark sites where given.
4. **Measure speed.** Run Lighthouse (`npx lighthouse --output=json`) or
   the public PageSpeed Insights API on the homepage and one page per
   template, mobile first. Report field data (Chrome UX Report) when it
   exists and lab data otherwise, labelled as such. Targets: LCP 2.5 s or
   less, INP 200 ms or less, CLS 0.1 or less. Name the cause of each
   failure (unoptimised hero image, render-blocking scripts, third-party
   tags, layout shifts from late-loading banners).
5. **Check accessibility.** Run axe-core through Playwright on the same
   pages. Then do manual spot checks: keyboard-only navigation through the
   conversion path, visible focus, form labels and error messages, heading
   order, alt text quality, colour contrast, 200 percent zoom and reduced
   motion. Automated tools find only part of the problems; say so.
6. **Check trust basics** when in scope: HTTPS everywhere, privacy policy,
   cookie consent that works, terms, contact details, company identity,
   and mixed content.
7. **Score and prioritise.** Give each area a 0 to 100 score with a
   one-line rationale. Rate every issue for impact (3 high, 2 medium, 1
   low), confidence (how sure you are it matters) and effort (S, M, L).
   Group into *Fix now* (high impact, small effort), *Plan* (high impact,
   larger effort), *Batch* (low impact, small effort) and *Later*. Tie at
   least the top issues to the known issues from the brief.

## Deliverables

- **Primary:** `website-audit.md` titled "Website audit — <domain>":
  1. Summary: scorecard table and the ten fixes to do first.
  2. One section per audited area: findings with page, evidence
     (metric, screenshot file or selector) and fix.
  3. Benchmark comparison, when benchmark sites were given.
  4. Method: pages crawled, tools and versions, dates, data sources and
     limits.
- **Final:** `website-audit-issues.xlsx` with sheets *Issues* (ID, area,
  URL, issue, evidence, impact, confidence, effort, priority group, fix,
  owner: developer, designer, copywriter or marketer), *Pages* (crawl
  data), *Performance* (metrics by page) and *Method*. If openpyxl is
  missing, deliver `website-audit-issues.csv`.
- Present them:

  ```sh
  zen output present --type text --title "Website audit — <domain>" \
    --summary "<overall verdict and the single most valuable fix>" \
    --primary website-audit.md="Audit report" \
    --final website-audit-issues.xlsx="Issue list"
  ```

## Quality bar

- Every issue is reproducible: a URL plus a metric, selector or
  screenshot. No generic best-practice advice without a page it applies to.
- Separate lab from field data and state the date of each measurement.
- Call the accessibility section a review, not a conformance audit.
- Read-only: never submit forms, create accounts, load-test or change
  anything on the site.
- Fixes are specific enough to act on: "compress the 1.8 MB hero image
  on /pricing to WebP under 200 KB" rather than "optimise images".

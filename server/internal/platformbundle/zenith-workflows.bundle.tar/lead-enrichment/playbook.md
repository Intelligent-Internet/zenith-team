# Lead enrichment

You are adding trustworthy data to a lead list the team already has, so
reps can prioritize and personalize. The reader will import the result or
sort it by fit score, so every added value must be accurate, sourced and
clearly separated from the original data. When a value cannot be verified,
a blank is the correct answer; a plausible guess is a defect.

## Inputs

- The lead list: pasted rows, CSV, or a link to a sheet. If a link cannot be
  opened, stop and report it — never enrich an imagined list. Beyond about
  500 rows, enrich the first 500 and report the remainder.
- The data to add, the source order, the conflict policy and the ideal
  customer profile — all in the brief. With no profile, either score against
  the dominant pattern in the list and say so, or skip scoring and say why.
- Connectors, read-only: a CRM (HubSpot, Salesforce) for existing account
  and contact records; Apollo or another enrichment Connector; Google Drive
  for a linked sheet. Never write back to any system.

## Procedure

1. **Parse and normalize.** Detect and map the columns (name, first and
   last name, title, company, email, domain, phone, country). Trim spaces,
   fix obvious casing, split full names, and derive the company domain from
   a business email or website — never from free-mail domains such as
   gmail.com. Give each row an ID so output rows map one-to-one to input.
2. **Find duplicates.** Flag exact duplicates (same email) and likely ones
   (same person and company). Mark them; do not delete.
3. **Resolve companies.** Match each row to one company by domain first,
   then by name plus country. Record match confidence: High (domain), Medium
   (name and location), Low (name only). Low-confidence rows get a flag, not
   firmographics.
4. **Enrich companies** in the chosen source order, once per company, reused
   for all its rows: industry (a plain label, plus a NAICS code when clear),
   employee range, headquarters city and country, revenue range (filings
   for public companies; otherwise "est." with its basis), funding stage and
   latest round (dated, from an announcement or filing), and technology
   signals (job posts, integration pages, public site traces — each with
   evidence).
5. **Check roles.** Confirm the person still holds the title at the company
   using the company site, recent press or public professional profiles.
   Classify Confirmed (seen within six months), Likely (older evidence),
   Possibly moved (evidence they left) or Unknown. Add seniority (C-level,
   VP, Director, Manager, Individual contributor) and function.
6. **Add triggers.** For each company, the single most relevant event of the
   last six months — funding, a hiring surge, a leadership change, expansion,
   a launch — dated and linked.
7. **Apply the conflict policy.** When a source contradicts the original
   (a new title, a different headquarters), keep the original and either add
   the new value in a "suggested" column or flag the row, as the brief says.
   Never overwrite input data.
8. **Score fit.** Build a 100-point rubric from the profile, for example
   industry 25, size 25, geography 15, role seniority and function 25,
   trigger 10. Tier A is 75 and above, B is 50–74, C is below 50. Write the
   rubric into the workbook.
9. **Check the output.** Rows out equal rows in; compute the fill rate of
   every added column; spot-check ten random rows end to end.

## Deliverables

- **Primary:** `enriched-leads.xlsx` with sheets:
  - *Leads* — original columns first and unchanged, then the added columns,
    each followed by its source where practical, plus match confidence, role
    status, suggested values, fit score, tier and notes;
  - *Companies* — one row per resolved company with firmographics and
    sources;
  - *Summary* — rows processed, fill rate per field, tier counts, duplicates,
    rows needing review, and the rubric.
  If openpyxl is unavailable, deliver the Leads and Companies sheets as CSV.
- **Final:** `enriched-leads-import.csv` — the Leads sheet without source
  columns, with import-friendly headers.
- Present it:

  ```sh
  zen output present --type file --title "Enriched leads" \
    --summary "<N rows enriched; fill rates; number of A-tier leads>" \
    --primary enriched-leads.xlsx="Enriched leads" \
    --final enriched-leads-import.csv="CRM import file"
  ```

## Quality bar

- Every added value traces to a source or is labeled an estimate; blanks
  beat guesses.
- Never guess email addresses or phone numbers, and never add personal
  contact details, home locations or sensitive personal data.
- The original data is never altered; conflicts are suggestions or flags.
- Read-only on every Connector: nothing is imported, updated or contacted.

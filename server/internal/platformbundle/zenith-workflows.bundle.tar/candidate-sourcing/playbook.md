# Candidate sourcing

You are building a longlist of people who could do a specific job, from
what they have made public about their professional work. A recruiter or
hiring manager will read it to decide whom to approach, so every candidate
needs a clear reason to be on the list and a link that proves it. Good
sourcing is rubric-driven and evidence-based, reaches beyond the obvious
job titles and employers, and treats candidates' information with
restraint: professional facts only, from public sources, and no contact
made on the Company's behalf.

## Inputs

- The role title, description, location and work model, rubric, sources,
  target backgrounds, exclusions and list size.
- If no rubric is given, derive one (step 1) and show it at the top of the
  deliverable so the person can correct it.
- An applicant tracking system Connector (Ashby) lets you
  remove people already in the pipeline; read only. LinkedIn and GitHub
  Connectors help read public profiles; Firecrawl helps with team pages.
  Without them, use public web search only.

## Procedure

1. **Build the rubric.** Two to four **must-haves** — observable,
   job-related requirements a candidate cannot succeed without. Three to
   six **signals**, each with a weight and a 0–3 scale defined by the
   evidence that earns each point (for example, "3 — has built and
   operated a payments ledger in production, shown in a talk, repository
   or detailed profile"). Avoid proxies that do not predict performance:
   school prestige, years of experience on their own, employer brand.
2. **Write the search plan.** List title variants and adjacent titles,
   skill and domain keywords, target and adjacent employers, and places
   where this kind of person shows their work. Write search strings per
   channel, for example site-restricted web searches over public profile
   pages (`site:linkedin.com/in "ledger" ("Go" OR "Golang") Lisbon`),
   code-host searches by language, topic and location, conference speaker
   archives, and paper or patent searches. Include at least one channel
   that reaches non-traditional backgrounds (career changers, bootcamps,
   communities).
3. **Collect.** For each promising person record: name, current title and
   employer as publicly stated, location as publicly stated, profile
   links, and the specific evidence (a repository, talk, article, project)
   relevant to the rubric. Deduplicate people found in several channels.
   Gather about twice the requested list size before scoring.
4. **Check currency.** Note the date of the most recent evidence. Mark
   anyone whose public information is more than two years old as "stale —
   verify". Remove people on the exclusion list and, with an applicant
   tracking system Connector, people already in the pipeline.
5. **Score.** For each must-have record Met, Not met or Unknown — unknown
   is not a fail; it becomes a question for the first conversation. For
   each signal give 0–3 with the evidence link. Compute the weighted score
   and a confidence level (high when most scores rest on direct
   evidence). Drop candidates with a must-have clearly not met.
6. **Rank and balance.** Rank by weighted score, then confidence. Check
   the list is not drawn from one or two employers or a single channel;
   if it is, go back to step 2 and widen the search.
7. **Write the hook.** One or two sentences per candidate that reference
   their specific public work and connect it to what the role offers,
   plus one short outreach template the recruiter can adapt. These are
   drafts; never message anyone.

## Deliverables

- **Primary:** `candidate-longlist.xlsx` with sheets:
  - **Longlist** — rank, name, current title, employer, location, profile
    links, must-have status per must-have, score per signal, weighted
    score (formula), confidence, evidence summary, unknowns to verify,
    outreach hook, channel found, date of latest evidence.
  - **Rubric** — must-haves, signals, weights and scale definitions.
  - **Search strings** — channel, string, results reviewed.
  - **Excluded** — name and reason.
  Deliver CSV files with the same columns if openpyxl is unavailable,
  presenting `longlist.csv` as `--primary` and the others as
  `--supporting` items.
- **Final:** `sourcing-summary.md` — the rubric (marked "derived" when you
  built it), the top ten with a two-line case each, channels that worked
  best, the outreach template, and gaps in the market for this profile.
- Present them:

  ```sh
  zen output present --type file --title "Candidate longlist — <role>" \
    --summary "<n> candidates ranked; <n> meet every must-have on evidence" \
    --primary candidate-longlist.xlsx="Candidate longlist" \
    --final sourcing-summary.md="Sourcing summary"
  ```

## Quality bar

- Every score cites public evidence; nothing is inferred from photos,
  names or anything outside professional work.
- Never record or infer age, gender, ethnicity, nationality, religion,
  health, family status or other protected characteristics, and never
  use them to rank.
- Business information only: no personal phone numbers or home
  addresses, and no guessed email addresses. Respect each site's terms;
  do not log in to scrape.
- Keep data minimal and note the source of each record, so the Company
  can meet its notice duties (for example under GDPR, telling a sourced
  candidate where their data came from when first contacting them).
- Nobody is contacted by this workflow.

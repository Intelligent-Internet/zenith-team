# Insurance submission package

You are assembling the package a broker sends to underwriters to quote a
commercial insurance program. The reader is a producer, account manager or
business owner; the eventual audience is an underwriter who prices faster
and better when the submission is complete, consistent and tells a credible
risk story. Good work organizes every fact the business supplied, never
invents exposure values, and is blunt about what is still missing. This is
preparation support; coverage decisions and binding belong to a licensed
broker or agent, and carrier applications must be completed and signed by
the insured.

## Inputs

- The insured, operations description, jurisdictions, situation, lines,
  effective date and documents — all in the brief.
- Documents may be pasted text, links, or files in Google Drive or email
  when those Connectors are available (read-only). If a linked document
  cannot be opened, list it in the gap list; do not guess its contents.
- Personal data in driver lists or payroll (dates of birth, licence
  numbers) is sensitive: carry it into the schedules only if provided,
  never search for it, and mask all but the last four characters of IDs.

## Procedure

1. **Classify the risk.** Describe operations precisely, assign a NAICS
   code, and propose general liability class descriptions and workers'
   compensation class codes (NCCI or the state bureau) as "proposed —
   confirm with the broker". Note monopolistic workers' compensation
   states (currently North Dakota, Ohio, Washington and Wyoming; confirm),
   where cover comes from the state fund.
2. **Map requirements per line.** List what underwriters need for each
   line requested. Standard industry applications cover general
   information, general liability, property, auto, workers' compensation
   and umbrella; professional, cyber, D&O and employment practices usually
   need carrier-specific supplemental applications. Build a checklist of
   required data points per line.
3. **Build the schedules** from supplied data:
   - **Locations and values:** address, occupancy, construction class,
     year built, square footage, stories, sprinkler percentage, alarm,
     roof type and year, updates to wiring, plumbing and heating, building
     replacement cost, contents, business income (12 months), and the
     basis of each value.
   - **Vehicles:** year, make, model, VIN, type and weight class, garaging
     address, radius of operation, cost new; **drivers** with years
     licensed and violations when supplied.
   - **Payroll and headcount** by class code and state; subcontractor
     costs and whether certificates of insurance are collected.
   - **Revenue** by operation, state and, for products, by product line.
   - **Cyber and management liability** controls when those lines are
     requested: multi-factor authentication, endpoint detection, offline
     backups, patching cadence, training, records held; and for D&O,
     ownership, financials and funding.
4. **Summarize loss history.** From loss runs (ideally five years, valued
   within the last 90 days): per line and policy year — carrier, claim
   count, paid, reserved, total incurred, open claims; large-loss
   narratives (cause, amount, status, corrective action); frequency and
   severity trends; loss ratio when premiums are known. Flag loss runs
   that are missing, stale or incomplete.
5. **Write the underwriting narrative** (one to two pages): who the
   business is and how long it has operated, operations and customers,
   what makes it a better-than-average risk (safety programs,
   certifications, maintenance, contracts with risk transfer), explanation
   of any large losses and what changed, the expiring program (carriers,
   limits, deductibles, premiums) when known, why the account is being
   marketed, and the requested structure and effective date.
6. **Consistency check.** Revenue, headcount, addresses, vehicle counts
   and dates must agree across the narrative, schedules and supplied
   documents; list every conflict.
7. **Build the gap list.** Every missing or unsupported item: what it is,
   why the underwriter needs it, who supplies it (insured, broker, prior
   carrier), priority (Blocks quoting / Affects price / Nice to have) and
   a target date that works back from the effective date (submissions
   commonly go out 60 to 90 days before renewal).

## Deliverables

- **Primary:** `submission-package.docx` (python-docx): cover summary;
  underwriting narrative; applicant information; per-line sections with
  exposures and requested limits; loss summary; expiring program;
  consistency issues; gap list.
- **Final:** `submission-schedules.xlsx` with sheets `Locations`,
  `Vehicles`, `Drivers` (when supplied), `Payroll`, `Revenue`, `Losses`,
  `Expiring program`, `Gap list`, with totals as formulas.
- Present:

  ```sh
  zen output present --type file --title "Insurance submission — <insured>" \
    --summary "<lines covered and the number of blocking gaps>" \
    --primary submission-package.docx="Submission package" \
    --final submission-schedules.xlsx="Schedules and gap list"
  ```

  Without python-docx or openpyxl, deliver Markdown and CSV equivalents.

## Quality bar

- Every value in a schedule traces to a supplied document or is blank and
  listed in the gap list; no estimated property values or payrolls.
- Class codes are marked as proposals for the broker to confirm.
- The narrative is factual and underwriter-friendly: no marketing
  superlatives, no omission of known losses.
- Nothing is sent to carriers or anyone else.

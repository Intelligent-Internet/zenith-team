# Litigation prep

You are building the working file for one dispute: a claim-by-claim
breakdown of the complaint, the defenses and the other side's likely
answers, and prioritized deposition outlines. The reader is a founder or
in-house lead who will work with litigation counsel; the file should let
them brief counsel in one meeting and spend fees on judgment, not reading.

This is decision support, not legal advice. Deadlines, privilege and
strategy must be confirmed by counsel admitted in the court named in the
brief — a missed response deadline can mean a default judgment.

## Inputs

- The complaint (or demand letter), court, our role, stage and objectives.
  If the complaint cannot be opened or is incomplete, stop and report
  which parts are missing; never analyse a paraphrase you invented.
- Our facts and key documents, when given. Keep them separate from the
  complaint's allegations throughout.
- A Google Drive Connector, when available, can open linked pleadings,
  contracts and correspondence.
- Where the forum does not use depositions (for example England and Wales
  or most civil-law courts), produce cross-examination and witness
  interview outlines instead and say so.
- No witnesses named: propose the likely deponents from the complaint (the
  people who made the key statements, signed the key documents or hold the
  key records) and outline the top two or three, marked as proposed.

## Procedure

1. **Snapshot the matter.** Parties and their roles, court, case number,
   judge if named, counts pleaded, relief sought (amounts, injunction,
   fees, interest), exhibits, and every date the complaint relies on.
2. **Estimate deadlines and immediate duties.** From the served date,
   estimate the response deadline under the forum's rules and label it
   "estimate — confirm with counsel". For orientation: U.S. federal court
   is 21 days after service (60 if service was waived); England and Wales
   is an acknowledgment within 14 days and a defence within 28 days of
   service of the particulars when acknowledged. Then list duties that
   start now: a litigation hold covering email, chat and devices (suspend
   auto-delete), notice to insurers under D&O, E&O or general liability
   policies, and a check of the contract's dispute clauses — arbitration,
   forum selection, notice and cure, contractual limitation periods and
   liability caps.
3. **Build the element matrix.** For every count, list its legal elements
   and, against each, the complaint paragraphs (¶) that allege it. Mark
   elements that are pleaded only as conclusions, pleaded by a party
   without knowledge, or not pleaded at all.
4. **Screen threshold defenses.** Jurisdiction, venue and forum clauses,
   arbitration, service defects, limitation periods, standing, failure to
   state a claim, missing parties, and contractual bars. Rate each
   *strong*, *arguable* or *weak* with the reason and the facts needed.
5. **Develop merits defenses.** Element by element, where is the other
   side weakest? Add affirmative defenses worth pleading — waiver,
   estoppel, failure to mitigate, set-off, statute of frauds, accord and
   satisfaction, comparative fault — noting that in many courts a defense
   not pleaded early is lost. Flag counterclaims that may be compulsory.
6. **Anticipate the reply.** For each defense, write the other side's
   best counter-argument and what would defeat it.
7. **Map the evidence.** For each disputed fact: what proves or disproves
   it, who holds it (custodian or third party), and whether we control it.
   List the gaps.
8. **Outline depositions.** Per witness: objectives (lock in testimony,
   establish a missing element, authenticate or undermine a document,
   test credibility), then topics ranked P1 (goes to an element or a
   defense), P2 (context and credibility) and P3 (nice to have). Under each
   topic, open questions funnelling to closed ones, with the exhibit to
   show. For our own witnesses, write preparation topics and the hard
   questions they will face, not a script of answers.
9. **Frame options.** Claimed versus realistic exposure, rough cost of
   each path (early motion, mediation, settlement, trial), and how each
   serves the stated objectives. Use qualitative likelihoods with reasons,
   never a percentage presented as fact.

## Deliverables

- **Primary:** `litigation-prep.docx` (python-docx), marked "Confidential —
  prepared in anticipation of litigation", with:
  1. Matter snapshot and deadline estimate on one page.
  2. Immediate actions checklist.
  3. Complaint summary by count with ¶ citations.
  4. Defense matrix: count, element, allegation ¶, our defense, strength,
     evidence needed, expected counter-argument.
  5. Threshold defenses, counterclaims and third-party claims.
  6. Evidence and custodian map with gaps.
  7. Deposition outlines per witness, P1 topics first.
  8. Options and questions for counsel.
- **Final:** `defense-matrix.xlsx` with the matrix and the evidence map as
  filterable sheets, when openpyxl is available.
- Present:

  ```sh
  zen output present --type file --title "Litigation prep — <matter>" \
    --summary "<claims, the strongest defenses and the deadline estimate>" \
    --primary litigation-prep.docx="Litigation prep" \
    --final defense-matrix.xlsx="Defense matrix"
  ```

  Without python-docx, deliver `litigation-prep.md` with `--type text`.
  Without openpyxl, write the matrix and the evidence map as
  `defense-matrix.csv` and `evidence-map.csv` and pass those as `--final`
  items instead.

## Quality bar

- Every statement about the complaint cites its paragraph; allegations are
  never described as facts.
- Cite a case or statute only after confirming it exists and says what you
  rely on, with a link; otherwise describe the principle and mark it
  "authority to be confirmed by counsel". Never fabricate a citation.
- Neutral, factual tone: no speculation about motives and no disparaging
  language, since privilege may not attach to everything.
- Deadlines are always labelled estimates.

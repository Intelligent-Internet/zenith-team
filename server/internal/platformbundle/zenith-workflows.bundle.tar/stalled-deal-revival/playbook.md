# Stalled deal revival

You are rescuing pipeline that has gone quiet. The reader is a founder or
sales lead who knows some deals are drifting but has not had time to look at
each one. For every stalled deal, the job is to understand why it stalled,
decide whether it is worth reviving, and draft a message that gives the buyer
a genuine reason to reply. "Just checking in" is never the message. You
draft; people send.

## Inputs

- Quiet threshold, stages, minimum value, owner filter, new reasons to
  reconnect and default tone — all in the brief.
- A CRM Connector (HubSpot, Salesforce) is the main source: open deals,
  stage, amount, close date, owner, contacts, activities and notes. Mail
  (Gmail) and a call recorder (Gong) add the last real conversation. All
  read-only.
- Without a CRM Connector, use the pasted deals. If there is neither, stop
  and report that there are no deals to review.

## Procedure

1. **Pull candidates.** Open deals in the chosen stages, at or above the
   minimum value, for the chosen owner. For each: amount, stage, created
   date, expected close date, owner, primary contact and other contacts.
2. **Measure real silence.** Find the date of the last two-way interaction:
   an email from the buyer, a meeting that took place, a connected call. Our
   own unanswered emails do not count. Keep deals whose silence meets the
   threshold, and also flag deals whose expected close date has passed.
3. **Read the last conversation.** Notes, the latest thread and the last
   call. Extract what was agreed, the last open question, who went silent
   (champion, economic buyer, procurement) and any promise we did not keep.
4. **Diagnose the stall.** Choose the most likely cause, with evidence:
   - the champion went quiet or left (check public sources for a role
     change);
   - no compelling event — the pain was real but not urgent;
   - budget or priority change (layoffs, freeze, reorganization, weak
     results in the news);
   - a new stakeholder or decision maker;
   - a competitor or an in-house option gained ground;
   - stuck in legal, security review or procurement;
   - we dropped the ball — a missing proposal, an unanswered question, no
     follow-up.
5. **Look for fresh triggers.** Company news from the last 90 days: funding,
   new leaders, expansion, launches, results. A new trigger is often the
   best reason to reconnect.
6. **Choose the play** for each deal:
   - **Revive** — there is a new reason; write to the original contact.
   - **Multi-thread** — the contact left or stays silent; reach a second
     stakeholder with a reason relevant to their role.
   - **Close the loop** — no new reason and long silence; a courteous
     "should I close this out?" message, which often earns a reply.
   - **Recommend closing** — the evidence says it is lost; suggest a
     closed-lost reason for the owner to record. Do not record it yourself.
7. **Draft messages.** Under 100 words. Open with a specific reference to
   the last conversation; bring one new thing — an insight, a customer
   result, a product change, their own news, or a reason from the brief;
   end with one low-effort question. Use the default tone unless the play
   calls for another, and say which. Give email drafts a subject line.
8. **Prioritize.** Rank by value times stage likelihood — use the CRM's
   probabilities, or discovery 10%, evaluation 25%, proposal 50%,
   negotiation 70%, contracting 85% — and by how recoverable the diagnosis
   looks.

## Deliverables

- **Primary:** Markdown `stalled-deals-<date>.md` titled
  "Stalled deals — <date>": a summary (count, total value at risk, count per
  play); a table of deal, company, stage, value, owner, days quiet, cause and
  play; then one section per deal with the evidence, the play and the draft
  message.
- **Email drafts:** when Agent Mail is enabled and the contact's email is
  known, also create one reviewable draft per deal with `create_mail_drafts`
  or `zen mail draft`, one delivery per recipient. Never send.
- **Supporting:** `stalled-deals.csv` with the summary table.
- Present it:

  ```sh
  zen output present --type text --title "Stalled deals — <date>" \
    --summary "<N stalled deals worth X in total; the three to act on first>" \
    --primary stalled-deals-<date>.md="Stalled deals and drafts" \
    --supporting stalled-deals.csv="Deal table"
  ```

## Quality bar

- Silence is measured from the buyer's last reply, not from our last touch.
- Every diagnosis cites its evidence — a note, an email date, a call, a news
  link — and guesses are labeled as guesses.
- No message uses "just checking in", "bumping this", guilt or invented
  urgency; no discounts or deadlines that the brief did not authorize.
- Read-only in every Connector: no email sent, stage changed, deal closed,
  task created or activity logged.

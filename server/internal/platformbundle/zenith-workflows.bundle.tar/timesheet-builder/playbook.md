# Timesheet builder

You are reconstructing where a person's working time went, from the
traces their tools already hold, and turning it into a timesheet grouped
by client or project. The reader will bill clients or report hours from
it, so accuracy and honesty matter more than completeness: every entry
shows its evidence and confidence, overlaps are never double-counted, and
time you cannot account for is shown as a gap — never padded. The result
is a draft the person confirms before anyone relies on it.

## Inputs

- The period, the client or project rules, the activity sources, working
  hours and time zone, rounding, billable rules and layout.
- Connectors for the chosen sources: calendar, mail, GitHub (or an
  authenticated `gh` CLI / local `git log` for repositories on this
  computer), trackers and chat. Use each read-only. With no source
  available at all, stop and report that the timesheet needs at least
  one.
- No working hours given: assume 09:00–18:00 Monday to Friday in the
  calendar's time zone and record the assumption.
- Client rules that are ambiguous (one domain mapped to two clients):
  apply the more specific rule and list the conflict.

## Procedure

1. **Fix the window.** Exact start and end timestamps of the period in
   the person's time zone. Convert every activity timestamp to that zone.
2. **Collect raw activity** into one table (date, start, end or
   timestamp, source, title or subject, participants or repository,
   link):
   - *Calendar:* accepted and tentative events. Skip declined events,
     all-day markers, and events marked private or clearly personal
     (keep them out of the file entirely).
   - *Email:* sent messages only; received mail is not work time.
   - *Code:* commits authored by the person (match all their emails),
     pull requests opened, reviews submitted.
   - *Tickets and chat:* status changes, comments and messages authored
     by the person.
3. **Sessionise point activity.** Commits, emails, reviews, ticket
   updates and messages are points in time. Sort them and group points
   less than 90 minutes apart into a session. A session starts 30 minutes
   before its first point (work precedes the commit or email) and ends at
   its last point; a lone point becomes a 15-minute session. Record the
   heuristic in the assumptions sheet.
4. **Resolve overlaps.** Build a minute-level timeline. Priority when
   intervals overlap: calendar event > code session > ticket session >
   email session > chat session. Each minute is counted once, for the
   highest-priority activity. Clip everything to working hours unless the
   evidence is strong (a meeting at 19:00 counts; a lone 23:00 email
   becomes a flagged 15-minute entry).
5. **Assign clients and projects** using the brief's rules in this order:
   participants' domains, repository, ticket prefix or team, then
   keywords in titles. Unmatched time goes to **Unassigned** with the
   evidence, so the person can reassign it quickly.
6. **Score confidence.** High: calendar events and explicit time entries.
   Medium: code and ticket sessions. Low: sessions built only from email
   or chat.
7. **Round and apply rules.** Round each entry (not the daily total) to
   the chosen increment, to the nearest increment with ties rounding up,
   and never below one increment for a non-zero entry. Apply billable
   rules (non-billable categories, rates such as 50% travel, daily caps)
   in a separate billable-hours column, so raw hours stay visible.
8. **Sanity-check.** Flag days over 10 hours, days with less than half of
   working hours accounted for, entries spanning lunch without a break,
   and weekend work. Report unaccounted working hours per day rather
   than filling them.

## Deliverables

- **Primary:** `timesheet.xlsx` (openpyxl) with sheets:
  1. **Timesheet** — the chosen layout (day × project rows, activity
     rows, or a project-by-day grid) with hours, billable hours and
     totals as live `SUMIFS` formulas over the Entries sheet.
  2. **Entries** — one row per entry: date, start, end, raw minutes,
     rounded hours, client or project, description, source, evidence,
     link, confidence, billable (yes/no), billable hours.
  3. **Summary** — hours and billable hours per client or project,
     unaccounted hours per day, flags.
  4. **Assumptions** — time zone, working hours, sessionising heuristic,
     rounding rule, client rules applied and conflicts.
  Freeze header rows, format hours to two decimals and dates as
  YYYY-MM-DD.
- **Supporting:** `timesheet-entries.csv`, the Entries sheet as CSV for
  import into billing or time-tracking tools.
- Present it:

  ```sh
  zen output present --type file --title "Timesheet — <period>" \
    --summary "<n> hours across <n> clients; <n> hours unassigned to confirm" \
    --primary timesheet.xlsx="Timesheet" \
    --supporting timesheet-entries.csv="Entries (CSV)"
  ```

  If openpyxl is unavailable and cannot be installed, deliver the CSV as
  primary plus a Markdown summary, and say so.

## Quality bar

- Never invent hours; unaccounted time is shown as unaccounted.
- No minute is counted twice; totals on every sheet agree.
- Every entry has evidence and a confidence level.
- Private and personal events never appear in the file.
- The summary states clearly that this is a draft for the person to
  confirm before billing or submission.

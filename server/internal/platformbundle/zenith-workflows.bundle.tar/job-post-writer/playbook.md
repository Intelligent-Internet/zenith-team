# Job post writer

You are turning a hiring manager's rough notes into a job post that the
right people will recognise themselves in, and a short outreach message
that matches it. Most job posts fail the same way: a generic intro, a list
of duties, and a wish list of requirements that deters capable people —
disproportionately people from under-represented groups — while
attracting everyone else. A strong post is specific about what the person
will achieve, honest about the work and the pay, short on requirements,
and written in plain, inclusive language. This is writing support, not
legal advice; recommend a check with an employment adviser where the
compliance points below apply.

## Inputs

- The role title, notes, location and work model, employment type, pay,
  company description, website, voice and channels.
- Read the website or careers page when given, for facts, tone and any
  standard benefits or equal-opportunity wording already in use; reuse
  the Company's existing statement rather than inventing one.
- Missing facts (pay, reporting line, hiring steps) become
  `[placeholders]` and questions in the review notes — never invented
  details. If the notes are too thin to say what the job is, draft from
  the title and mark the post "needs the hiring manager's input".
- An applicant tracking system Connector (Ashby) can show
  earlier posts for tone and structure; read only. Nothing is published.

## Procedure

1. **Extract the substance.** From the notes, write down: why the role
   exists now; three to five outcomes for the first year; the day-to-day
   work; the team and manager; tools; must-haves; nice-to-haves; the
   hiring process and timeline; pay and benefits; location, time-zone
   overlap and travel.
2. **Challenge the requirements.** Keep only what someone truly needs on
   day one — usually four to six items. Replace years-of-experience with
   the capability behind it ("you have run a full sales cycle for
   five-figure contracts"). Drop degree requirements unless the law or a
   licence demands one. Move everything else to "nice to have" and say
   plainly that nobody is expected to have all of it.
3. **Draft the post** in this order:
   - **Title** — the plain title people search for, with level where
     it helps ("Senior", "Founding"); no "rockstar", "ninja" or internal
     level codes.
   - **Opening** — two or three sentences on the problem this person will
     solve and why it matters now.
   - **About us** — three or four specific, checkable facts, not
     adjectives.
   - **What you will do** — five to seven outcome-led bullets.
   - **What you will bring** — the short must-have list.
   - **Nice to have** — optional, clearly labelled.
   - **What we offer** — pay range, equity, benefits, flexibility, growth.
   - **How we hire** — the steps, how long each takes, when candidates
     hear back, and how to ask for adjustments or accommodations.
   - **Equal opportunity** — the Company's statement.
   Aim for 400 to 650 words, second person ("you"), short sentences and
   headings with bullets so it reads well on a phone and with a screen
   reader.
4. **Run the inclusive-language pass.** Replace or remove:
   - Gender-coded words — "dominant", "aggressive", "competitive",
     "rockstar", "ninja", "guys".
   - Age-coded words — "digital native", "young and energetic team",
     "recent graduate" (unless it is a graduate programme).
   - Ability assumptions — physical requirements the job does not need
     ("must be able to stand" for desk work); keep genuine ones and
     phrase them as the task ("moves equipment up to 20 kg").
   - "Native speaker" — replace with the proficiency level needed.
   - Vague culture filters — "culture fit", "work hard, play hard", "we
     are a family", "fast-paced" without saying what it means.
   - Unexplained jargon and acronyms.
   Record each change: original, replacement, reason.
5. **Check compliance.** Flag, for the person to confirm:
   - Pay transparency — several US states and cities require a good-faith
     pay range in the post, and the EU Pay Transparency Directive (member
     states had to transpose it by June 2026) requires pay information
     before the interview and bans asking about pay history. Confirm the
     rule in force where the role is advertised. If no pay is given,
     leave a `[pay range]` placeholder and say why.
   - The employment type matches the work (a "contractor" with fixed
     hours and a manager may be an employee).
   - No preference based on protected characteristics, and no request
     for photos, date of birth or marital status.
   - Right-to-work or sponsorship wording only if the notes state it.
6. **Write channel variants** for each selected channel: the careers page
   gets the full post; LinkedIn gets a short announcement post of about
   120 words with the link; general job boards get plain text without
   special formatting; community boards get a compact block — role,
   location and remote policy, pay range, one line on the work, how to
   apply.
7. **Write the outreach message** for sourced candidates: a subject line;
   under 120 words; a `[specific detail about their work]` slot at the
   start; one sentence on why them; two on the role and its impact; the
   pay range if known; a low-pressure ask (a 20-minute call); and an
   easy way to say no. Add a short, polite follow-up for a week later.
   Drafts only — nothing is sent or published.

## Deliverables

- **Primary:** `job-post.docx` (Markdown `job-post.md` if python-docx is
  unavailable) titled "Job post — <role>", with:
  1. The job post, ready to publish.
  2. Channel variants.
  3. Outreach message and follow-up.
  4. Language changes: original, replacement, reason.
  5. Compliance checklist, each item marked done or to confirm.
  6. Open questions and `[placeholders]` for the hiring manager.
- Present it:

  ```sh
  zen output present --type file --title "Job post — <role>" \
    --summary "<word count>-word post with <n> channel variants and an outreach message" \
    --primary job-post.docx="Job post"
  ```

  Use `--type text` and the `.md` path when you delivered Markdown.

## Quality bar

- Every claim about the Company, role, pay and benefits comes from the
  brief or the website; nothing is embellished.
- The must-have list has no more than six items, each job-related.
- The post passes the language pass with no gender-coded, age-coded or
  ability-assuming wording left unexplained.
- The outreach message is consistent with the post: same title, pay and
  location.
- Nothing is posted, published or sent by this workflow.

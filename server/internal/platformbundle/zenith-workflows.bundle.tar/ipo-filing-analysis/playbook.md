# IPO filing analysis

You are reading an IPO registration statement or prospectus so the reader
does not have to read all of it. The reader is an investor, a pre-IPO holder,
a competitor or a researcher, as the brief says; tilt the emphasis to what
that reader decides. Good work tells the business story in plain words, tests
the numbers rather than repeating them, separates company-specific risk from
boilerplate, and derives valuation from fully diluted share counts. This is
research support, not investment advice or a recommendation to buy shares.

## Inputs

- The company, listing venue, reader, emphasis, peers and pricing — all in
  the brief.
- The filing: use the link if given. Otherwise search the regulator's
  system — for the US, SEC EDGAR filings of type S-1, S-1/A, F-1, F-1/A and,
  once priced, 424B4; for the UK and EU, the approved prospectus on the
  issuer's site or the national storage mechanism. Always use the latest
  amendment and record which one. If no public filing exists (for example,
  only a confidential draft), stop and report that.
- Peer data from the peers' latest filings and a dated market-data source.

## Procedure

1. **Establish the version.** Note filing date, amendment number, whether a
   price range and share count are set, the lead underwriters, the
   exchange and ticker. Skim the changes versus the prior amendment
   (updated quarter, new risk factors, revised share numbers).
2. **Explain the business.** In under 200 words: what it sells, to whom,
   how it charges, and why customers choose it. Identify the company's own
   KPIs (for example ARR, net revenue retention, GMV, take rate, active
   customers) and read their exact definitions — flag unusual ones.
   Record customer or supplier concentration above 10%.
3. **Test the financials.** From the audited statements and the quarterly
   tables: growth by year and the last four to eight quarters (look for
   deceleration), gross margin trend, operating leverage, stock-based
   compensation as a share of revenue (and any one-off charge when
   performance-vesting awards vest at the listing), free cash flow, cash
   burn and runway, deferred revenue and remaining performance
   obligations. Reconcile non-GAAP measures to GAAP and list what they
   exclude. Check the auditor's report for going-concern language and the
   risk factors for material weaknesses in internal control.
4. **Rank the risks.** Read every risk factor, discard boilerplate and
   keep the ones specific to this company: customer concentration,
   regulatory exposure, related-party dealings, litigation, dependence on
   one platform or supplier, accounting judgments. Rank the top five to
   eight by likelihood and impact, quoting the filing.
5. **Map governance and control.** Share classes and votes per share,
   post-IPO voting control, controlled-company exemptions, board
   independence and committee composition, staggered board and other
   anti-takeover provisions, lock-up length and early-release triggers,
   directed share programs, executive pay, and related-party
   transactions.
6. **Follow the money.** Primary versus secondary shares (who is
   selling), net proceeds, stated uses (debt repayment, cash to the
   balance sheet, payments to insiders), pro forma capitalization, and
   dilution to new investors. Flag vague "general corporate purposes"
   when it is most of the proceeds.
7. **Frame a valuation range.** At the low, mid and high of the price
   range: market cap on fully diluted shares (outstanding plus options,
   RSUs, warrants and converted preferred, using the treasury method for
   options where strike data exists) and on basic shares; enterprise value
   = market cap + debt − pro forma cash. Compute EV to revenue, EV to gross
   profit and, when meaningful, EV to EBITDA on trailing and run-rate
   figures, and compare with the peer median and range (dated). Note the
   last private round price versus the range. Present a range and the
   growth or margin the valuation seems to assume — not a target price.
8. **Red-flag sweep.** Recent auditor change, restatements, heavy
   related-party revenue, insiders selling a large share, founder
   super-voting with no sunset, non-standard KPI definitions, and
   material weaknesses.

## Deliverables

- **Primary:** `ipo-analysis.md` (or `.docx`) titled "IPO filing
  analysis — <company>": verdict summary (five bullets for the stated
  reader); business; financial quality with a summary table; top risks;
  governance and control; use of proceeds and dilution; valuation range;
  red flags; questions for the roadshow or management; sources with filing
  section references.
- **Final:** `ipo-model.xlsx` with `Inputs` (price range, share counts),
  `Capitalization` (basic to fully diluted with formulas), `Financials`
  (annual and quarterly summary), `Comps` (peer multiples with date and
  source) and `Sources`.
- Present:

  ```sh
  zen output present --type text --title "IPO filing analysis — <company>" \
    --summary "<one-sentence verdict and implied valuation range>" \
    --primary ipo-analysis.md="IPO analysis" \
    --final ipo-model.xlsx="Capitalization and comps"
  ```

  Without openpyxl, deliver the capitalization and comps tables as CSV
  files and say the workbook is not live.

## Quality bar

- Cite the filing section or page for every figure and quoted risk.
- Show the share count behind each market cap; never mix basic and
  diluted counts without saying so.
- Compare like with like: fiscal periods, currencies, GAAP versus
  non-GAAP.
- Peer multiples carry a date and a source.
- No recommendation to buy, sell or subscribe.

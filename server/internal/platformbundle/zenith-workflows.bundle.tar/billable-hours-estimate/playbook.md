# Billable hours estimate

You are estimating how many hours one legal or professional work product
will take, broken down by phase, task and role. The reader is a general
counsel setting a budget, a partner pricing a matter, or an operator
checking a quote. A good estimate is built bottom-up, shows a range rather
than false precision, and makes its assumptions so explicit that anyone
can see which one would move the number.

This is a planning estimate, not a quote or a promise: actual time depends
on the other side's behaviour, surprises in the facts and client choices.
Say so in the summary.

## Inputs

- The work product, practice area, scope, complexity, purpose, rates and
  deadline are in the brief.
- A thin scope is not a reason to stop: assume the standard scope for this
  work product, write each assumption down, and make it an input the
  reader can change.
- No rates given: produce hours by role, leave the rate cells as clearly
  marked inputs, and let cost formulas fill in once rates are entered.
  Never invent a firm's rates.
- When the purpose is checking a quote, the quote should be in the scope;
  if it is missing, estimate anyway and say the comparison could not be
  made.

## Procedure

1. **Fix the scope boundary.** In scope, out of scope, dependencies (the
   other side's turnaround, client decisions, third-party consents), and
   the counts that drive effort: parties, documents, pages, jurisdictions,
   negotiation rounds, custodians, witnesses. Assume a number of rounds
   explicitly — it is usually the biggest single driver.
2. **Break down the work** into phases that fit the practice area, for
   example:
   - Transactions: intake and planning, diligence, first drafts, each
     negotiation round, ancillary documents, signing and closing,
     post-closing filings.
   - Litigation: case assessment, pleadings, written discovery, document
     review, depositions (preparation plus attendance, per witness),
     motions, experts, trial preparation.
   - Contracts: review and issues list, markup, each turn, calls, final
     execution version.
   - Compliance and advisory: fact gathering, research, drafting, review,
     client meetings.
3. **Estimate each task three ways.** Low, likely and high hours, per role.
   Compute the expected value as (low + 4 × likely + high) / 6. State the
   unit rate behind volume-driven tasks — documents reviewed per hour,
   pages marked up per hour — so it can be adjusted. Apply complexity to
   the tasks it actually affects, not as a flat multiplier on everything.
4. **Add the work people forget.** Client calls and status updates,
   internal coordination and supervision, matter management, re-work after
   the other side's comments, research on novel points, closing logistics
   and travel. These often add 10–20% to drafting and negotiation time;
   show them as their own rows.
5. **Check the role mix.** Push work to the lowest role that can do it well.
   Flag a mix where senior time is unusually high, and explain why when it
   is justified.
6. **Price and bound.** Cost = hours × rate by role. Report the expected
   total and the range; for a fixed fee, add a visible contingency (10–25%
   depending on uncertainty) rather than padding tasks.
7. **Test the timeline.** If a deadline is given, compare hours per role
   with the working weeks available, assuming about six billable hours per
   person per day, and flag crunch weeks or extra staff needed.
8. **Compare with the quote** when that is the purpose: phase by phase,
   show where the quote is above or below the estimate and the assumption
   that likely explains the gap.

## Deliverables

- **Primary:** `hours-estimate.xlsx` built with openpyxl:
  - *Inputs*: roles and rates, currency, contingency %, hours per day,
    complexity notes — input cells shaded.
  - *Estimate*: phase, task, role, low, likely, high, expected (formula),
    cost (formula), assumption reference.
  - *Summary*: totals by phase and by role, blended rate, expected total,
    low–high range, contingency and grand total — all formulas.
  - *Assumptions*: numbered assumptions and exclusions.
  - *Quote check* or *Timeline* when the purpose or deadline calls for it.
- **Final:** `estimate-summary.md`: the headline range, the three biggest
  drivers, key assumptions and exclusions, and what would change the
  estimate.
- Present:

  ```sh
  zen output present --type file --title "Hours estimate — <work product>" \
    --summary "<expected hours, range and cost if rates were given>" \
    --primary hours-estimate.xlsx="Hours estimate" \
    --final estimate-summary.md="Estimate summary"
  ```

  Without openpyxl, deliver `hours-estimate.csv` for the task table (with
  the expected-hours and cost columns computed, and the formulas written
  out in the summary) as `--primary`, plus the Markdown summary as
  `--final`.

## Quality bar

- Every output number is a live formula; nothing hard-coded in totals.
- For every task, low ≤ likely ≤ high, and the summary ties to the task
  table.
- Each task points to an assumption; exclusions are listed, not implied.
- Rates come only from the brief; contingency is visible, never hidden.
- Round hours to the nearest 0.5 and never present a range as a
  guarantee.

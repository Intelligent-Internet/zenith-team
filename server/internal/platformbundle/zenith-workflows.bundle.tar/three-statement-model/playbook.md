# Three-statement model

You are building an integrated operating model for one company: an income
statement, balance sheet and cash flow statement driven by a single
assumptions sheet and tied to each other in every period. The reader is a
founder, CFO, investor or lender who will change assumptions and expect every
statement to update. Good means historicals that reconcile to the source,
every forecast number traceable to a labelled driver, a balance sheet that
balances without a plug, and scenarios switched from one cell. This is
decision support, not investment or accounting advice; say so on the cover.

## Inputs

- Company, purpose, data source, history and forecast length, revenue build,
  scenarios, units and known assumptions are in the brief.
- **Public filings:** pull the annual reports (10-K, 20-F or local
  equivalent) for the years requested plus the latest quarterly report from
  SEC EDGAR or the national filing system. The XBRL company-facts API
  (`data.sec.gov/api/xbrl/companyfacts/CIK##########.json`, with a
  descriptive User-Agent) speeds up capture; always reconcile to the filed
  statements.
- **Pasted or linked financials:** if a link will not open, or the balance
  sheet provided does not balance, stop and report exactly what is missing.
  Never model a guessed history.
- **Accounting Connector:** pull the P&L and balance sheet by fiscal year.
  Note whether the latest period is closed and reconciled.
- **Private company estimates:** build from disclosed revenue, press, peer
  filings and headcount data; mark every estimate "Est." with its derivation.
- Units or fiscal year end missing: infer from the source and record the
  assumption on the cover.

## Procedure

1. **Standardize the historicals.** Map reported lines to a standard chart:
   revenue, COGS, opex by function, D&A, interest, tax; cash, receivables,
   inventory, other current assets, PP&E, intangibles, payables, accruals,
   deferred revenue, debt by tranche, leases, equity. Keep a column naming
   the source line. Move one-off items (restructuring, impairments, disposal
   gains) to a separate line so margins are clean. Each historical statement
   must reconcile to reported totals within rounding.
2. **Lay out the assumptions sheet.** One row per driver, one column per
   period, and a block per scenario. A single selector cell chooses the live
   case with `CHOOSE` or `INDEX`. Show each driver's historical value beside
   the forecast so a reader can judge it: growth, gross margin, opex as % of
   revenue, DSO, DIO, DPO, capex as % of revenue, useful lives, tax rate,
   interest rates, minimum cash, dividends.
3. **Build revenue** with the requested method: growth on prior period;
   units × price; sum of segments; customers × revenue per customer with
   new, churned and expansion lines (an ARR bridge); or locations ×
   revenue per location with a ramp curve. Tie year one to any guidance or
   budget in the brief and explain differences.
4. **Supporting schedules.**
   - Working capital: receivables = revenue × DSO ÷ days in period;
     inventory = COGS × DIO ÷ days; payables = COGS × DPO ÷ days; other
     items as % of revenue; deferred revenue for subscription businesses.
   - PP&E: opening + capex − depreciation − disposals = closing, with
     depreciation from useful lives on existing assets and new capex.
   - Debt: per tranche opening, draws, scheduled and optional repayments,
     closing; a revolver draws when cash would fall below the minimum.
     Charge interest on opening balances to avoid circularity; if average
     balances are required, add an on/off circularity switch.
   - Tax: rate × pre-tax income, zero on losses, with a simple loss
     carryforward line.
   - Equity: opening + net income − dividends + issuance − buybacks +
     stock compensation = closing.
5. **Assemble the statements.** The cash flow statement uses the indirect
   method: net income, non-cash add-backs, working capital changes (an
   increase in an asset is a use of cash), capex, debt and equity flows.
   Balance sheet cash equals the cash flow statement's closing cash. Never
   plug cash, equity or "other".
6. **Integrity checks.** A Checks sheet with one row per check and one
   column per period, each returning 0 or 1, and a master flag on the cover:
   balance sheet balances (|assets − liabilities − equity| under half a
   display unit), cash flow closing cash equals balance sheet cash, retained
   earnings roll forward, historical totals equal reported totals, no debt
   balance below zero, cash at or above the minimum, revolver within its
   commitment.
7. **Scenarios.** Switch the selector through each requested case,
   recalculate, and record revenue, EBITDA, net income, free cash flow,
   closing cash, net debt ÷ EBITDA and the lowest cash point in a Scenario
   summary. This is the only pasted-values table; label it "Snapshot taken
   <date>; re-run the selector to refresh".
8. **Recalculate and verify.** openpyxl writes formulas but does not compute
   them. Recalculate with LibreOffice headless
   (`soffice --headless --convert-to xlsx --outdir recalc model.xlsx`) and
   read the check cells with `load_workbook(path, data_only=True)`. Fix
   every failing check in every scenario. Without LibreOffice, rebuild the
   core roll-forwards in pandas to prove the model balances, and say the
   workbook computes on open.

## Deliverables

- **Primary:** `three-statement-model-<company>.xlsx` with sheets Cover
  (company, units, fiscal year end, live scenario, master check,
  disclaimer), Assumptions, Historicals, Revenue, Schedules, Income
  statement, Balance sheet, Cash flow, Checks, Scenario summary, Sources.
- **Supporting:** `model-notes.md`, one page: key assumptions and why,
  scenario outputs, check status, estimates used, what to verify.
- Present:

  ```sh
  zen output present --type file --title "Three-statement model — <company>" \
    --summary "<forecast period, base-case revenue and closing cash in one sentence>" \
    --primary three-statement-model-<company>.xlsx="Three-statement model" \
    --supporting model-notes.md="Model notes"
  ```

  If openpyxl is missing and cannot be installed, deliver each statement as
  CSV plus the notes, present with `--type file`, and say the model is not
  live.

## Quality bar

- Blue font for hard-coded inputs, black for formulas, green for links to
  other sheets. No numbers typed inside formulas except unit conversions.
- Periods labelled FY2025A / FY2026E (or quarter and month equivalents);
  units in every sheet header; negatives in parentheses.
- All checks pass in every scenario before presenting.
- Every historical figure cites its filing or document; every estimate is
  marked as one.
- Freeze panes on labels and periods; no merged cells in calculation ranges;
  no links to external workbooks.

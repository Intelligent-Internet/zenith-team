# Meeting action items

You are turning a messy record of a meeting into the short list of things
that must now happen. The reader is someone who was in the room — or
missed it — and needs to know what was decided, who does what by when, and
what is still open. Good output is faithful to what was actually said:
nothing invented, nothing that was merely floated recorded as decided, and
every item traceable to the moment in the notes that created it.

## Inputs

- The notes or transcript, pasted or linked. If a link cannot be opened,
  stop and report it; never reconstruct a meeting from its title. If a
  meeting-recorder Connector (for example Fireflies) or a drive Connector
  is available, use it read-only to fetch the linked transcript.
- The meeting name, and optionally the date, attendees with roles, the rule
  for undated items and the extra export format.
- If no meeting date is given, look for one in the notes or the calendar
  event; if you cannot find it, keep relative dates as written ("next
  Friday") and flag them.

## Procedure

1. **Normalise the record.** Identify speakers and map nicknames, first
   names and transcript labels ("Speaker 2") to the attendee list. When a
   speaker cannot be identified, keep the label and say so. Note the
   language of the notes and write the output in the same language unless
   the brief says otherwise.
2. **Find decisions.** A decision is a choice the group settled, signalled
   by phrases such as "let's go with", "agreed", "we won't", "final
   answer", or by a proposal followed by assent and no objection. Record
   each as one sentence in the form "<what> — decided by <who>, <any
   condition>". Keep proposals that were discussed but not settled out of
   this list; they go to open questions.
3. **Extract action items.** An action item is a commitment to do
   something after the meeting. For each record:
   - **Action** — starts with a verb and names the output ("Send the
     revised pricing sheet to Acme", not "Pricing").
   - **Owner** — exactly one person. "The team" or "we" is not an owner:
     use whoever volunteered or was asked; if nobody was, mark
     **Unassigned** and list it under open questions.
   - **Due** — resolve relative dates against the meeting date (ISO
     format, YYYY-MM-DD). "End of week" is that Friday; "next week"
     without a day is the following Friday. Apply the brief's rule for
     items with no date and label proposed dates as proposed.
   - **Done when** — the observable result that closes it.
   - **Source** — a short quote or timestamp from the notes.
   - **Confidence** — *explicit* (someone said "I'll do it") or
     *implied* (clearly needed but nobody claimed it). Implied items are
     suggestions; mark them so.
   Merge duplicates raised twice in the meeting, and split compound items
   ("draft and circulate") only when they have different owners.
4. **Collect open questions and risks.** Unresolved disagreements,
   questions nobody answered, dependencies on people not in the room, and
   decisions deferred to a later date. Name who should answer each one.
5. **Note external commitments.** Anything promised to a customer,
   partner or investor gets its own marker; these are the items that hurt
   most when dropped.
6. **Check the result.** Every action item has an owner or the
   Unassigned flag; every due date is a real calendar date or flagged;
   no decision contradicts another; attendees' names are spelled as in
   the attendee list.

## Deliverables

- **Primary:** `action-items.md` titled "<meeting name> — decisions and
  action items (<date>)" with:
  1. **Summary** — three sentences at most: purpose, the main outcome,
     the most urgent action.
  2. **Decisions** — numbered list.
  3. **Action items** — table: #, action, owner, due, done when,
     confidence, source. External commitments marked.
  4. **Open questions and risks** — who should answer each, and by when
     if a date was mentioned.
  5. **Parking lot** — ideas raised but explicitly set aside.
- **Supporting**, per the brief's export choice:
  - CSV `action-items.csv` with the header
    `Title,Owner,Due date,Done when,Source,Confidence` (UTF-8, ISO dates,
    one row per action item) — imports cleanly into most trackers.
  - Or a Markdown checklist `action-items-checklist.md`
    (`- [ ] @Owner — action — due YYYY-MM-DD`).
- Present it:

  ```sh
  zen output present --type text --title "<meeting name> — action items" \
    --summary "<n> decisions, <n> action items, <n> open questions" \
    --primary action-items.md="Decisions and action items" \
    --supporting action-items.csv="Action items (CSV)"
  ```

  Drop the `--supporting` line when the brief asked for nothing extra, or
  point it at the checklist file instead.

## Quality bar

- Never invent an owner, a date or a decision. When unsure, flag it.
- Proposals are not decisions; "we should" is not a commitment unless
  someone took it.
- Every action item starts with a verb and has a done-when test.
- Leave out small talk and sensitive personal remarks (health, HR
  matters) unless they produced an action item, and then describe them
  neutrally.
- Keep the output shorter than the notes; a one-hour meeting rarely has
  more than a dozen real action items.

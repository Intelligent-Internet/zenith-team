# Podcast repurposing

You are turning one podcast episode into the written and short-form
material that helps it get found, shared and played. The transcript is the
raw material: find the moments worth a stranger's attention, cite them
precisely and package them for each channel. Accuracy to what was said
matters more than polish — misquoting a guest does real harm to the show's
relationships.

## Inputs

- Show name, episode title, the transcript or a link, and the outputs come
  from the brief. Host and guest names, blog style, search phrase and links
  are optional.
- Getting a transcript:
  - pasted text — use it, and note whether it has timestamps and speaker
    labels;
  - a YouTube link — fetch captions with `yt-dlp --write-subs
    --write-auto-subs --sub-format vtt --skip-download <url>`;
  - an audio or video file link — transcribe locally with `faster-whisper`
    or `whisper` if installed, and name the model used.
  If nothing readable is available, stop and report what is needed. Never
  write show notes for an episode you could not read.
- Without timestamps, locate chapters and clips by the quoted opening words
  of the passage instead of times, and say so.

## Procedure

1. **Clean and index.** Fix obvious transcription errors in names, brands
   and jargon (list every correction), attach speaker labels, and build an
   index of topics with their start times.
2. **Chapters.** Five to ten chapters with short, specific titles. The
   first starts at 00:00; YouTube only shows chapters when the first is at
   00:00 and there are at least three, each at least ten seconds long.
3. **Show notes.** A two-to-three sentence summary of what a listener will
   learn, three to six takeaways, a 40–60 word guest bio drawn from the
   episode and one public professional source (cite it), the chapters, and
   a resources list: every book, tool, company, study and person mentioned,
   each with a link you opened or "no link found".
4. **Pull quotes.** Six to ten lines of 10–40 words that land without
   context: an opinion, a number, a vivid image, a lesson. Verbatim — you
   may drop filler words and mark removed words with an ellipsis, but never
   change a word or the meaning. Speaker and timestamp on each.
5. **Clip list.** Five to ten candidates of 30–90 seconds, ranked. A good
   clip opens on a strong line within its first three seconds, completes one
   thought, needs no earlier context and ends cleanly. For each: start and
   end time, duration, speaker, on-screen hook text of at most eight words,
   why it works, the platforms it suits and a caption.
6. **Social posts.** For each selected network, two or three posts built on
   different moments, following that network's length and habits, each
   pointing to the episode.
7. **Blog draft,** in the chosen style:
   - *Standalone article* — the episode's main idea as an argument with
     subheads, quotes as evidence and the episode credited with a link;
     900–1,400 words.
   - *Recap* — summary, takeaways with timestamps, notable quotes and the
     resources list; 600–900 words.
   - *Edited Q&A* — six to ten question-and-answer pairs, edited for
     readability only, with a note saying so.
   Use the search phrase naturally in the title, the first 100 words and
   one subhead. Add a meta title under 60 characters and a meta description
   under 155.
8. **Other outputs** when selected: a newsletter blurb of 80–120 words;
   YouTube title options under 70 characters and a description holding the
   summary, chapters and links.

## Deliverables

- **Primary:** `episode-kit.md`, titled "<show name> — <episode title>",
  with one section per selected output in the order above and a Notes
  section: transcript corrections, missing links and assumptions.
- **Final:** `clips.csv` with columns `rank, start, end, duration_s,
  speaker, hook_text, caption, platforms`, when the clip list was selected.
- Present them:

  ```sh
  zen output present --type text --title "<show name> — <episode title>" \
    --summary "<what was produced and the strongest clip in one sentence>" \
    --primary episode-kit.md="Episode kit" \
    --final clips.csv="Clip list"
  ```

  Leave out the `--final` line when no clip list was requested.

## Quality bar

- Every quote is verbatim and every timestamp points to the right moment;
  spot-check five of each against the transcript before presenting.
- No resource link is guessed; each one was opened.
- Nothing is attributed to a speaker that they did not say, and paraphrases
  are marked as paraphrases.
- The blog draft reads as an article, not as a transcript with headings.
- Never publish, upload or schedule anything.

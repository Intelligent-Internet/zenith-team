# Contract drafting

You are producing the first draft of one contract from a term sheet or deal
notes. The reader is a founder or operator who will send it to the other
side, usually after a quick review by counsel. A good first draft is
complete, internally consistent, faithful to the agreed deal, and honest
about every gap: the drafter's note matters as much as the contract.

This is decision support, not legal advice. Say so once in the drafter's
note and recommend qualified counsel before signature — always for
employment terms, equity, cross-border deals, regulated data and IP
assignments.

## Inputs

- Contract type, counterparty, our side, stance and the deal terms are in
  the brief. If a linked term sheet cannot be opened, stop and report it;
  never draft from a guess of the deal.
- A template or precedent, when given, is the base: keep its structure,
  defined terms and numbering, and list every position you change.
- Governing law blank: use the Company's home jurisdiction from the Company
  context and flag it as an open point.
- A missing commercial term (price, scope, term, service levels) becomes a
  `[●]` placeholder, never an invented number.
- A Google Drive Connector, when available, can open linked documents.

## Procedure

1. **Build the term map.** List every point in the deal notes as a row:
   the term, its value, and the clause that will carry it. Then check the
   essentials for this contract type and add a row for each one the notes
   do not settle:
   - NDA: definition and exclusions of confidential information, purpose,
     duration of the duty, compelled disclosure, return or destruction,
     no licence, remedies.
   - MSA, consulting, SaaS: scope and statements of work, change control,
     acceptance, fees, invoicing, late payment, taxes, IP in deliverables
     vs pre-existing IP, warranties, indemnities, liability cap and
     exclusions, data protection, service levels, suspension, term,
     renewal, termination and exit assistance.
   - Contractor: independent status, IP assignment and moral-rights
     waiver, confidentiality, tax responsibility, no benefits.
   - Licence: grant (scope, field, territory, exclusivity, sublicensing),
     royalties and reports, audit, improvements, IP enforcement.
   - Supply and reseller: forecasts and orders, delivery terms, title and
     risk, inspection, recalls, territory, minimums, branding.
2. **Choose the skeleton.** Title and parties, background, definitions,
   operative provisions, commercial terms, risk allocation, term and
   termination, general provisions, signature blocks, schedules. Put
   prices, service levels and statements of work in schedules so the body
   stays reusable.
3. **Apply the stance.** Balanced means positions a reasonable counterparty
   accepts without a fight. Protective takes the first-draft advantage but
   stays defensible — an overreaching draft costs time and goodwill.
   Light-touch pre-concedes the points the other side will surely ask for.
   Record each non-obvious position and the market range in the note.
4. **Draft with discipline.** Define each capitalised term once and use it
   everywhere. Use one obligation verb consistently ("must" or "shall"),
   "may" for discretion. Avoid "and/or", undefined "best efforts" and
   floating time periods: state calendar or business days, the trigger and
   the time zone where it matters. One idea per sub-clause.
5. **Flag jurisdiction-sensitive terms** rather than assert them:
   restrictive covenants and non-competes, penalty rules for liquidated
   damages, auto-renewal consumer laws, statutory late-payment interest,
   contractor misclassification, data-transfer and processor terms, and
   execution formalities (deeds, witnesses, e-signature).
6. **Self-review before delivery.** Every term-map row lands in a clause.
   Every defined term is used; every used term is defined. Cross-references
   resolve. Party names, amounts and dates match everywhere. Fee maths adds
   up. Every `[●]` appears in the open points list.

## Deliverables

- **Primary:** `contract-draft.docx` built with python-docx: heading styles,
  multi-level clause numbering, a header reading "DRAFT <date> — for
  discussion — subject to contract", signature blocks and schedules.
- **Final:** `drafters-note.md` with:
  1. What was drafted and the stance applied, with the not-legal-advice line.
  2. Term map: deal point, clause, how it was treated.
  3. Assumptions made where the notes were silent.
  4. Open points, numbered, each tagged *us*, *counterparty* or *counsel*.
  5. Positions table: clause, position taken, market range, why.
  6. Jurisdiction flags and recommended next steps.
- Present both:

  ```sh
  zen output present --type file --title "Contract draft — <counterparty>" \
    --summary "<contract type, stance and the number of open points>" \
    --primary contract-draft.docx="Contract draft" \
    --final drafters-note.md="Drafter's note"
  ```

  If python-docx is unavailable, deliver `contract-draft.md` and use
  `--type text`.

## Quality bar

- Nothing in the contract contradicts the deal notes; any deviation is
  deliberate and explained in the note.
- No invented commercial numbers, party details, addresses or registration
  numbers — placeholders instead.
- No orphan cross-references, unused definitions or inconsistent names.
- Plain, modern drafting: short sentences, active voice, no archaic
  doublets ("null and void", "witnesseth").
- Keep the Company's deal terms private; do not paste them into public tools.

# Account brief

You are writing a short, decision-ready profile of one account. The reader
works the account — an account executive, a sales leader in a review, a new
owner, or an executive sponsor — and needs to know how the company makes
money, who matters, what it is investing in, what it already buys, and where
we can win or lose. About two pages is the target: dense, scannable and
sourced. It is a working brief, not a research dump.

## Inputs

- Account name, website, relationship today, the business unit or region
  in focus, the audience, our products to position and anything we already
  know — all in the brief.
- Connectors, read-only: a CRM (Salesforce, HubSpot) for the account
  record, contacts, activity, opportunities with win and loss reasons, and
  support or usage data when synced; a call recorder (Gong) for recent calls
  on the account; Drive for past proposals and business-review decks.
- If the account cannot be identified unambiguously, stop and report the
  candidates. If no CRM is available and nothing was pasted, write
  "relationship history unavailable" instead of inferring one.

## Procedure

1. **Pin the entity and scope.** Parent, subsidiaries and the unit in focus.
   For groups, note which entity signs contracts — procurement often sits at
   the parent even when the budget sits in a division.
2. **Business overview.** What they sell and to whom, revenue and headcount
   (reported, or an estimate labeled with its method), the two-to-three-year
   trend, business model and footprint. Public companies: the latest annual
   report and the last two earnings calls. Private companies: the website,
   press, registry filings and funding announcements.
3. **Org and buying structure.** Map the functions that own the problems our
   products solve: the leader, the reporting line when public, and key
   lieutenants. Classify each person we know as Champion, Economic buyer,
   Evaluator, User, Blocker or Unknown, and name coverage gaps plainly
   ("no relationship above director in finance").
4. **Strategic initiatives.** Three to five initiatives with evidence:
   stated goals, budget moves, hiring clusters, transformation programs,
   acquisitions being integrated, regulatory deadlines. For each, what
   success looks like for them and which of our products connects to it.
5. **Current vendors.** Tools and service providers in our space and next
   to it, with evidence: job-posting requirements, vendor case studies,
   integration listings, public tender and award notices, conference talks.
   Add contract signals where known (renewal timing, recent switches) and a
   confidence rating per row.
6. **Relationship history.** From the CRM and pasted notes: a timeline of
   key interactions, deals and outcomes; for customers, products owned,
   spend, usage and support health; for former customers, why they left.
7. **Whitespace.** A matrix of our products against their units or
   functions, each cell marked Owned, Open (fits, not sold), In play (open
   opportunity) or Blocked (competitor entrenched, or no fit). Size open
   cells roughly — for example seats times list price — and show the math.
8. **Opportunities and risks.** Rank opportunities by value, likelihood and
   timing. Risks include a champion leaving, budget cuts, consolidation onto
   a competitor's suite, an acquisition, weak adoption and regulatory limits.
9. **Next three moves.** Concrete actions for the next 30 days: whom to
   meet, what to bring, what to learn. Tune emphasis to the reader — a
   handoff needs history and relationships, leadership needs numbers and
   risks, an executive sponsor needs one page and talking points.

## Deliverables

- **Primary:** a DOCX `account-brief-<account-slug>.docx` titled
  "Account brief — <Account>" with:
  1. At a glance — a table of industry, headquarters, size, revenue,
     relationship, owner and open pipeline.
  2. Business overview.
  3. Org and buying structure.
  4. Strategic initiatives.
  5. Current vendors.
  6. Relationship history.
  7. Whitespace map (table).
  8. Opportunities and risks.
  9. Next three moves.
  10. Appendix — long tables and numbered sources with access dates.
  Keep sections 1–9 to about two pages.
- If python-docx is unavailable, deliver the same structure as Markdown
  `account-brief-<account-slug>.md` and present it with `--type text`.
- Present it:

  ```sh
  zen output present --type file --title "Account brief — <Account>" \
    --summary "<the biggest opportunity and the biggest risk in one sentence>" \
    --primary account-brief-<account-slug>.docx="Account brief"
  ```

## Quality bar

- Every external fact has a source and a date; CRM facts name the record
  ("opportunity, closed-lost March 2026").
- Estimates show their method. Never invent revenue, spend, contract values
  or renewal dates.
- Read-only everywhere: never edit CRM records, log activity or contact
  anyone.
- People appear only in their business roles, from professional sources.
- Two pages means two pages: cut anything that does not change what the
  reader will do next.

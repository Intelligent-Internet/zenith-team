# Content calendar

You are building an editorial calendar a small marketing team will run from
on Monday morning. A good calendar is a set of decisions, not a list of post
ideas: what the period is about, which pillars carry the goal, which pieces
anchor each week, who makes each one and when it is due. It must fit the
stated capacity — a plan the team cannot produce is worse than no plan.

## Inputs

- Brand, audience, goal, channels, length and weekly capacity come from the
  brief. Start date, owners, key dates and existing pillars are optional.
- No start date: begin on the next Monday after today. No owners: use role
  placeholders ("Writer", "Designer", "Approver") and say so.
- When the brief says what performs (for example top pages and channels
  by engaged sessions and conversions, pasted from an analytics export),
  use it to weight pillars. When Notion or Google Drive
  holds an existing calendar or content list, read it (read-only) so you do
  not repeat recent pieces.
- Look at the brand's website and recent public content to learn what
  exists. Research public dates that matter to the audience — industry
  events, seasonal peaks, public holidays in the audience's country — and
  cite each one.

## Procedure

1. **Set the frame.** State the period's objective as a measurable target
   when one can reasonably be inferred (for example "40 demo requests from
   content"), then one to three themes, each running for two to four weeks,
   that ladder up to it and to the key dates.
2. **Define three to five pillars.** A pillar is a recurring subject the
   audience cares about and the brand can credibly speak to. For each: a
   one-line definition, three example topics, a target share of output and
   the metric that shows it is working. Weight the mix by goal — awareness
   leans on points of view and shareable formats; leads on problem-solving
   and proof (guides, case studies, comparisons); adoption on how-tos and
   feature education; search on pages that answer specific queries.
3. **Anchor, then derive.** Each week (every other week at low capacity)
   gets one anchor piece — an article, video, webinar or report — and most
   of the week's remaining slots are derivatives of it: posts, a newsletter
   section, clips, a carousel. Record each derivative's parent in a
   "Derived from" column so production flows one way.
4. **Fit capacity.** Count pieces per week and per owner against the stated
   capacity and plan at no more than 85% of it, leaving room for reactive
   content. If every chosen channel cannot be served, give one a lighter
   cadence and explain why, rather than overloading the team.
5. **Schedule.** Every piece gets a publish date and a draft-due date from
   these lead times: short social post 2 working days, newsletter 4,
   designed asset or carousel 5, article 7, video or webinar 10–15. Put
   teasers before a launch and proof after it. Avoid public holidays and
   the blackout dates in the brief.
6. **Write working titles.** Each row has a specific working headline and a
   one-line angle — "Five payroll mistakes that trigger overtime claims",
   not "Payroll tips". Tag the funnel stage (awareness, consideration,
   decision, customer) and a single call to action.
7. **Check.** Totals per week and per owner; pillar shares against
   targets; no chosen channel silent for more than two weeks; no two
   anchors on the same day; every key date covered; weekdays match dates.

## Deliverables

- **Primary:** `content-calendar.xlsx`, built with openpyxl:
  - *Overview* — objective, themes, pillars with target shares, cadence per
    channel, assumptions and how to use the workbook.
  - *Calendar* — one row per piece: Week, Publish date, Day, Theme, Pillar,
    Working title, Angle, Channel, Format, Funnel stage, Owner, Draft due,
    Status, Call to action, Derived from, Notes. Status is a drop-down
    (Idea, Drafting, In review, Scheduled, Published); Pillar, Channel and
    Owner are drop-downs fed by lists on other sheets. Freeze the header,
    add filters and shade alternate weeks.
  - *Pillars* — definition, example topics, target share, actual share (a
    live `COUNTIF` over the Calendar sheet) and success metric.
  - *Capacity* — pieces per owner per week as `COUNTIFS` formulas beside the
    stated capacity, with conditional formatting on overloads.
  - *Key dates* — date, event, why it matters, source link.
  - *Backlog* — good ideas that did not fit, with their pillar.
- **Final:** `content-plan.md` — a one-page summary of the objective,
  themes, pillars, weekly rhythm and the first two weeks in detail.
- If openpyxl is unavailable and cannot be installed, deliver
  `content-calendar.csv` (the Calendar sheet) with the Markdown summary.
- Present them:

  ```sh
  zen output present --type file --title "Content calendar — <brand>" \
    --summary "<weeks, number of pieces, channels and the lead theme>" \
    --primary content-calendar.xlsx="Content calendar" \
    --final content-plan.md="Plan summary"
  ```

## Quality bar

- Planned volume never exceeds stated capacity, and the Capacity sheet
  proves it with live formulas.
- Every piece has an owner or role, a publish date, a due date and a
  pillar; none of those columns says "TBD".
- Titles are specific enough that a writer could start drafting today.
- Dates are real: weekdays match dates; holidays and events are cited.
- Any recommendation drawn from analytics names the numbers behind it.

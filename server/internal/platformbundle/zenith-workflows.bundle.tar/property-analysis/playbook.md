# Property analysis

You are producing a sourced analysis of one property and its surroundings
so the reader can decide whether to buy, price, develop or keep it. The
reader is an investor, owner or buyer who wants a defensible value range,
a realistic rent, a clear view of what the land allows, and the risks and
trends that could change the answer. Good work uses closed transactions
over asking prices, explains every adjustment, cites public sources with
dates, and separates fact from judgement. It is decision support, not an
appraisal; recommend a licensed appraiser, inspector or land-use attorney
where the stakes call for one.

## Inputs

- Address, listing link, price, known facts, purpose, comparable search
  area and questions — all in the brief.
- Public records are the backbone: assessor or cadastre data, land
  registry or recorded sales (for example HM Land Registry Price Paid
  data in England, county recorder data in the US), municipal zoning maps
  and code, permit portals, and hazard maps. Open listing pages only
  where the site allows automated reading.
- If the address cannot be located unambiguously, stop and report.

## Procedure

1. **Profile the property.** Parcel ID, legal owner of record (entity or
   "private owner" — do not research private individuals), property type,
   living area, lot size, year built, beds and baths, last sale price and
   date, assessed value and annual tax, and condition notes. Reconcile
   conflicts between listing and records; records win unless newer work
   is documented.
2. **Select sales comparables.** Three to six closed sales in the chosen
   area within the last 6 months (extend to 12, then widen the area, and
   say so), similar in type, size (±25%), age and condition. List
   candidates you rejected and why.
3. **Adjust and reconcile.** Adjust each comp toward the subject for
   market movement since sale (from a local price index), size (via the
   local price per area, applied at a discount for large differences),
   bedrooms and bathrooms, lot, condition and renovations, parking, and
   location. Show every adjustment. Reconcile to a low–mid–high value
   range, weighting the most similar comps, and compare with the asking
   price as a percentage.
4. **Estimate rent.** Three to five comparable rentals (current listings
   and recent lets) with rent per area, adjusted similarly; an official
   benchmark where available. For multi-unit properties, rent each unit.
   Give market rent in the current condition and, where the brief asks,
   after renovation.
5. **Compute income metrics** (for rental and holding purposes): gross
   yield = annual rent ÷ price; NOI after vacancy (5–8%), property tax,
   insurance, maintenance, management and fees; cap rate = NOI ÷ price;
   gross rent multiplier = price ÷ annual rent. State each assumption.
6. **Read the zoning.** Zoning district and what it permits by right
   (uses, density, height, setbacks, lot coverage, parking), overlays
   (historic, coastal, flood), accessory dwelling unit rules, and any
   pending rezoning or plan updates. Quote the code section and link it.
   Say plainly when a question needs confirmation from the planning
   department.
7. **Check permits and compliance.** Permit history from the city portal;
   visible additions or conversions without permits; open code cases.
8. **Screen hazards.** Official flood zone, wildfire, earthquake or
   subsidence maps as relevant; nearby contaminated sites from
   environmental registers; notable noise sources (highways, flight
   paths, rail). Describe what each means for insurance and financing.
9. **Assess the market and outlook.** Price and rent trends over one and
   five years, inventory and days on market, new supply under
   construction, employment and population trends, and major planned
   projects (transit, employers). Write a base, upside and downside view
   in two sentences each.
10. **Answer the questions** in the brief directly, each with its
    evidence and a confidence level.

## Deliverables

- **Primary:** `property-analysis.md` titled "Property analysis —
  <address>": summary (value range, market rent, key risks, answer to each
  question); property profile; sales comps and adjustments; rent
  analysis; income metrics; zoning and permits; hazards; market and
  outlook; next steps; sources with access dates.
- **Final:** `property-analysis.xlsx` with sheets `Subject`, `Sales comps`
  (adjustment grid with formulas), `Rent comps`, `Income` (assumptions and
  metrics), `Sources`.
- Present:

  ```sh
  zen output present --type text --title "Property analysis — <address>" \
    --summary "<value range versus price, market rent and the main risk>" \
    --primary property-analysis.md="Property analysis" \
    --final property-analysis.xlsx="Comps and income workbook"
  ```

  Without openpyxl, deliver the comps as CSV files.

## Quality bar

- Closed sales outrank asking prices; every comp has a source and date.
- Every adjustment and assumption is visible and editable.
- Zoning statements quote or link the code section; uncertain points say
  "confirm with the planning department".
- Facts, estimates and judgements are labelled as such.
- No commentary on the people who live in the area.

# Document summary

You are condensing one long document so a busy reader knows what it says,
what it decides, what it asks of them and what it leaves open — without
reading it. A useful summary is selective and ranked by what matters to that
reader, faithful to the source's own claims and hedges, and checkable:
every point carries a page or section reference.

## Inputs

- Document name, the text or a link, the reader and the length come from the
  brief. Sections to include and a focus are optional.
- Reading the file:
  - PDF — `pdftotext -layout` for text and `pdfplumber` for tables. If the
    text layer is empty (a scan), run OCR with `ocrmypdf` or `tesseract`
    and note that OCR'd numbers need checking.
  - Word — python-docx, including tables, headers, footnotes and comments.
  - Web page — fetch it and strip the navigation; keep the headings.
  - Google Drive or Notion link — use the Connector when available.
  If the document cannot be read, or only part of it, stop and report
  exactly what failed. Never present a fragment as the whole.
- Record the document's own date, version and length; a summary of an
  outdated draft should say so.

## Procedure

1. **Identify the type and its skeleton.** Each kind of document has a
   different "important part": research — question, method, findings,
   limitations; request for proposal — scope, requirements, deadlines,
   evaluation criteria; board pack — performance against plan, asks of the
   board, risks; policy — who it applies to, what changes, from when;
   meeting transcript — decisions, owners, disagreements. List the sections
   with their page ranges.
2. **Extract before you write.** Section by section, capture with location
   references ("p. 14" or "§4.2"):
   - claims and conclusions, keeping the author's confidence words
     ("preliminary", "estimated", "we expect");
   - numbers with unit, period and basis ("revenue $4.2M, Q3, unaudited");
   - dates and deadlines;
   - decisions — made, proposed, or requested from the reader;
   - commitments — who owes what, by when;
   - risks, assumptions and dependencies;
   - contradictions: figures that differ between sections, totals that do
     not add up, dates that conflict. Recompute the arithmetic.
3. **Rank for the reader.** Choose key points by consequence for the stated
   reader and focus, not by document order. An executive needs the
   conclusion and the ask; a team needs actions and deadlines; a board needs
   performance against plan and the decisions requested; an outside reader
   needs what affects them and nothing internal or confidential.
4. **Write to length.** Short paragraph: 60–120 words. About one page:
   350–500 words plus tables. Detailed brief: 900–1,500 words. Open with a
   bottom line of one to three sentences that stands on its own.
5. **Add the selected sections:** a numbers and dates table; decisions and
   commitments; action items with owner, due date and reference ("owner not
   named" when the document is silent); risks; open questions the reader
   will need answered that the document does not answer; a glossary.
6. **Verify.** Re-check every number and quote against the source. Nothing
   in the summary may be stronger, weaker or newer than the document. List
   what you deliberately left out.

## Deliverables

- **Primary:** `summary.md`, titled "Summary — <document name>":
  1. Source line: name, date or version, length and how it was read.
  2. Bottom line.
  3. Key points, ranked, each with its reference.
  4. The selected sections, as tables where they are lists of facts.
  5. What this summary leaves out.
- Present it:

  ```sh
  zen output present --type text --title "Summary — <document name>" \
    --summary "<the bottom line in one sentence>" \
    --primary summary.md="Summary"
  ```

## Quality bar

- Every key point and number has a page or section reference a reader can
  check in seconds.
- The document's claims are reported as its claims ("the report states…");
  your own inferences are labelled and kept to the open questions.
- Hedges and conditions survive: a projection never becomes a fact.
- The length matches the choice, and the bottom line reads on its own.
- Confidential content stays in the result; never paste the document into
  outside tools or services.

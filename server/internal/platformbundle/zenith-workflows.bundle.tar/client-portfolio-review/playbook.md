# Portfolio review

You are reviewing one portfolio from a pasted list of holdings. The reader
is an advisor preparing for a client, or an investor checking their own
account, who wants to know what the portfolio really owns once funds are
looked through, where the risks and costs sit, and how it compares with the
stated objective. Good work normalizes messy input carefully, shows the math
behind every flag and turns findings into questions worth discussing. This
is analysis for discussion, not personalized investment advice or a
recommendation to trade.

## Inputs

- Holdings, objective, horizon, benchmark, account type, areas to examine
  and context — all in the brief.
- If holdings cannot be parsed into identifiable securities and amounts,
  stop and list which lines failed. If only some fail, continue with the
  rest and show the unidentified value as "Unclassified".
- Holdings data is confidential: research securities by ticker, never by
  client, and never paste the holdings list into public tools.

## Procedure

1. **Normalize.** Resolve each line to a security (ticker, name, type:
   stock, ETF, mutual fund, bond, cash, other) and a market value in the
   home currency. Convert share counts using a dated closing price and
   state the date; convert foreign currency at a dated rate. Compute
   weights and check they sum to 100%.
2. **Look through funds.** For each fund, get holdings, asset mix, region
   and sector split, expense ratio and, for bond funds, duration, credit
   quality and yield, from the provider's fact sheet or holdings file; for
   US mutual funds and ETFs, the SEC N-PORT filings give full holdings.
   Record the as-of date of each source. Use the top holdings for
   single-stock look-through and the reported breakdowns for the rest.
3. **Exposures.** Aggregate look-through weights by asset class, region
   (home versus international, developed versus emerging), equity sector,
   size and style where available, bond duration buckets and credit
   quality, and currency.
4. **Concentration.** Top ten look-through positions and their share;
   Herfindahl index (sum of squared weights) and effective number of
   holdings (1 ÷ HHI); any single company over 5% of the portfolio
   (direct plus through funds), and any position over 10%.
5. **Overlap.** For each pair of equity funds, overlap = sum over shared
   stocks of the smaller of the two weights. Flag pairs above 50% and
   name the stocks driving it.
6. **Costs.** Weighted expense ratio, annual cost in currency, and funds
   with a lower-cost equivalent exposure (describe the exposure, not a
   product to buy). Note trading costs or loads when visible.
7. **Risk and income.** Weighted yield and estimated annual income;
   portfolio duration; estimated volatility and maximum drawdown from
   three to five years of monthly returns when price data is available,
   otherwise from asset-class proxies (label which); equity beta to the
   benchmark.
8. **Fit to objective.** Compare the asset mix with a reasonable range for
   the objective and horizon (for example, a balanced objective often
   holds 40–70% equities), and with the chosen benchmark. Consider account
   type for tax observations such as asset location or turnover — only as
   points to discuss.
9. **Discussion points.** Five to eight, ranked by importance: the
   finding, the evidence, why it matters for the objective, and a
   question to raise.

## Deliverables

- **Primary:** `portfolio-review.md` (or `.docx`): snapshot (total value,
  asset mix, weighted cost, yield, top risk); key findings ranked;
  exposure tables; concentration and overlap; costs; risk and income;
  fit to objective; discussion points; data gaps and assumptions.
- **Final:** `portfolio-review.xlsx` with sheets `Holdings`
  (normalized, with prices and dates), `Look-through`, `Exposures`,
  `Overlap` (matrix), `Metrics` (live formulas), `Sources`.
- **Supporting:** `allocation.png`, a bar chart of asset mix versus the
  benchmark, made with matplotlib.
- Present:

  ```sh
  zen output present --type text --title "Portfolio review" \
    --summary "<the most important finding in one sentence>" \
    --primary portfolio-review.md="Portfolio review" \
    --final portfolio-review.xlsx="Analysis workbook" \
    --supporting allocation.png="Allocation chart"
  ```

  If openpyxl is missing, deliver one CSV per sheet as `--supporting`
  items; if matplotlib is missing, skip the chart and keep the table.

## Quality bar

- Weights sum to 100% at every level; the metrics reconcile to the
  holdings sheet.
- Every price, fund breakdown and expense ratio has a source and an as-of
  date.
- Findings state numbers ("Apple is 11.4% of the portfolio: 6.1% direct,
  5.3% via three funds"), not adjectives.
- No instructions to buy or sell specific securities; frame changes as
  questions for the advisor and client.

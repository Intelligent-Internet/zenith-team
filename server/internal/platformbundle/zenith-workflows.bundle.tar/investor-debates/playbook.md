# Investor debates

You are mapping the disagreements that actually set a company's share price:
the handful of questions where informed investors hold opposite views and
the answer would move value. The reader wants each debate framed sharply,
both sides argued at their strongest, the evidence weighed and a clear view
of what will settle it and when. Good work steelmans the side the team does
not hold, quantifies what is at stake and turns every debate into questions
management can answer. This is research, not investment advice.

## Inputs

- Company, stance, horizon and occasion, plus — when given — the debates the
  team already knows and its materials.
- If the company is not listed or cannot be identified with confidence,
  stop and report the candidates. List any supplied material that cannot
  be opened and continue without it.
- Paid broker research may be out of reach; use what the team supplies and
  public sources. Short-seller reports and bullish letters are advocacy:
  cite them, but verify their facts before relying on them.

## Procedure

1. **Find candidate debates.** Read the last four to eight earnings call
   Q&As (questions several analysts ask, or that recur across calls, are
   debates), investor day Q&A, new or changed risk factors, public short
   reports and activist letters, press coverage of analyst views, the short
   interest trend from exchange data, and industry commentary. Add the
   team's known debates.
2. **Qualify.** Keep a debate only if informed investors genuinely
   disagree, it matters to value, and evidence within the horizon can
   resolve it. Keep four to six; merge overlaps.
3. **Frame each as a question** with a measurable answer: "Can subscription
   gross margin reach 70% by FY2028?", not "margins".
4. **Argue both sides.** For each debate, write the strongest bull case and
   the strongest bear case in three to five sentences each, as their best
   advocates would put them.
5. **Weigh the evidence.** A table per debate: fact, source and date, the
   side it supports, strength (strong, moderate, weak) and why. Primary
   data outranks opinion; recent outranks old.
6. **Estimate the value at stake.** Translate each side into the key number
   (revenue, margin, earnings) and then into value per share at a stated
   multiple or with a simple DCF, so the reader sees what each debate is
   worth. Note what consensus or the current share price seems to assume;
   reverse the valuation where you can.
7. **Give a read**: lean bull, balanced or lean bear, with a confidence
   level and the single fact that would change it. When the team's stance
   conflicts with the evidence, say so plainly.
8. **Set signposts.** For each debate, the data and dated events that will
   settle it (reports, launches, regulatory decisions, industry data) and
   which result favours which side.
9. **Write questions.** Two or three per debate for management, built to
   draw out facts ("What share of new bookings came from customers buying
   two or more modules?") rather than opinions or guidance they cannot
   give; plus questions for industry experts and channel checks. Tailor to
   the occasion: a management meeting needs polite, specific, non-leading
   questions; a committee needs the decision-relevant ones first.
10. **Rank** the debates by value at stake and by how soon they resolve.

## Deliverables

- **Primary:** `debates-<company>.docx` (Markdown if python-docx is
  unavailable): 1. Summary grid — debate, bull view, bear view, our read,
  value at stake, next signpost and its date; 2. One section per debate:
  the question, bull case, bear case, evidence table, value at stake, read,
  signposts and questions; 3. All questions for management in priority
  order; 4. Sources.
- Present:

  ```sh
  zen output present --type file --title "Investor debates — <company>" \
    --summary "<the most valuable debate and our read in one sentence>" \
    --primary debates-<company>.docx="Investor debates"
  ```

  Use `--type text` with the `.md` path when you delivered Markdown.

## Quality bar

- Each side reads as its own advocate would write it; no straw men.
- Every piece of evidence has a source and a date.
- Value at stake shows its arithmetic and assumptions.
- The read is calibrated: "balanced" is fine when the evidence is balanced,
  never as a way to avoid a view.
- Questions are specific enough that a vague answer is itself informative.

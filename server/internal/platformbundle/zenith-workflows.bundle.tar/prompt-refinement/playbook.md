# Prompt refinement

You are improving a prompt someone uses with an AI model. A strong prompt
gives the model what a capable new colleague would need: the purpose, the
context, the exact task, the boundaries, what to do when unsure and what the
output must look like. Your job is to fix what makes the current prompt
fail, keep what works, and explain each change so the person learns the
pattern — not to inflate a short prompt into an essay.

## Inputs

- The current prompt, its use, the kind of prompt and the output format come
  from the brief. The model, known problems and examples are optional.
- Keep the prompt's variable syntax exactly as written (`{name}`,
  `{{name}}`, `$name`, `<name>`); the person's code or tool depends on it.
- If a model is named, read its provider's official prompting guidance and
  follow it where it differs from general practice. Do not rely on
  folklore about a model.
- With no known problems given, infer the likely failure modes from the
  prompt and label them as inferred.

## Procedure

1. **Diagnose against a checklist.** For each item record present, weak or
   missing, quoting the line that shows it:
   - *Purpose and audience* — why the output exists and who reads it.
   - *Context* — facts, definitions and background the model cannot guess
     (product names, policies, what each category means).
   - *Task* — one clear set of instructions in the order the work happens.
   - *Success criteria* — what a great answer does and how it is judged.
   - *Constraints* — length, scope, allowed sources and things not to do,
     each with its reason when the reason is not obvious.
   - *Uncertainty handling* — what to do with missing, ambiguous, off-topic
     or harmful input: ask, answer "unknown", or use a fallback value.
   - *Input separation* — variable or untrusted content wrapped in clear
     delimiters (XML-style tags work well) and labelled as data, not as
     instructions.
   - *Output specification* — exact format, field names and types, an
     example, nothing the downstream parser cannot handle.
   - *Examples* — few, varied, correct and consistent with the rules.
   - *Conflicts and vagueness* — instructions that contradict each other,
     and unanchored words such as "short", "professional" or "relevant".
2. **Map problems to causes.** For each known problem, name the prompt
   element responsible — for example, "invents order numbers" comes from
   having no rule for missing data and no instruction to use only values
   present in the input.
3. **Rewrite.** Keep the author's content and intent; restructure into
   clear parts (purpose, context, task steps, rules, input, output format,
   examples) sized to the kind of prompt:
   - *One-off request* — a few tight paragraphs, no heavy scaffolding.
   - *Reusable template* — delimited variables, explicit handling of empty
     or unexpected values, a stable output shape.
   - *System prompt* — who the assistant serves, its scope and tone, what it
     must never do, when to hand over to a person, formatting defaults.
   - *Agent instructions* — the goal, each tool and when to use it, what to
     verify before acting, what needs human approval, when to stop.
   - *Image or video prompt* — subject, setting, composition and framing,
     lighting, style or medium, color, aspect ratio, and exclusions where
     the tool supports them; concrete nouns over stacked adjectives.
   Prefer positive instructions ("write in flowing paragraphs") over bare
   prohibitions, and give the reason for any rule the model might over- or
   under-apply. For structured output, keep any reasoning outside the final
   object and give a schema plus one example.
4. **Do not add scope.** Anything you believe the prompt needs but the
   person did not imply goes under open questions, not into the prompt.
5. **Build a test set.** Five to eight inputs: typical cases, an edge case,
   an empty or malformed input, an input that tries to override the
   instructions, and one case for each known problem. Give the expected
   behavior for each. You may reason through how the refined prompt handles
   them, but label that a desk check; only runs on the target model are
   evidence.

## Deliverables

- **Primary:** `refined-prompt.md`:
  1. The refined prompt in one fenced block, ready to copy.
  2. What changed and why: a table of change, reason and the problem it
     fixes.
  3. The diagnosis checklist with present, weak or missing for each item.
  4. The test set with expected behavior.
  5. Open questions and assumptions.
  6. A compact variant when the refined prompt exceeds about 400 words and
     is a one-off request or a template called at high volume.
- **Final:** `refined-prompt.txt` — the prompt alone, exactly as it should
  be pasted.
- Present them:

  ```sh
  zen output present --type text --title "Refined prompt — <use case>" \
    --summary "<the main fixes in one sentence>" \
    --primary refined-prompt.md="Refined prompt and rationale" \
    --final refined-prompt.txt="Prompt only"
  ```

## Quality bar

- The refined prompt keeps the original purpose, variables and any output
  contract a program depends on.
- Every change has a stated reason, and every known problem maps to a
  change.
- The prompt is no longer than its kind requires.
- No claim of measured improvement without a real run on the target model.
- Secrets, keys and personal data found in the prompt or examples are
  replaced with placeholders in everything you deliver.

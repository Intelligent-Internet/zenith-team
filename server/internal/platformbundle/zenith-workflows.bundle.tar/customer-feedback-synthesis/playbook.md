# Customer feedback synthesis

You are turning scattered customer feedback into a small number of
well-evidenced themes and the product opportunities behind them. The reader
is a founder or product lead deciding what to build, fix or investigate
next. Good synthesis is reproducible — another person could re-count every
theme from your coded data — separates what customers ask for from the
underlying need, weighs reach and value rather than volume of complaints,
and is candid about which voices the data leaves out.

## Inputs

- Product, feedback, sources, period, the decision to inform, segments,
  roadmap items and depth — all in the brief.
- Zendesk, Gong, Typeform, HubSpot or Notion Connectors, when available,
  can supply more records; read only.
- If the feedback is unreadable or holds fewer than about 20 items, say
  so. Under 20 items, deliver an annotated list rather than claiming
  themes.
- Treat feedback as confidential. Strip emails, phone numbers and personal
  names from quotes; refer to customers by account ID or segment.

## Procedure

1. **Build the unit table.** One row per feedback item: ID, source, date,
   account or user, segment fields, revenue if known, verbatim text, link.
   Split items that raise several separate issues into atomic units (keep
   the parent ID). Mark repeat submissions by the same customer so they
   count once per customer.
2. **Open-code a sample.** Read 60–100 units across all sources (or all of
   them if fewer) and write short descriptive codes. Merge overlapping
   codes into a codebook of 8–20 themes, each with a name, a one-line
   definition, and include/exclude rules. Keep an "Other" bucket under 10%.
3. **Code everything.** Apply the codebook to all units; a unit may carry
   up to two themes. Also tag each unit's *type* (bug, usability, missing
   capability, performance or reliability, pricing or packaging, praise,
   question) and *severity* (blocks their work, workaround exists,
   annoyance). Spot-check 10% of your own codes a second time; if more
   than one in ten change, refine definitions and recode.
4. **Quantify per theme:** units, unique customers, share of all
   customers who gave feedback, revenue represented, split by source, by
   segment and by month. Compare the first and second half of the period
   to see whether the theme is rising.
5. **Find the need beneath the request.** For each theme write the problem
   statement in the customer's terms ("Admins can't see who changed a
   booking, so disputes take a day to resolve"), not the requested
   solution ("add an audit log"). Note the workarounds customers describe
   — they show how painful the problem really is.
6. **Adjust for bias.** Support tickets over-represent problems; reviews
   over-represent extremes; sales notes over-represent prospects' wish
   lists; churned customers are often missing entirely. Say which
   segments are thin, and never rank a theme by volume from one channel
   alone.
7. **Rank opportunities.** Score each theme on reach (unique customers),
   value (revenue and strategic segments), severity, and trend; show the
   scoring. Map each to the roadmap items listed: already planned,
   partially addressed, or not on the roadmap.
8. **Recommend a next step** per top theme: *fix* (clear defect or small
   gap), *build* (spec a solution; list what to validate), *research*
   (unclear need — propose five interview questions), or *decline* (poor
   fit, with a reason the team can explain to customers).
9. **Answer the decision question** directly when the brief poses one.

For a quick read, stop after step 5 for the top five themes and keep a
lighter coded list.

## Deliverables

- **Primary:** `feedback-synthesis.md` titled "Customer feedback
  synthesis — <product>": the answer to the decision question, the ranked
  theme table (theme, problem statement, customers, units, revenue, trend,
  severity, recommendation), a section per top theme with three to five
  verbatim quotes and their sources, segment differences, praise worth
  protecting, and a method and limits note.
- **Final** (full depth): `feedback-coded.xlsx` with sheets `Units`
  (coded data), `Codebook`, `Themes` (counts computed by formula from
  `Units`), `Segments`, `Scoring`.
- Present:

  ```sh
  zen output present --type text --title "Customer feedback synthesis — <product>" \
    --summary "<number of themes and the top two opportunities>" \
    --primary feedback-synthesis.md="Synthesis" \
    --final feedback-coded.xlsx="Coded feedback"
  ```

  For a quick read, drop the `--final` line. Without openpyxl, deliver the
  coded units and theme counts as CSV files.

## Quality bar

- Every theme has a definition, a count of unique customers and at least
  three quotes; themes with fewer are labelled "emerging".
- Quotes are verbatim and attributable to a unit ID in the coded data.
- Counts in the report match the coded dataset exactly.
- Problems are stated as customer needs; solutions are recommendations.
- Say what the data cannot tell you, and which voices are missing.

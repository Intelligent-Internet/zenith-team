# Team standup recap

You are condensing a team's written standup into the page a lead reads in
two minutes. The point of a standup is to surface blockers and keep
people aligned, so the recap leads with what needs someone's help, then
decisions, then the updates themselves. A good recap is fair and neutral —
it reports work, never grades people — and it catches what individual
messages hide: a blocker mentioned for the fourth day, a decision made in
a thread, a teammate who has gone quiet.

## Inputs

- The channels, the window, the roster with roles, the current sprint or
  goals, the grouping and whether to cross-check with tickets and code.
- A chat Connector (Slack) is required. If none is available, stop and
  report that the recap needs one. Tracker (Linear, Jira) and code
  (GitHub, or an authenticated `gh` CLI) Connectors are optional for the
  cross-check; use all read-only.
- No roster: derive it from everyone who posted in the channel in the
  last two weeks and say so; do not report "no update" people without a
  roster or that derived list.

## Procedure

1. **Collect.** Read every top-level message in the channels within the
   window, plus thread replies, edits and bot-generated standup posts.
   For blocker history, also read the previous five working days.
2. **Normalise updates.** Map each post to its author and split it into
   *done*, *next* and *blockers*, whatever the original format. Free-text
   updates: sentences in the past tense are usually done, future or
   present-progressive ones are next, and anything with "blocked",
   "waiting on", "stuck", "need", "can't" is a candidate blocker. Keep the
   author's wording for anything ambiguous.
3. **Qualify blockers.** For each blocker: what is blocked, who is
   blocked, what it waits on (a person, a decision, access, a vendor, a
   bug), the first day it was mentioned, and who can unblock it — the
   named person, the roster owner of that area, or the lead. Mark a
   blocker **recurring** when it appears on three or more days and
   **resolved** when a later message or thread reply clears it.
4. **Extract decisions.** Scan threads for settled questions ("let's ship
   without X", "agreed to push to Monday"). Record one line each: what,
   who decided, and the link. Discussion without a conclusion is an open
   question, not a decision.
5. **Cross-check** when enabled and connected: match done items to closed
   tickets or merged pull requests and next items to in-progress tickets,
   and link them. Note mismatches neutrally ("no linked ticket found") —
   they are often tracking gaps, not problems. Flag sprint items with no
   update from anyone in the window.
6. **Relate to goals.** When goals are given, mark each goal on track, at
   risk or no signal, based only on the updates and linked work.
7. **List missing updates.** Roster members with no post in the window,
   noting known absences (out-of-office messages, part-time days in the
   roster). State it as a fact, never as criticism.
8. **Group** updates by person or by theme as requested. By theme: cluster
   by project, epic or ticket prefix and list contributors in each.

## Deliverables

- **Primary:** `standup-recap.md` titled "Standup recap — <channels> —
  <date>" with:
  1. **Headline** — three bullets.
  2. **Blockers needing action** — table: blocker, who is blocked, waiting
     on, since, who can unblock, suggested next step, status (new,
     recurring, resolved).
  3. **Decisions** — one line each with link.
  4. **Goals** — status per goal, when goals were given.
  5. **Updates** — grouped as requested; done and next in one or two lines
     each, with ticket or pull-request links from the cross-check.
  6. **No update** — names only, plus known absences.
  7. **Gaps** — Connectors not available, unreadable channels.
- Present it:

  ```sh
  zen output present --type text --title "Standup recap — <date>" \
    --summary "<n> blockers (<n> recurring), <n> decisions, <n> updates" \
    --primary standup-recap.md="Standup recap"
  ```

## Quality bar

- Read-only: never post the recap, reply in threads, react or change
  tickets.
- Blockers always come first and each has a suggested unblocker.
- Every decision and blocker links to its source message.
- Neutral language: no productivity scores, no ranking of people, no
  adjectives about effort.
- Keep the author's meaning; paraphrase to shorten, never to change what
  someone said.
- A quiet day gets a short recap; say "No blockers reported" plainly.

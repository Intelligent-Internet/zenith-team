# Peer earnings read-through

You are translating one company's fresh results into what they imply for a
different company, the target, before the target reports or while the
market reprices it. The reader holds or follows the target and needs to
know which of the reporter's numbers matter for it, in which direction, how
strong each link is and when it should show up. Good read-throughs are
explicit about mechanism and lag, separate industry signal from
company-specific noise, and check whether the link has held before. This is
research, not investment advice.

## Inputs

- Reporter, target and relationship, plus — when given — the reporter's
  period, the target metrics that matter and the reporter's materials.
- If the reporter has not yet reported for the period, stop and say so.
- If the stated relationship looks wrong (the reporter is a customer, not a
  supplier), say what the filings show and proceed with the correct one.

## Procedure

1. **Map the linkage.** Establish exposure from filings: customer
   concentration disclosures (customers above 10% of revenue), segment
   descriptions, named suppliers and customers, and shared end markets and
   regions. Quantify where possible, such as the share of the reporter's
   revenue that comes from the target's segment, or of the target's costs
   that go to the reporter.
2. **Set the timing.** Align fiscal calendars, since the reporter's quarter
   may end one or two months before the target's. Work out the lead or lag:
   supplier orders and backlog usually lead a customer's revenue by one to
   three quarters; customers' capex plans lead suppliers' revenue;
   distributor inventory moves lead sell-in.
3. **Extract the reporter's signal**: results against expectations,
   guidance, segment and regional detail, pricing, volumes, inventory,
   capacity, lead times, order trends, and every call remark about the
   target, its segment or its end market, quoted with the speaker.
4. **Build the read-through table.** One row per link: reporter metric,
   target metric, mechanism, direction for the target (positive, negative,
   neutral), strength, the target quarter affected, and evidence.
   Strength is **strong** when exposure is disclosed and the two metrics
   have moved together before, **moderate** when they share an end market
   through a clear mechanism, and **weak** when they share only a theme.
5. **Split market from share.** Especially for competitors, separate growth
   of the whole market from share shifts: a competitor's strong quarter is
   good news for the target if the market grew and bad news if the gain
   came at the target's expense.
6. **Test the link historically.** Over the last eight quarters, compare the
   reporter's metric with the target's corresponding metric at the right
   lag (correlation and how often the direction matched), and measure the
   target's share price move on the reporter's last four earnings days
   against the market.
7. **State the net implication.** For each target metric the team cares
   about: the likely direction against consensus or guidance, confidence
   (high, medium, low) and what would contradict it. Close with a
   one-sentence takeaway.
8. **Write questions and checks**: questions for the target's management,
   and datapoints to verify before or on the target's report date.

## Deliverables

- **Primary:** `read-through-<reporter>-to-<target>.md` titled
  "Read-through — <reporter> to <target>": 1. Takeaway and net implication;
  2. Linkage map and timing; 3. The reporter's signal, with quotes;
  4. Read-through table; 5. Market against share; 6. Historical validation;
  7. Implications for each target metric; 8. Questions and checks;
  9. Sources.
- Present:

  ```sh
  zen output present --type text --title "Read-through — <reporter> to <target>" \
    --summary "<the net implication for the target in one sentence>" \
    --primary read-through-<reporter>-to-<target>.md="Read-through"
  ```

## Quality bar

- Every link names its mechanism and lag; a link resting only on "same
  sector" is labelled weak.
- Quotes are verbatim with the speaker named; figures cite the release.
- Show the historical validation even when it weakens the story.
- Directional calls are relative to expectations; never give price targets.
- Keep the reporter's facts and your inferences in separate columns.

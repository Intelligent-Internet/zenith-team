# SEO keyword research

You are finding the searches the Company can realistically win and that
lead to business. The reader is a founder or marketer planning the next
quarter of content. Good output is a prioritised set of keyword clusters,
each mapped to one page (existing or new), with honest demand and
difficulty signals and a content idea, not a list of thousands of
keywords. Volumes without a source are guesses; say where every number
comes from.

## Inputs

- Topic, site, offering, seeds, competitor sites, market, goal, site
  strength and any keyword data, all in the brief.
- Data sources, in order of trust:
  1. Exports the person shared: Semrush, Ahrefs or Keyword Planner, and
     Search Console query exports with real impressions, clicks and
     positions for the site.
  2. Google Trends (relative interest and seasonality), autocomplete and
     related searches, and "people also ask" questions.
  3. Competitor pages: titles, headings and sitemaps reveal what they
     target.
  4. Community language: Reddit, forums, review sites and Q&A.
- Without a paid tool export, do not invent search volumes. Use relative
  demand bands (high, medium, low) with the evidence behind each.
- Look at live results pages only for priority keywords, at a human pace,
  or through a results API the Company already pays for. Never run bulk
  automated queries against a search engine.

## Procedure

1. **Understand the business.** Read the site (or the offering if there is
   none). List the products, use cases, audiences and problems solved.
   These become the seed themes alongside the brief's seeds.
2. **Find what the site already ranks for.** From a Search Console export
   in the brief, take queries with impressions in the last three months.
   Flag *near wins*: queries at average position 8 to 20 with meaningful
   impressions. These are usually the fastest gains. Without such an
   export, leave near wins empty and say so.
3. **Expand.** For each seed theme, gather variants: modifiers (best,
   vs, alternative, template, cost, how to, for <industry>), questions,
   synonyms and the words customers use in reviews and forums. Add the
   topics competitors rank or publish on that the Company does not cover.
4. **Classify intent** as informational, commercial investigation,
   transactional or navigational, and confirm it for priority keywords by
   what the results page actually shows (guides, product pages, listicles,
   tools, videos, local pack). The results page is the ground truth.
5. **Assess difficulty with signals.** For priority keywords note who
   ranks (big brands, niche sites, forums), the content type and depth,
   freshness, and results-page features such as AI summaries, snippets,
   shopping or local packs that take clicks. Forums and thin pages on page
   one mean an opening. Weigh everything against the site's strength: a
   new site should favour long-tail and question keywords.
6. **Cluster.** Group keywords that one page can satisfy. Prefer results
   overlap (keywords whose top results share three or more URLs belong
   together); where results data is not available, cluster by shared
   intent and meaning and say so. Name each cluster by its head keyword.
7. **Map and prioritise.** Map each cluster to an existing URL or mark it
   as a new page. Score priority = business value (0 to 3, how close the
   searcher is to buying what the Company sells) x demand (1 to 3) x
   winnability (1 to 3, given site strength). Near wins get a bonus.
8. **Turn clusters into content ideas.** For the top clusters: working
   title, format the results page rewards, angle that adds something new
   (data, a tool, first-hand experience), and internal links to and from
   existing pages. Sketch a simple publishing order.

## Deliverables

- **Primary:** `keyword-research.xlsx` with sheets:
  - *Keywords*: keyword, cluster, intent, demand (volume or band) and
    its source, difficulty signal, results-page features, current
    position and URL, business value, priority score.
  - *Clusters*: cluster, head keyword, keyword count, intent, target
    URL or "new page", format, priority, content idea.
  - *Near wins*: query, page, position, impressions, clicks, suggested
    change.
  - *Method*: sources, dates, market and assumptions.
  If openpyxl is missing, deliver the Keywords and Clusters sheets as CSV.
- **Final:** `keyword-research.md`: summary, top ten opportunities, near
  wins, the content plan in order, and caveats.
- Present them:

  ```sh
  zen output present --type file --title "SEO keyword research — <topic>" \
    --summary "<number of clusters and the biggest opportunity>" \
    --primary keyword-research.xlsx="Keyword plan" \
    --final keyword-research.md="Summary and content plan"
  ```

## Quality bar

- Every volume figure names its tool and date; bands are labelled as
  bands.
- One cluster, one page. Flag any cluster that two existing pages already
  compete for.
- Priority reflects business value first. Do not rank a big irrelevant
  keyword above a small one that sells.
- Keywords are written the way people search, in the market's language
  and spelling.
- No invented rankings: current positions come from a shared Search
  Console or tool export, or are left blank.

# Advisor prospecting

You are building a prospect list of businesses for a professional-services
practice — wealth or retirement-plan advisors, accountants, brokers,
fractional CFOs, lawyers, lenders. The reader is a partner or business
developer who wants fewer, better names: companies that fit, with a
concrete, dated reason to reach out now and a public source for every fact.
Good work is accurate, deduplicated against existing relationships, and
built only from public business information.

## Inputs

- The practice type, ideal client, geography, size range, buying signals,
  count, value proposition and exclusions — all in the brief. If the ideal
  client is too vague to search ("small businesses"), narrow it using the
  practice type and state the narrowed definition at the top.
- Connectors, when available, are read-only: the CRM (HubSpot or
  Salesforce) to exclude existing accounts and open opportunities, Apollo
  for business contact data, LinkedIn only through its Connector. Never
  create, update or enrich CRM records, and never send outreach.

## Procedure

1. **Define the ideal client profile.** Turn the brief into searchable
   criteria: industry codes (NAICS), size range, geography, ownership type
   (owner-managed, family, private-equity backed), and disqualifiers.
2. **Choose sources by signal.** Use public, professional sources only:
   - Company websites, press releases and local business journals.
   - State business registries (formation date, status, registered
     officers).
   - Industry association member directories and licensing board
     look-ups (for example dental, medical or contractor boards).
   - SEC EDGAR Form D filings for private raises, which name executive
     officers.
   - US Department of Labor Form 5500 filings (EFAST2) for retirement plan
     sponsors: plan type, participants, assets and service providers — a
     prime source for retirement-plan and wealth practices.
   - Public contract awards (for example SAM.gov and USAspending) and
     public permit or zoning records for expansion.
   - Job postings on company career pages for hiring and new roles (a new
     CFO or controller hire is a signal for accountants and fractional
     CFOs).
   - Published lists of fast-growing or award-winning companies.
3. **Build a long list** of roughly three times the requested count, then
   remove exclusions and existing CRM accounts, merge duplicates
   (trading names versus legal names) and drop anything outside the
   geography or size range.
4. **Profile each prospect.** Legal and trading name, website, city,
   industry, size estimate with its basis, ownership, founding year, the
   decision-maker's name and title from a public professional source, a
   public business contact route (company phone, general inbox or contact
   form), the trigger with its date and link, and one sentence of context.
5. **Score and tier.**
   - Fit 0–5: industry, size, geography and ownership match.
   - Trigger 0–5: recency (within 90 days scores highest) and relevance to
     the practice.
   - Access 0–3: a public contact route, shared networks or
     associations, a warm introduction path noted in the brief.
   Total out of 13: tier A at 10 or more, B at 7–9, C below 7. Deliver the
   requested count, A tier first.
6. **Write the angle.** For each A and B prospect, one or two sentences
   linking the trigger to the value proposition ("Opened a third clinic in
   March; owners at this stage often need entity and succession planning").
   These are notes for the advisor, not messages.
7. **Summarize the pattern.** Which sources and signals produced the best
   prospects, and how to repeat the search next quarter.

## Deliverables

- **Primary:** `prospects.xlsx` with sheets:
  1. `Prospects` — one row each: tier, total score, fit, trigger, access,
     company, website, city, industry, size estimate and basis, ownership,
     decision-maker and title, public contact route, trigger and date,
     angle, source links.
  2. `Method` — the ideal client profile, sources searched, scoring rubric.
  3. `Excluded` — names removed and why (existing client, out of range,
     duplicate).
- **Final:** `prospecting-summary.md`: the top ten prospects in a table,
  patterns found, suggested next steps.
- Present:

  ```sh
  zen output present --type file --title "Prospect list — <ideal client>, <geography>" \
    --summary "<count by tier and the strongest signal found>" \
    --primary prospects.xlsx="Prospect list" \
    --final prospecting-summary.md="Summary"
  ```

  Without openpyxl, deliver `prospects.csv` instead.

## Quality bar

- Business information only: no home addresses, personal phone numbers or
  emails, family details or estimates of an individual's personal wealth.
  Only people acting in a business role, taken from professional sources.
- Respect robots.txt and site terms; no scraping behind logins and no
  scraping of social networks outside an approved Connector.
- Every trigger has a date and a link; nothing older than 18 months counts
  as a trigger.
- Contact data is never guessed (no pattern-built email addresses).
- Outreach is out of scope. If the person later sends messages, marketing
  and electronic-communication rules (for example CAN-SPAM, and the SEC
  marketing rule or FINRA rules for advisors) apply.

# Sales call prep

You are preparing a seller for one call. The reader will skim this sheet ten
minutes before joining, so it must fit on one or two screens and answer four
questions: why are we meeting, who is in the room and what do they care
about, what must we learn or win, and what do we say when they push back.
Good prep sets one clear goal for the call and one specific next step to ask
for.

## Inputs

- Company, call type, date, length, attendees on both sides, what we sell,
  deal history, competitors and the desired outcome — all in the brief.
- Helpful Connectors, all read-only: the calendar (the invite, its agenda
  and attendee addresses), mail (the latest thread with the account), the
  CRM (stage, amount, close date, notes, contacts) and a call recorder
  (earlier calls with this account). Never send, accept or edit anything.
- Missing attendee names: prepare by role and make "confirm attendees" the
  first pre-call action. Blank desired outcome: set one from the call type
  (step 2) and say you did.

## Procedure

1. **Refresh the account.** One paragraph: what they do, their size, and
   one or two dated triggers from the last six months (funding, launches,
   leadership changes, results). Cite each. Spend no more than ten minutes.
2. **Set the call goal** as what the buyer will agree to by the end:
   - introduction → agree the problem is worth a discovery conversation;
   - discovery → confirm pain, its impact, the decision process and timing;
   - demo → validate the two or three use cases that matter and name a
     technical owner;
   - technical review → close open requirements with a written list;
   - proposal → confirm scope and price fit the budget and the path to
     signature;
   - negotiation → agree final terms and a signature date;
   - renewal → confirm value delivered, expansion scope and renewal date.
3. **Plan the agenda** against the call length, with minute marks: opener
   and agenda check (about 10%), their priorities (about 40% in early calls),
   our part (about 30%), and next steps with dates in the last five minutes —
   never cut.
4. **Profile each attendee.** Role, tenure, relevant public background, what
   they are likely measured on, their probable part in the decision
   (economic buyer, champion, evaluator, user, blocker, unknown), anything
   they said before (from notes), and one tailored opener or question.
   Business sources only.
5. **Find the qualification gaps.** Lay out what we know and do not know
   under MEDDICC headings — metrics, economic buyer, decision criteria,
   decision process, paper process, identified pain, champion, competition.
   Each gap becomes a question.
6. **Write discovery questions.** Eight to twelve open questions ordered by
   importance, grouped into situation, problem and impact (quantified in
   time, money or risk), and decision and timeline. Star the three must-ask
   questions. Drop any question the research already answers.
7. **Value points and proof.** Three talking points linking their priorities
   to our offer, each with a proof point — a customer result, benchmark or
   reference. Use only proof from the brief or public sources; if none
   exists, write "proof needed".
8. **Prepare for objections.** The five most likely for this stage and these
   attendees (price, timing, "we already use X", status quo, security,
   building it themselves, bandwidth). For each: what it usually means, a
   response that acknowledges, clarifies, answers and confirms, and the
   supporting proof. When competitors are named, add two questions that
   surface criteria where we are strong.
9. **Define the ask.** The specific next step with a date and owner, plus a
   fallback if the first ask is refused. From the proposal stage onward,
   add a short mutual action plan: steps, owners and dates to signature.

## Deliverables

- **Primary:** Markdown `call-prep-<company-slug>.md` titled
  "Call prep — <Company> — <date>" with these sections: Goal and the ask
  (three lines at the top); Agenda with minute marks; Account refresh;
  Attendees; Qualification gaps; Discovery questions; Talking points and
  proof; Objections; Pre-call checklist (confirm attendees, test the demo
  environment, materials to send). Keep it under about 1,000 words.
- Present it:

  ```sh
  zen output present --type text --title "Call prep — <Company>" \
    --summary "<the call goal and the next step to ask for>" \
    --primary call-prep-<company-slug>.md="Call prep"
  ```

## Quality bar

- The goal and the ask are specific and checkable; "build rapport" is not a
  goal.
- Every question is open-ended and specific to this account — no generic
  padding.
- Objection responses never disparage a competitor or promise what the
  offer does not support.
- Research facts carry links and dates; inferences are labeled.
- Read-only on every Connector; the person sends any follow-up themselves.

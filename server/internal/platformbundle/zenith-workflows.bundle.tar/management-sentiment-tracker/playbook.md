# Management sentiment tracker

You are measuring how a management team talks about its business over a run
of earnings calls, and explaining which changes matter. The reader is an
investor or analyst who already knows the numbers and wants the signal in
the language: growing hedges, a KPI that stopped being mentioned, a CFO who
started answering shorter. Good work combines a transparent, repeatable
score with a careful human read, and never overstates what tone can
predict. This is research support, not investment advice.

## Inputs

- The company, the number of calls, which sections to score, optional
  themes, peers and transcripts — all in the brief.
- Transcripts: use pasted text first, then the investor relations site
  (transcripts, prepared remarks, webcast captions) and filed exhibits
  (some companies file call scripts with the regulator). Do not buy access
  or bypass paywalls. If fewer than three calls can be obtained, stop and
  report which calls are missing instead of scoring a partial series.
- If a transcript is machine-generated or partial, flag it in the source
  list; its scores are lower confidence.
- A Google Drive Connector, when available, can open transcripts the
  person linked from their own drive.

## Procedure

1. **Assemble the corpus.** One clean text per call, split into prepared
   remarks and Q&A, and tagged by speaker role (CEO, CFO, other executive,
   analyst). Remove operator lines, safe-harbour boilerplate and
   introductions so they do not dilute the scores.
2. **Score with a fixed lexicon.** Use the Loughran–McDonald financial
   sentiment word lists (published by the University of Notre Dame's
   Software Repository for Accounting and Finance); if they cannot be
   downloaded, use a compact list you write down in the appendix and apply
   it identically to every call. Per section and speaker, compute per 1,000
   words: positive, negative, uncertainty, litigious, weak-modal ("may",
   "could", "might") and strong-modal words, plus
   net tone = (positive − negative) ÷ (positive + negative).
   Handle simple negation ("not strong", "no improvement") within three
   words before the term.
3. **Measure behaviour in Q&A.** Average answer length by executive,
   share of answers that deflect ("we don't guide to that", "too early to
   say", "we'll share more later"), questions answered by someone other
   than the person asked, and the tone of the analysts' questions — analyst
   negativity often leads management's.
4. **Track themes and vocabulary.** For each theme (from the brief, or the
   eight terms with the largest mention swings), count mentions per call
   and pull the representative sentence from each call. Diff the vocabulary:
   words and phrases that newly appear ("normalization", "prudent",
   "choppy") or disappear ("record", "accelerating", a named KPI).
5. **Read it like an analyst.** Lexicons miss sarcasm, context and
   industry terms ("liability" in insurance, "tax" in tax software). Review
   every call and override or annotate automated results where the reading
   clearly differs, logging each override.
6. **Baseline against peers** when peers are given: score each peer's
   most recent two calls the same way. A cautious tone shared by the whole
   sector is a macro signal; a company-specific shift is the interesting one.
7. **Relate to outcomes.** Line up tone shifts with what followed:
   guidance changes, the next quarter's results, and the one-day share price
   reaction if a price source is available. Describe association, not
   causation, and say how many observations support each claim.
8. **Call the signals.** Classify each notable shift as Signal (persistent,
   company-specific, backed by behaviour and content), Watch (new, one call
   only) or Noise (sector-wide, seasonal or a one-off speaker change).

## Deliverables

- **Primary:** `sentiment-report.md` with: headline finding in two
  sentences; tone chart; scorecard table (call × metric, prepared versus
  Q&A); theme tracker with quote pairs showing before and after; Q&A
  behaviour findings; Signal / Watch / Noise list; method and limitations.
- **Final:** `tone-chart.png` — net tone and uncertainty per call, drawn
  with matplotlib, with call dates on the x-axis and peers as grey lines.
- **Supporting:** `sentiment-scores.xlsx` (or `.csv`) with every metric per
  call, section and speaker, the lexicon version and the override log.
- Present:

  ```sh
  zen output present --type text --title "Management sentiment — <company>" \
    --summary "<the main shift in one sentence>" \
    --primary sentiment-report.md="Sentiment report" \
    --final tone-chart.png="Tone chart" \
    --supporting sentiment-scores.xlsx="Scores"
  ```

  If matplotlib is missing and cannot be installed, drop the chart line and
  show the tone series as a table in the report; if openpyxl is missing,
  pass `sentiment-scores.csv` instead.

## Quality bar

- Every claimed shift is backed by a quote from each side of the change,
  with call date and speaker.
- Scores are normalized per 1,000 words and computed identically for every
  call; the method section lets someone reproduce them.
- Never infer intent or honesty from tone; describe the language and what
  it has historically accompanied.
- Say plainly when the sample is too small to mean much.

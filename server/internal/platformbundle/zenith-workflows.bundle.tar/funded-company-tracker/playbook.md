# Funded company tracker

You are finding companies that just raised money and fit the profile. A new
round usually brings fresh budget, a hiring plan and pressure to hit
milestones, which makes it the best window for a relevant offer. The reader
is a founder or seller who will reach out this month. Good output is a
short, verified list: each round confirmed from a primary source, a credible
read on what the money is for, and an angle that ties our offer to that plan.

## Inputs

- Sector, geography, round types, time window, round size, maximum count,
  exclusions and our offer — all in the brief.
- Connectors, read-only: a CRM (HubSpot, Salesforce) to drop current
  customers, open deals and owned accounts; Apollo for firmographics and
  business contacts; Firecrawl to read news pages that block simple fetching.
- If the sector is broad, prioritize by fit with the offer and say so. If
  fewer companies qualify than requested, deliver the verified ones and
  explain the gap — never pad the list.

## Procedure

1. **Search announcements** made in the window, across source types:
   - company newsrooms and blogs, and wire services (Business Wire, PR
     Newswire, GlobeNewswire);
   - investor blog posts and portfolio pages;
   - reputable tech and trade press, regional startup news and weekly
     funding round-ups;
   - regulatory filings: SEC Form D on EDGAR for US private raises (amount
     sold, date of first sale, industry group), and share-allotment filings
     at Companies House for UK companies;
   - accelerator and demo-day cohorts, for pre-seed and seed.
2. **Verify each round.** Company, round type, amount and currency, date
   announced, lead investor and notable participants. Confirm with at least
   one primary source — the company, a lead investor or a filing — and mark
   rounds reported only by third parties as "unconfirmed". Convert currency
   only when useful, stating the rate and its date.
3. **Filter to the profile.** Sector fit, geography, round type, round size,
   exclusions and CRM status. Record why each borderline company was kept or
   dropped.
4. **Read the use of funds.** From the announcement ("to expand into…", "to
   grow the sales team"), open job postings counted by function (for example
   twelve sales roles, three data roles), new executive hires, new offices
   or markets, and launches. Write one sentence — "They are investing in X"
   — with its evidence.
5. **Judge timing.** Buying windows tend to open one to four months after a
   raise, as new leaders arrive and budgets are set. Note where each company
   sits and any sign the window is closing — the role we serve is already
   filled and a vendor has been announced.
6. **Match the angle.** Tie the use of funds to our offer in one or two
   sentences, and name the role most likely to own the purchase (a newly
   hired VP of Sales for a sales tool, for example). Find that person only
   from public professional sources or the Apollo Connector; when no current
   holder can be verified, leave it as a role.
7. **Score and rank.** Fit 0–50, timing 0–25, strength of the use-of-funds
   match 0–25, each explained in one line.

## Deliverables

- **Primary:** `funded-companies-<sector-slug>.xlsx` with sheets:
  - *Companies* — rank, company, website, headquarters, sector, round type,
    amount, date, lead investor, source link, confirmation status, use of
    funds, hiring signal, angle, role to contact, named contact and its
    source (when found), score and notes;
  - *Excluded* — companies considered and why they were left out;
  - *Method* — sources searched, window and scoring.
  If openpyxl is unavailable, deliver one CSV per sheet.
- **Final:** `funded-companies-summary.md` — the top ten with a two-line
  angle each, plus patterns across the list, such as the investors most
  active in the sector and the functions most often hiring.
- Present it:

  ```sh
  zen output present --type file --title "Funded companies — <sector>" \
    --summary "<N companies funded in the window; the three strongest angles>" \
    --primary funded-companies-<sector-slug>.xlsx="Funded companies" \
    --final funded-companies-summary.md="Top companies and angles"
  ```

## Quality bar

- Every round has a date, an amount (or "undisclosed") and a working source
  link; rumored rounds are excluded or clearly labeled.
- Use-of-funds statements rest on the announcement or observable hiring,
  never on the round size alone.
- Business contacts only, from public professional sources or a connected
  provider; never guess email addresses.
- Nothing is contacted, imported or logged anywhere.

# Company deep dive

You are writing the research report an analyst wants before forming or
defending a view on one company. The reader is an investor or strategist
who will read closely and check your sources. Good work explains how the
business really makes money, tests the moat and management against
evidence, builds the financial history from filings, and ends with the
risks and open questions rather than a summary of the company's marketing.
This is research and decision support, not investment advice.

## Inputs

- Company, angle, depth, focus areas and workbook choice, plus — when
  given — the team's questions, hypothesis and materials.
- The angle sets emphasis. A long looks for durable advantage and what is
  mispriced; a short looks for deterioration, accounting stretch and
  catalysts; an acquisition looks for fit, synergies and integration risk;
  a competitor study looks for strategy and weak points.
- For a private company, work from registry filings, press, funding news
  and product evidence. Label every estimate and shorten sections the data
  cannot support rather than filling them.
- Test the team's hypothesis honestly and give the evidence against it
  equal space.

## Procedure

1. **Read the primary record.** Five years of annual reports (business
   section, risk factors, MD&A, segment and revenue disaggregation notes,
   stock compensation, related parties), the last four to eight earnings
   calls, the latest investor day, the proxy (incentive metrics, insider
   ownership) and the main competitors' filings.
2. **Business model.** Segments, products, customers, channels, pricing,
   revenue mix (recurring, transactional, one-off), seasonality and
   cyclicality. Trace the money: who pays, for what and how often.
3. **Unit economics.** Define the unit (customer, store, subscriber,
   device, transaction). Revenue per unit, contribution margin per unit,
   acquisition cost, payback and lifetime, with cohort or retention
   evidence where disclosed. Note which metrics the company reports and
   which it has stopped reporting.
4. **Market.** Size and growth from at least two sourced methods, share
   trend, how customers buy, and the structural shifts that matter.
5. **Competition and moat.** Name the moat claimed (switching costs,
   network effects, scale, intangibles, cost position) and test it: gross
   margin stability, five-year share trend, price increases without volume
   loss, and ROIC against a stated cost of capital through a cycle. Profile
   the three to five most relevant competitors.
6. **Management and governance.** Tenure and track record; capital
   allocation history (acquisitions and how they turned out, buybacks and
   the prices paid, dividends, dilution from stock compensation);
   incentive metrics; insider ownership and transactions; board
   independence, share classes and auditor.
7. **Accounting quality.** Revenue recognition choices, capitalized costs,
   growth in non-GAAP adjustments, stock compensation as a share of
   revenue, receivable and inventory day trends, operating cash flow
   against net income, restatements and auditor changes.
8. **Financial history.** Revenue, growth, gross and operating margin, free
   cash flow, ROIC, net debt to EBITDA and diluted share count for five to
   ten years, from filings, fiscal years labelled.
9. **Valuation context.** Current multiples against the company's own
   history and peers, and a reverse DCF: the growth and margin the current
   price implies at a stated discount rate. For the three-statement
   workbook, project five years from an Inputs sheet with base, upside and
   downside cases.
10. **Risks and open questions.** Rank risks by probability and impact,
    each with a signpost to monitor. Close with bull, base and bear
    narratives, direct answers to the team's questions, and what remains
    unknown.

## Deliverables

- **Primary:** `deep-dive-<company>.docx` (Markdown if python-docx is
  unavailable): 1. Summary and key conclusions; 2. Business model; 3. Unit
  economics; 4. Market; 5. Competition and moat; 6. Management and
  governance; 7. Accounting quality; 8. Financial history; 9. Valuation
  context; 10. Risks, scenarios and open questions; 11. Sources. Add PNG
  charts (matplotlib) for revenue and margin history, segment mix and
  valuation against history. Standard depth runs about 12 pages; the focus
  areas get the extra space in the exhaustive version.
- **Final, unless the workbook is "No workbook":** `deep-dive-<company>.xlsx`
  with Inputs, Historicals (as reported), KPIs, Unit economics, Peers,
  Valuation, Checks and Sources; the three-statement option adds projected
  income statement, balance sheet and cash flow with live formulas and a
  balance check.
- Present:

  ```sh
  zen output present --type file --title "Deep dive — <company>" \
    --summary "<the core conclusion in one sentence>" \
    --primary deep-dive-<company>.docx="Deep dive report" \
    --final deep-dive-<company>.xlsx="Financial workbook"
  ```

  Use `--type text` and the `.md` path when the report is Markdown. If
  openpyxl is missing, deliver the workbook sheets as CSV files and list
  them as `--supporting` items.

## Quality bar

- Every non-obvious claim links to a filing page, transcript or source;
  data carries its as-of date.
- Historical figures tie to the filings; restated years are flagged.
- The workbook has no hard-coded outputs and its Checks sheet passes.
- Keep what the company says, what the numbers show and what you infer
  visibly separate.
- Words such as "dominant" or "best-in-class" appear only beside a number
  that earns them.

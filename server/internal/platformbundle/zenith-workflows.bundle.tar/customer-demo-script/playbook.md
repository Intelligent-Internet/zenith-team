# Demo script

You are writing the script for one customer demo. The reader is the seller
or solutions engineer who will drive it. A strong demo is a story about the
customer's own problem: it opens with the result they want, shows only the
few workflows that prove it, lets every person in the room see their part,
and ends with an agreed next step. Feature tours lose deals; this script
exists to prevent one.

## Inputs

- Company, attendees, discovery notes, demo type, time available, the
  capabilities we can show, product docs, proof points and a competitor —
  all in the brief.
- Connectors, read-only, when available: the CRM and a call recorder hold
  discovery notes and transcripts. The customer's exact words from those
  calls are the best raw material for the talk track.
- Show only what is listed under "What we can show" or confirmed in the
  product docs. If discovery is thin, build the script around the two most
  likely use cases for the customer's industry and open the demo by
  confirming them; say so at the top of the script.

## Procedure

1. **Choose the story.** Pull the customer's top three pains from discovery,
   in their words, with the impact in time, money or risk. Choose at most
   two use cases for 20 minutes, three for 30–45 and four for 60. Order them
   by impact, unless an evaluator needs a foundation scene first.
2. **Open with the ending.** Write a 60–90 second opener: a recap of what we
   heard ("You told us…"), a check on whether priorities changed, the
   agenda, and a first look at the end state — the screen, report or result
   they will have. Invite corrections before the first click.
3. **Write each scene** in the same four beats:
   - **Set up** — the pain in their words and who in the room owns it;
   - **Show** — the click path step by step: starting screen, actions and
     the record or data to use;
   - **Tell** — the value in one sentence, quantified where possible, with
     one proof point (customer result, metric, certification);
   - **Check** — a question that confirms relevance, such as "How does that
     compare with how your team handles it today?"
   Keep scenes under eight minutes and talk-track lines short enough to say
   while clicking.
4. **Tailor the data.** Specify sample data that looks like theirs: their
   company name and logo placement, their terms (patients, shipments, jobs,
   SKUs), realistic volumes and one record per persona. List it so it can be
   loaded before the call.
5. **Time the run of show.** Opener about 10%, scenes 60–65%, questions
   about 15%, close about 10%. Put minute marks on every section and mark
   which scene to cut if time runs short.
6. **Work the room.** For each attendee: what they must see and the
   question to ask them. Executives get outcomes and the business case,
   evaluators get workflows, integrations and security, users get their own
   day-to-day screens. Keep a parking lot for detailed questions and say
   when it will be answered.
7. **Position against the competitor.** When one is named, place our
   clearest differentiators naturally inside the scenes and add two or three
   questions that bring the evaluation criteria toward our strengths —
   without naming or criticizing the competitor.
8. **Close.** Recap the value of each scene in one line, ask which scene
   mattered most, then ask for a specific, dated next step (technical deep
   dive, pilot, proposal review or reference call) with a fallback ask.
9. **Plan for failure.** Backup screenshots or a short recording per scene,
   a second browser session already signed in, and a line to use if
   something breaks.

## Deliverables

- **Primary:** `demo-script-<company-slug>.docx` titled
  "Demo script — <Company>" with:
  1. Summary — goal of the demo, audience, the next step to ask for.
  2. Run of show — a table of minute mark, section, goal and presenter.
  3. Opener — the full script.
  4. Scenes — set up, show, tell and check for each scene.
  5. Sample data to load.
  6. Questions for each attendee.
  7. Objections likely during a demo, with responses.
  8. Close and next step.
  9. Prep checklist and backup plan.
  Deliver the same structure as Markdown when python-docx is unavailable,
  and present it with `--type text`.
- Present it:

  ```sh
  zen output present --type file --title "Demo script — <Company>" \
    --summary "<the story in one sentence and the next step to ask for>" \
    --primary demo-script-<company-slug>.docx="Demo script"
  ```

## Quality bar

- Every scene answers a pain from discovery; every pain has a scene or is
  explicitly marked out of scope.
- Only demonstrable capabilities. Roadmap items are named as roadmap and
  never shown as live.
- Proof points come from the brief or public sources and are cited; none are
  invented.
- The script fits the time available, has a cut plan, and closes on a dated
  next step.

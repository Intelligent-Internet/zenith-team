# Lead magnet article

You are writing a long-form guide a company will offer in exchange for an
email address. It only works if a qualified reader, having read it, feels
they got more than they gave — so the guide must solve a real problem more
completely and concretely than the free articles already out there, and
lead naturally to what the company sells without turning into a brochure.

## Inputs

- Topic, ideal reader, what the company sells, format, length and voice come
  from the brief. The company's own insights, sources and brand details are
  optional.
- The company's first-hand material (data, stories, checklists) is the most
  valuable input. Use it exactly as given and never embellish a number or a
  story. Without it, originality must come from structure, synthesis and
  worked examples; say so in the notes.
- Google Drive or Notion, when available, may hold research, past content
  or a style guide; read them. HubSpot, when available, can show which
  existing offers convert (read-only).

## Procedure

1. **Define the promise.** One sentence: after reading, this reader can do
   X. Choose a title that states the outcome, the audience and the method
   ("The multi-site payroll playbook: nine checks that stop overtime
   errors"). Make sure the promise is narrow enough to deliver fully at the
   chosen length.
2. **Study what exists.** Read the top free resources on the topic. Note
   what they cover, what they miss and where they are vague or dated. The
   guide must beat them on at least two of: depth, specificity, recency,
   original data, usable tools.
3. **Gather evidence.** Prefer primary sources: regulators, official
   statistics, peer-reviewed or methodologically transparent studies,
   company filings. Record each source with its date. Drop any statistic you
   cannot trace to its origin.
4. **Outline.** An introduction (the cost of the problem, the promise, who
   it is for), five to nine core sections, a tool section and a conclusion.
   Each core section gives the principle, how to apply it step by step, a
   worked example with realistic numbers (labelled illustrative when you
   made them up) and the common mistake with how to spot it. Shape it to
   the format:
   - *Step-by-step playbook* — ordered steps with time estimates and owners.
   - *Comprehensive guide* — concepts first, then decisions and trade-offs.
   - *Guide with checklist and templates* — each section ends in checklist
     items; templates appear in full.
   - *Benchmark or data report* — method first, findings with charts, then
     what to do about them; illustrative numbers are never shown as data.
5. **Write.** Short paragraphs, descriptive subheads, second person, a
   three-line summary box at the top of each section. Mention the product
   only where it genuinely removes a step the reader would otherwise do by
   hand — once or twice in the body — plus an honest call to action at the
   end.
6. **Build the tool.** A checklist, worksheet, calculator table or template
   the reader can use the same day, inside the guide and again as a
   one-page appendix.
7. **Produce the files.** Build the PDF from HTML with a headless browser
   (Playwright's `page.pdf`) or WeasyPrint: cover page, contents, page
   numbers, brand colors, 11–12 pt body text, callout boxes, and charts
   drawn with matplotlib when there is data. Build an editable DOCX with
   python-docx (Markdown when the library is missing).
8. **Write the capture kit.**
   - Landing page: headline, subheadline, three to five bullets on what the
     reader gets, who it is for, a credibility line about the author or
     company (leave a placeholder for testimonials; never invent one), and
     form advice — ask only for what sales will use (work email, role,
     company size), with a consent line and a privacy-policy link.
   - Three follow-up emails: delivery (immediately), a practical tip from
     the guide (day 2–3) and a soft offer tied to the guide's hardest step
     (day 5–7). Each has a subject, preview text, body and one call to
     action.

## Deliverables

- **Primary:** `lead-magnet.pdf` — the designed guide.
- **Final:** `lead-magnet.docx` (the editable guide) and `capture-kit.md`
  (landing page copy, form advice and the three emails).
- **Supporting:** `sources.md` — every source with title, publisher, date
  and link, plus notes on assumptions and illustrative figures.
- If no PDF engine can run, deliver `lead-magnet.html` with the DOCX and say
  so.
- Present them:

  ```sh
  zen output present --type file --title "<guide title>" \
    --summary "<the promise, the length and the tool inside>" \
    --primary lead-magnet.pdf="Guide (PDF)" \
    --final lead-magnet.docx="Guide (editable)" \
    --final capture-kit.md="Landing page and follow-up emails" \
    --supporting sources.md=Sources
  ```

## Quality bar

- Word count within 15% of the chosen length with no padding: every section
  holds a step, example or decision the reader can use.
- Every statistic is cited to a primary or clearly named source with a date;
  illustrative numbers are labelled.
- The guide is useful to someone who never buys; the product appears as a
  genuine option, never as a bait-and-switch.
- No invented testimonials, customer names, awards or survey results.
- Draft only: never publish the landing page, load emails into a marketing
  tool or send anything.

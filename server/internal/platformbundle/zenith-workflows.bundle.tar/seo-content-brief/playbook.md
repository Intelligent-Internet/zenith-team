# SEO content brief

You are writing the brief for one article that should rank for one query
and move its reader toward the Company. The reader of the brief is a
writer, in-house or freelance, who knows how to write but not this
market. Good output tells them exactly what the searcher wants, what the
current top pages already do, what this article must add that they lack,
and how to structure it, with sources to cite and links to place. It is a
brief, not a draft: do not write the article.

## Inputs

- The target query, site, market, reader, goal, format, the Company's
  angle, pages to beat and style rules, all in the brief.
- Google Drive, when available, may hold a style guide the person points
  to. Read-only.
- Look at the live results page for the query, and a few close variants,
  at a human pace. Never run bulk automated searches.

## Procedure

1. **Check for an existing page.** Search the site (a `site:` query or
   the sitemap) for pages on the same query. If one exists and ranks,
   recommend updating it instead and brief the update;
   two pages on one query compete with each other.
2. **Read the results page.** For the market, record the top organic
   results, the page types they are (guide, tool, list, product page,
   video, forum thread) and the results-page features (AI summary,
   featured snippet, "people also ask", video, images). The dominant page
   type defines the format when the brief says to let results decide. If
   intent is mixed, say which slice this article will serve.
3. **Dissect the top five to eight pages.** For each: title, H2 and H3
   outline, approximate word count, publication or update date, unique
   assets (calculators, templates, original data, diagrams) and obvious
   weaknesses (outdated, thin, no examples, no author). Collect the
   questions they all answer: these are table stakes.
4. **Find the information gain.** List what none or few of them provide
   that the Company can: its data, a worked example, a template, expert
   quotes, a clearer method, a current-year update. This becomes the
   article's reason to exist; build it around the angle from the brief.
5. **Gather questions and entities.** From "people also ask", related
   searches and forums, list the questions the reader has. From the top
   pages, list the concepts, formulas, standards, tools and named things
   that recur (entities). Say which section should cover each.
6. **Outline.** Proposed H1; an introduction that answers the query in
   the first 100 words; a snippet target (a 40 to 60 word definition, a
   numbered list or a table, matching what currently holds the snippet);
   then H2 and H3 headings, each with its purpose, key points, entities,
   evidence to cite and a word range. Add an FAQ block only for real
   remaining questions. Word count guidance: the median of comparable top
   results, plus or minus 20 percent; depth matters more than length.
7. **Specify on-page elements.** Title tag (about 60 characters, query
   near the front), meta description (about 150 characters, a reason to
   click), URL slug, image and diagram ideas with alt text, and schema
   (Article or BlogPosting; others only where the page genuinely fits).
8. **Plan internal links.** From the site's sitemap or a light crawl, pick
   three to eight existing pages this article should link to, with anchor
   text, and two or three existing pages that should link to it.
9. **List sources.** Five to ten authoritative sources (government,
   standards bodies, academic work, primary research, official docs), each
   with what it supports. Note who should be credited as author or
   reviewer to show real expertise.
10. **Place the call to action** for the stated goal: where in the flow
    and what it offers, without interrupting the answer.

## Deliverables

- **Primary:** `seo-content-brief.docx` (python-docx), or
  `seo-content-brief.md` if the library is missing, titled "Content brief
  — <query>", with: At a glance (query, secondary queries, intent, format,
  word range, reader, goal), Results-page analysis table, Information
  gain, Outline, Questions and entities, On-page specs, Internal links,
  Sources, Voice and style notes, and a writer's checklist.
- Present it:

  ```sh
  zen output present --type file --title "Content brief — <query>" \
    --summary "<intent, format and the article's unique angle in one sentence>" \
    --primary seo-content-brief.docx="Content brief"
  ```

  Use `--type text` and the `.md` path when you delivered Markdown.

## Quality bar

- Every observation about competing pages links to the page and is dated.
- The outline answers the query early and covers every table-stakes
  question, then adds at least one thing the top results lack.
- Treat entities as topics to cover, never as keyword-density targets.
- Sources are primary or authoritative; no linking to direct competitors
  as evidence.
- Respect the style rules exactly, and flag any that conflict with what
  the results reward.

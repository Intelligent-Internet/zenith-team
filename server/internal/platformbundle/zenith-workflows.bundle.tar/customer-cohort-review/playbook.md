# Customer cohort review

You are analyzing a company's customer revenue by cohort to show how well it
keeps and grows customers. The reader is a founder, finance lead, investor
or product owner who needs retention numbers they can defend in a board
meeting or diligence call. Good work states every definition, reconciles
cohort totals back to total revenue, handles messy billing data explicitly
and explains the story behind the curves, not just the curves.

## Inputs

- The data, business model, cohort grain, currency, segment columns and
  questions — all in the brief. Data may be pasted CSV, a link, or, when
  available, a Stripe or Google Drive Connector (read-only).
- If the data cannot be parsed, has no customer identifier, or covers
  fewer than three periods, stop and report exactly what is missing.
- Treat the data as confidential: process it locally, never upload it to
  public tools, and show customer IDs rather than names in outputs.

## Procedure

1. **Profile and clean.** Detect columns, parse dates and amounts, and
   report row counts, date range, customers, total revenue and anomalies:
   duplicates, negative amounts (refunds and credits — net them into the
   period they relate to when identifiable), zero rows, currency mixes
   and customer IDs that look like the same account. Separate one-time
   revenue (setup, services) from recurring revenue for subscription and
   usage models when a column allows it.
2. **Build the revenue series.** Aggregate to customer × period. For
   subscription data billed annually or quarterly, spread each invoice
   evenly over its service period to get monthly recurring revenue, and
   say so; if service periods are unknown, analyze on billed revenue and
   flag the distortion.
3. **Define terms and apply them consistently.**
   - Cohort: the period of a customer's first positive revenue.
   - Active: revenue above zero in the period.
   - Logo retention (period n) = active customers from the cohort ÷
     cohort size.
   - Revenue retention (period n) = cohort revenue in period n ÷ cohort
     revenue in period 0.
   - Net revenue retention (trailing 12 months) = revenue this period
     from customers active 12 months ago ÷ their revenue 12 months ago.
   - Gross revenue retention = the same, with each customer's revenue
     capped at its starting level (so expansion is excluded).
   - Returning customers after a gap count as reactivations, not new.
4. **Build the triangles.** Cohort × period-since-start tables for
   customers, revenue, logo retention % and revenue retention %. Exclude
   the current incomplete period, and mark cells for cohorts with fewer
   than 20 customers as low-confidence.
5. **Build the revenue bridge** per period: opening revenue + new +
   expansion − contraction − churn + reactivation = closing revenue. It
   must tie to total revenue per period to the cent; show the check.
6. **Transactional businesses.** For e-commerce, marketplaces and
   services without subscriptions, add repeat purchase rate, orders per
   customer, days between orders and cumulative revenue per customer by
   cohort (a lifetime-value curve) — these matter more than monthly
   recurring revenue.
7. **Concentration.** Share of revenue from the top 1, 10 and 20
   customers, customers over 10% of revenue, and the Herfindahl index;
   repeat for the latest 12 months.
8. **Segments and questions.** Repeat the headline metrics for each
   segment column; test each question in the brief with a before-and-after
   or segment comparison and say how confident the data lets you be.
9. **Interpret.** Where the curves flatten, whether newer cohorts retain
   better or worse than older ones, what drives net retention (expansion
   versus churn), and which customers or segments dominate. Compare with
   commonly cited ranges only as rough context and say they vary widely by
   segment.

## Deliverables

- **Primary:** `cohort-review.xlsx` with sheets `Summary` (headline
  metrics as formulas), `Data` (cleaned), `Customers by cohort`, `Revenue
  by cohort`, `Logo retention`, `Revenue retention` (conditional-format
  heatmaps), `Bridge`, `Concentration`, `Segments`, `Definitions`,
  `Checks` (reconciliations, all showing zero difference).
- **Final:** `cohort-review.md`: findings in five bullets, charts
  (`retention-heatmap.png`, `retention-curves.png`, `revenue-bridge.png`
  made with matplotlib), answers to the questions, data issues and
  assumptions.
- Present:

  ```sh
  zen output present --type file --title "Customer cohort review" \
    --summary "<net and gross revenue retention and the main trend>" \
    --primary cohort-review.xlsx="Cohort workbook" \
    --final cohort-review.md="Findings" \
    --supporting retention-heatmap.png="Retention heatmap" \
    --supporting retention-curves.png="Retention curves" \
    --supporting revenue-bridge.png="Revenue bridge"
  ```

  Without openpyxl, deliver the tables as CSV files and make the findings
  primary with `--type text`.

## Quality bar

- Cohort revenue summed across cohorts equals total revenue for every
  period; the bridge ties; checks are visible in the workbook.
- Every metric has a written definition; gross retention never exceeds
  100%.
- Small or incomplete cohorts are marked, never presented as trends.
- Findings distinguish what the data shows from what it suggests.

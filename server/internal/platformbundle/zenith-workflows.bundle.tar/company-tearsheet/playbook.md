# Company tearsheet

You are producing a one-page profile that lets a reader understand a company
in three minutes: what it does, how big and healthy it is, who owns and
runs it, what just happened and who it competes with. The discipline is
compression without loss of accuracy: every number sourced and dated,
nothing padded, and the page genuinely fits on one page. This is research,
not investment advice.

## Inputs

- Company name (with ticker or website when given), purpose, display
  currency, format and any extra topics.
- If the name is ambiguous and no website is given, profile the most
  prominent match, state exactly which entity you covered (legal name,
  country and an identifier such as ticker, CIK or registry number) and
  name the alternatives.
- The purpose sets emphasis. Screening favours financials and valuation;
  meeting prep favours news, management and talking points; a competitor
  check favours products, customers and positioning; a credit check favours
  leverage, liquidity, debt maturities and ratings.

## Procedure

1. **Identify the entity.** Legal name, listed or private, exchange and
   ticker, HQ, founding year, employees, fiscal year end and sector.
2. **Use primary sources first.**
   - Listed: the latest annual and quarterly filings (EDGAR 10-K and 10-Q,
     or the home regulator or exchange), the latest earnings release, the
     proxy or remuneration report, and the IR site.
   - Private: the company site, press releases, funding announcements,
     registry filings (Companies House accounts, state filings, SEC Form D
     for US raises) and reputable press. Label every estimate with its
     source.
3. **Business.** At most four sentences: what it sells, to whom, how it
   charges and where it wins. Add the segment or geographic revenue split
   in percent from the latest annual report.
4. **Key numbers.** Listed: share price and date, market cap, net debt or
   net cash, enterprise value (market cap + debt + preferred + minority
   interest − cash), revenue for the last two fiscal years and LTM, growth,
   gross margin, EBITDA or operating margin, free cash flow, EV/revenue,
   EV/EBITDA and P/E. LTM = last fiscal year + current year-to-date − prior
   year-to-date. Private: disclosed or estimated revenue, total funding,
   last round (date, amount, valuation if public, lead) and headcount
   trend. Convert currency at a stated rate and date when asked.
5. **Ownership and management.** Listed: largest holders from the latest
   filings, insider ownership and any dual-class structure. Private:
   founders, lead investors or the sponsor. CEO and CFO with start dates.
6. **Recent news.** Five dated items from the last 12 months that matter
   (results, guidance, M&A, leadership, litigation, product), one line
   each with a link. No press-release filler.
7. **Competitors.** The four to six closest, one line each on how they
   differ, plus one comparable metric (revenue or valuation) where public.
8. **Watch items.** Two or three upcoming catalysts or risks with dates.
9. **Lay out the page.** A header band with name, ticker or "Private",
   sector, HQ and as-of date; two columns below (business, ownership and
   management on the left; key numbers and competitors on the right); news
   and watch items across the bottom; sources as numbered footnotes. Build
   it as HTML/CSS and render to PDF with a headless browser (Playwright, or
   Chromium's `--print-to-pdf`) or WeasyPrint. Confirm the PDF has exactly
   one page and no text smaller than 8 pt.

## Deliverables

- **Primary:** `tearsheet-<company>.pdf` for the PDF format;
  `tearsheet-<company>.docx` or `tearsheet-<company>.md` otherwise, with
  the same sections in the same order.
- **Supporting:** `sources.md`, each numbered source with URL and access
  date.
- Present:

  ```sh
  zen output present --type file --title "Tearsheet — <company>" \
    --summary "<what the company is and its single most important number>" \
    --primary tearsheet-<company>.pdf="Tearsheet" \
    --supporting sources.md=Sources
  ```

  Use `--type text` with the `.md` path for the Markdown format. If no PDF
  renderer can be installed, deliver the DOCX (or Markdown) version and say
  why.

## Quality bar

- Every number has a footnoted source and an as-of date; market data shows
  the quote date.
- Units and currency on every figure; fiscal years labelled (FY2025, not
  "last year").
- Nothing is guessed: an unknown is written "not disclosed".
- It is one page. Cut words before shrinking the type.

# Investment committee memo

You are drafting the memo an investment committee reads before it votes on
a private company investment. The readers are partners who have not lived
in the deal: they need the recommendation and its logic on page one, the
evidence behind it, the downside stated honestly and the terms in plain
words. A good memo lets a skeptical partner find the weakest assumption in
five minutes. This is a draft for the deal team, not investment advice; the
committee decides.

## Inputs

- Company, deal type and deal materials, plus — when given — terms, our
  check, fund strategy and targets, the deal team's lean, length and date.
- If the materials cannot be opened or hold no financials, stop and report
  what is missing. Never present a memo built on public information alone
  as if it reflected diligence.
- Tag every figure **management** (as presented by the company),
  **verified** (tied to statements, contracts or third-party data) or
  **estimate** (yours, with the method). Committees weigh these differently.
- Drive or Notion Connectors often hold the data room and call notes. Use
  them read-only.

## Procedure

1. **Fact base.** Company overview, product, customers, business model,
   team, cap table, use of proceeds and the transaction mechanics.
2. **Market.** Size it bottom-up (number of target customers × realistic
   annual spend) and cross-check any top-down figure. State why now. Map
   four to eight competitors, including incumbents and the status quo.
3. **Financial performance.** Three years of history plus the plan.
   - Venture and growth: ARR or revenue, growth, gross margin, net and gross
     revenue retention, CAC payback, burn multiple (net burn ÷ net new ARR),
     runway, cohorts and customer concentration.
   - Buyout and minority PE: revenue, gross margin, EBITDA and an adjusted
     EBITDA bridge with each add-back marked supportable or not, cash
     conversion ((EBITDA − capex) ÷ EBITDA), working capital, capex split
     into maintenance and growth, and customer concentration.
   Compare the plan with history and say how much of it is contracted or in
   a qualified pipeline.
4. **Valuation and returns.** Build `returns-model.xlsx` with an Inputs
   sheet, one sheet per case and live formulas.
   - Venture: entry post-money and ownership, future rounds with a stated
     dilution each (15–25% is a common planning range), exit value per case
     from a multiple of exit-year revenue, proceeds through the preference
     stack, MOIC and IRR. Add the exit value this check needs to return the
     fund's target multiple and compare it with realistic category outcomes.
   - Buyout: entry EV/EBITDA, sources and uses, leverage and debt schedule,
     exit multiple and year, equity value, MOIC and IRR, and returns
     attribution split into EBITDA growth, multiple change and deleveraging.
   Run base, upside and downside cases and a sensitivity grid (exit multiple
   × exit year, or growth × margin). Anchor multiples to cited public comps
   and precedent transactions.
5. **Thesis.** Three to five reasons to invest, each specific and testable
   ("net retention stays above 120% as the product expands into finance
   teams"), with the evidence for each.
6. **Risks.** Market, execution, team, financial, technology, regulatory and
   structure risks, each with likelihood, impact, mitigant and diligence
   status. Add a pre-mortem: the most plausible story of how this
   investment loses money.
7. **Terms.** Price, security, liquidation preference and participation,
   anti-dilution, board, protective provisions, pro rata, information
   rights, option pool (and its effect on the effective pre-money), drag
   and tag. For buyouts: structure, leverage, rollover, earn-outs,
   management incentive plan and warranty insurance. Flag anything off
   market and why it matters.
8. **Diligence status.** Completed, open, and conditions to closing.
9. **Recommendation.** State the draft recommendation the evidence
   supports. If it differs from the deal team's lean, say so in one
   sentence with the reason; never bend the analysis toward the lean. Check
   fund fit: concentration limits and returns against targets.

## Deliverables

- **Primary:** `ic-memo-<company>.docx` (Markdown if python-docx is
  unavailable): 1. Recommendation and key reasons; 2. Deal summary and
  terms; 3. Company and product; 4. Market and competition; 5. Financial
  performance; 6. Valuation and returns; 7. Thesis; 8. Risks, mitigants and
  pre-mortem; 9. Diligence status; 10. Appendix of sources and data tags. A
  short memo keeps 1, 2, 6, 7 and 8 in full and compresses the rest.
- **Final:** `returns-model.xlsx` with Inputs, Base, Upside, Downside,
  Sensitivity, Comps, Sources and Checks sheets.
- Present:

  ```sh
  zen output present --type file --title "IC memo — <company>" \
    --summary "<recommendation, base-case MOIC and the key risk in one sentence>" \
    --primary ic-memo-<company>.docx="IC memo" \
    --final returns-model.xlsx="Returns model"
  ```

  If openpyxl is missing, deliver the model as CSV files with a Markdown
  note explaining every formula.

## Quality bar

- Page one stands alone: recommendation, check, valuation, base-case
  returns, top three reasons and top three risks.
- Every figure carries its tag and source; nothing is rounded into a
  better story.
- The Checks sheet confirms sources equal uses and every case recomputes
  from Inputs; no hard-coded outputs.
- The downside is a real downside (slower growth and a lower multiple), not
  the base case minus 10%.
- Keep deal information confidential: never search the web with the
  project's code name or confidential figures.

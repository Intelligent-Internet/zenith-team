# Search ads keyword plan

You are designing the keyword side of a paid search account before any
money is spent. The reader is a founder or marketer who will build or
review the campaigns, often without a specialist. Good output is a lean
structure the budget can actually feed: high-intent keywords first, match
types chosen on purpose, negatives in place from day one, and budget maths
anyone can check. A plan that spreads a small budget over fifty ad groups
fails, however good the keywords are.

## Inputs

- Business, landing page, offer, geography, exclusions, platform, goal,
  budget, economics and the competitor-name choice, all in the brief.
- If no budget is given, recommend one from the maths in step 7. If no
  economics are given, state the cost-per-result ceiling you assumed and
  why.
- This workflow uses no Connectors. Work from the landing page, public
  search results and competitors' visible ads. When the brief quotes
  Keyword Planner volumes, search terms or conversion rates, use them as
  measured figures. Never create, edit or enable anything in an ad
  account.

## Procedure

1. **Read the offer and the page.** List the products or services, the
   buyer's words for them, prices, proof and the call to action. Note
   landing-page gaps that will hurt quality or conversion (no price, no
   clear action, slow mobile load) as risks.
2. **Build the keyword list by intent tier.**
   - *Tier 1, ready to buy*: service or product plus buying words (near
     me, cost, book, buy, quote, pricing, best, for <use case>).
   - *Tier 2, comparing*: alternatives, versus, reviews, top options.
   - *Tier 3, researching*: problems and questions. Usually excluded at
     launch unless the budget is generous or the goal is signups.
   - *Brand*: the Company's own name, in its own campaign.
   Unless the brief supplies them, mark volumes and bid ranges as not
   measured and recommend a Keyword Planner check before launch.
3. **Group into ad groups.** Each ad group holds one tight theme, 5 to 20
   keywords, that one ad and one landing page can answer. Split by
   service, then by intent where the message differs. Name them
   consistently: `<campaign> | <theme>`.
4. **Choose match types.** Default to exact and phrase match at launch.
   Recommend broad match only paired with automated bidding once
   conversion tracking is reliable and the account records roughly 30 or
   more conversions a month, and say so. Keep brand terms exact.
5. **Write negatives.** Create a shared list for the account (for most
   businesses: jobs, careers, salary, free, DIY, course, training,
   definition, template, used, wholesale, unless one of these is the
   offer) plus the brief's exclusions. Add ad-group negatives so each
   query routes to the right ad group. Add competitor names as negatives
   when the brief says to leave them out.
6. **Draft ad copy angles** per ad group: eight to twelve headlines of at
   most 30 characters and three or four descriptions of at most 90, using
   the keyword theme, the offer, proof and a clear action. Include the
   character count next to each line.
7. **Do the budget maths.** Daily budget = monthly budget / 30.4.
   Clicks = budget / average CPC. Results = clicks x conversion rate.
   Cost per result = CPC / conversion rate. Highest affordable CPC =
   target cost per result x conversion rate. Show low, base and high
   scenarios with the conversion rates you assumed and where they came
   from. Every funded ad group should be able to buy about 100 clicks a
   month; if the budget cannot, cut ad groups rather than spreading thin.
8. **Plan the first 30 days.** Which campaigns launch first, the bidding
   strategy to start with (manual or maximise clicks with a CPC cap until
   conversions accrue, then a conversion-based strategy), what to check
   weekly in the search terms report, and the thresholds that trigger a
   change.

## Deliverables

- **Primary:** `ads-keyword-plan.xlsx` with sheets *Structure* (campaign,
  ad group, theme, landing URL, budget share), *Keywords* (campaign, ad
  group, keyword, match type, intent tier, volume and bid range with
  source, priority), *Negatives* (list or level, keyword, match type,
  reason), *Ad copy* (lines with a live `LEN()` check), *Budget* (inputs
  and formula-driven scenarios, no hard-coded outputs) and *Notes*.
- **Final:** `ads-editor-import.csv` with columns Campaign, Ad Group,
  Keyword, Criterion Type (Exact, Phrase, Broad, Negative Exact, Negative
  Phrase) and Final URL. Tell the reader to check the column names against
  the current Editor template before importing.
- **Final:** `ads-keyword-plan.md`: structure summary, budget verdict,
  launch sequence, risks and the first-month checklist.
- Present them:

  ```sh
  zen output present --type file --title "Search ads keyword plan — <business>" \
    --summary "<campaigns, ad groups and the expected cost per result>" \
    --primary ads-keyword-plan.xlsx="Keyword plan" \
    --final ads-editor-import.csv="Editor import" \
    --final ads-keyword-plan.md="Plan summary"
  ```

  If openpyxl is missing, deliver the sheets as separate CSV files (the
  Budget sheet then shows its formulas as text next to the computed
  values), present `keywords.csv` as `--primary` and the other sheets as
  `--supporting` items.

## Quality bar

- Every keyword belongs to exactly one ad group; no duplicate keywords
  across ad groups with the same match type.
- Headlines and descriptions respect the character limits, checked by
  formula.
- Estimated numbers name their source; assumed conversion rates are
  labelled as assumptions.
- Do not bid on terms the brief excluded, on trademarks where the offer
  would mislead, or on sensitive categories without flagging platform
  policy limits.
- The budget verdict is honest: say when the budget is too small for the
  plan and what to cut.

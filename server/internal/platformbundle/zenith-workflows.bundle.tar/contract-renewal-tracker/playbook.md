# Contract renewal tracker

You are building one tracker of when the Company's contracts renew, the
last day to cancel or renegotiate, and how prices can change at renewal.
The reader is a founder, finance lead or operator. The failure this
prevents is a missed notice window: an auto-renewal locks in another term,
often at a higher price. So the date that matters is the notice deadline,
not the renewal date, and the tracker is sorted by it.

This is decision support, not legal advice. Where a clause is unclear or a
large contract is at stake, recommend counsel check the notice mechanics.

## Inputs

- The contracts (text, links or a list), which extra sources to search,
  owners, the horizon, the warning lead time and extra fields are in the
  brief.
- Connectors, when available and selected, are used read-only:
  - Google Drive: search the linked folders for agreements, order forms,
    renewals and amendments.
  - Gmail: search for "renewal", "auto-renew", "your plan will renew",
    "price increase", "updated terms" and invoices from known vendors.
  - Xero: recurring bills and vendor spend, to find
    contracts nobody listed and to fill annual value.
  Never reply to vendors, cancel, change a plan or edit records.
- If none of the contracts can be read, stop and report it. If some can,
  build the tracker and list the unreadable ones as gaps.

## Procedure

1. **Inventory.** One row per contract relationship. Merge duplicates and
   group each relationship's document stack (master agreement, order
   forms, renewals, amendments). The latest signed order form usually
   controls term and price; confirm against the precedence clause.
2. **Extract the terms** for each: counterparty, what it covers, signed and
   start dates, current term end, renewal mechanism (automatic, evergreen
   until cancelled, manual, fixed end), renewal term length, the notice
   period and how notice must be given (written notice to an address,
   email, in-app setting), and the clause references.
3. **Compute the dates.**
   - Roll forward: if the original term has passed and it auto-renewed,
     find the current term end by adding renewal terms until it is in the
     future.
   - Notice deadline = current term end − notice period. When the clause
     says "at least" or "more than", treat the deadline as one day earlier,
     and respect business days if the contract uses them.
   - Warn-on date = notice deadline − the lead time.
   - Status: *act now* (warn-on date passed, deadline ahead), *upcoming*
     (deadline within the horizon), *later*, *window missed* (renewed this
     cycle — show the next one), *unknown* (dates not in the documents).
4. **Read the price clauses.** Fixed through the term, fixed uplift
   percentage, index-linked (name the index and its latest published value
   with a link), capped increase, "then-current list price" (effectively
   uncapped), or silent. Where the clause allows it, compute the maximum
   next-term cost from the annual value. Flag uncapped and unilateral
   changes, and online terms the vendor can change by posting.
5. **Capture the extras** the brief asks for: termination for convenience,
   minimum commitments and true-ups, annual value, payment terms, data
   export and exit duties.
6. **Recommend per upcoming item.** Renew, renegotiate, cancel or owner to
   decide, with the reason. With no usage or satisfaction data, default to
   "owner to decide" and say what information would settle it.
7. **List the gaps.** Spend with no contract found, contracts with no dates,
   click-through terms with no saved copy (record the URL and the date you
   read it), missing owners.
8. **Test the maths** on three contracts by hand before delivery.

## Deliverables

- **Primary:** `renewal-tracker.xlsx` (openpyxl):
  - *Tracker*: counterparty, description, owner, annual value, current
    term end, renewal mechanism, renewal term, notice period, notice
    method, notice deadline, warn on, days left (formula from TODAY()),
    status, price clause type, maximum uplift, next-term cost estimate,
    extras, clause references, source link, confidence.
  - *Upcoming*: rows with a notice deadline inside the horizon, sorted by
    deadline.
  - *Price clauses*: verbatim price-change wording per contract.
  - *Gaps*: what is missing and who can supply it.
- **Final:** `renewal-summary.md`: decisions due in the next 30, 60 and 90
  days, the biggest price-increase exposures and the gap list.
- **Supporting:** `renewals.ics` with an event on each warn-on date.
- Present:

  ```sh
  zen output present --type file --title "Contract renewal tracker" \
    --summary "<contracts tracked and notice deadlines in the next 90 days>" \
    --primary renewal-tracker.xlsx="Renewal tracker" \
    --final renewal-summary.md="Renewal summary" \
    --supporting renewals.ics="Notice reminders"
  ```

  Without openpyxl, deliver `renewal-tracker.csv` plus the summary.

## Quality bar

- Every date traces to a clause and a source document or email.
- Dates are computed conservatively; when unsure, the earlier deadline wins
  and the note says why.
- Estimates (index values, spend) are labelled as estimates with a source.
- Read-only across every Connector; nothing is sent, cancelled or changed.

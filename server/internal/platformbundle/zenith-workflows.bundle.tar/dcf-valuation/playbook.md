# DCF valuation

You are valuing one company from the cash it can generate. The reader will
use the answer to price an investment, a round, a purchase or a sale, so the
work must show which assumptions carry the value and how far it moves when
they change. Good means a defensible forecast, a sourced discount rate, two
terminal methods reconciled to each other, a clean bridge from enterprise
value to value per share, and a range rather than a false point estimate.
This is decision support, not investment advice; say so in the summary.

## Inputs

- Company, purpose, data source, valuation date (default today), forecast
  length, terminal method, cash flow basis, sensitivities and WACC views are
  in the brief.
- **Public company:** latest annual and quarterly filings for history,
  diluted shares, debt, leases, cash and investments; guidance from earnings
  materials; share price at the valuation date's close.
- **Provided projections** are the base case. Do not overwrite them; if you
  disagree, add your own case beside them and explain the difference.
- **Private company without usable numbers:** if revenue and margins cannot
  be established or reasonably estimated, stop and list what is needed.

## Procedure

1. **Normalize history.** Three to five years of revenue, EBITDA, EBIT,
   D&A, capex, working capital and cash taxes. Remove one-offs with a note.
   State two policies up front: stock-based compensation is treated as a
   real expense (not added back) unless the brief says otherwise, and
   leases are handled consistently (if lease liabilities are in the bridge,
   EBITDA excludes rent, and vice versa).
2. **Forecast to a steady state.** Growth fades toward a long-run rate,
   margins toward a mature peer level, capex toward depreciation plus the
   investment growth needs. Check reinvestment against growth: implied
   return on new invested capital = ΔNOPAT ÷ net reinvestment; flag
   anything implausibly high. Unlevered FCF = EBIT × (1 − tax rate) + D&A −
   capex − increase in net working capital. For levered FCF use net income
   + D&A − capex − ΔNWC + net borrowing, discounted at the cost of equity.
   For banks and insurers capex and working capital are not meaningful:
   prefer a dividend discount or excess-return model and say so.
3. **Build the WACC** on its own sheet, every input sourced and dated:
   - Risk-free rate: 10-year government yield in the cash flows' currency
     on the valuation date (US: FRED series DGS10).
   - Equity risk premium: a published estimate such as Damodaran's monthly
     implied ERP, with the month cited.
   - Beta: bottom-up from 5–10 listed peers. Unlever each with
     βu = βL ÷ (1 + (1 − t) × D/E), take the median, relever at the target
     debt-to-equity. Show the peer table with source and date.
   - Size or country premium only when justified, labelled as judgement.
   - Pre-tax cost of debt: yield on the company's traded debt, or a
     synthetic rating from interest coverage plus a current credit spread.
   - Weights: target or peer-median market-value capital structure.
   Apply overrides from the brief and show the computed value beside them.
4. **Terminal value.**
   - Perpetuity growth: TV = FCF(n+1) ÷ (WACC − g), with g at or below
     long-run nominal GDP growth and below the risk-free rate.
   - Exit multiple: current peer EV/EBITDA (EV/revenue if unprofitable)
     applied to final-year metrics.
   - Reconcile: show the multiple implied by the perpetuity value and the
     growth implied by the exit value; explain any gap. Flag when terminal
     value is more than 75% of enterprise value.
5. **Discount.** Mid-year convention (period t − 0.5), with a stub when
   the valuation date falls inside a fiscal year. Discount factors are
   formulas off the WACC cell.
6. **Bridge to equity.** Enterprise value − debt − leases (if consistent
   with step 1) − preferred stock − non-controlling interests + cash + non-
   operating assets (investments, equity stakes, surplus property) = equity
   value. Per share on diluted shares: treasury stock method for options
   and RSUs at the implied price, convertibles if-converted when in the
   money.
7. **Sensitivities.** Build each requested grid with live formulas, not
   Excel data tables: each cell recomputes value with `SUMPRODUCT` over the
   FCF row and a discount-period row, so the grid moves when inputs move.
   Centre on the base case, highlight it, and show "n/a" where WACC ≤ g.
8. **Sanity checks.** Compare with the market price, recent funding or
   deal prices and peer trading multiples. For listed companies add a
   reverse DCF: the revenue growth the current price implies. Explain large
   gaps in the memo; never tune inputs until a gap disappears.
9. **Recalculate** with LibreOffice headless and read results back with
   openpyxl `data_only=True`. Without LibreOffice, reproduce the valuation in
   Python and state that the workbook computes on open.

## Deliverables

- **Primary:** `dcf-<company>.xlsx` with sheets Summary (value range, per-
  share value, football-field table, disclaimer), Inputs, Historicals,
  Forecast and FCF, WACC, Terminal value, Bridge, Sensitivities, Sources.
- **Supporting:** `valuation-memo.md`, one to two pages: the range, the
  three drivers that matter most, WACC and terminal assumptions with
  sources, sanity checks and risks to the value.
- Present:

  ```sh
  zen output present --type file --title "DCF valuation — <company>" \
    --summary "<value range and base-case value per share in one sentence>" \
    --primary dcf-<company>.xlsx="DCF model" \
    --supporting valuation-memo.md="Valuation memo"
  ```

  If openpyxl is unavailable, deliver the memo with the tables as Markdown
  plus CSV schedules, present the memo as the `--primary` item with
  `--type text`, and say the model is not live.

## Quality bar

- Every input has a source link and date or is labelled as an assumption.
  Blue inputs, black formulas, no hard-coded outputs.
- Nominal cash flows with a nominal discount rate, in one currency.
- The headline is a range from the sensitivity grid's central band.
- Terminal growth never exceeds WACC or long-run nominal GDP growth.
- Share counts, units and the valuation date are stated on the Summary.

# Support inbox triage

You are clearing the first pass of an online store's customer support inbox:
sorting every open message by urgency and topic, checking the facts behind
each one, and drafting replies a person can review and send. The reader is
the owner or support lead. Good triage puts safety, money and legal risks at
the top, answers the customer's real question (usually "where is my order?")
with the actual order status, stays inside the store's policies, and surfaces
patterns the product team should hear about. You write drafts only; nothing
is ever sent, closed, refunded or changed.

## Inputs

- The brief gives the store, the scope, policies and facts, urgent rules,
  allowed goodwill, tone, sign-off and where drafts go.
- A support Connector is required: a mail inbox (Gmail) or a helpdesk
  (Zendesk). Without one, stop before drafting and report that the triage
  needs one. A store Connector (Shopify) is strongly recommended for order
  status and tracking; without it, write drafts that ask for or confirm the
  order number and say so in the report. Everything is read only except
  saving unsent drafts or internal notes.
- If no policies are given, read the store's public shipping, returns and
  FAQ pages; if you still lack a fact, leave a `[bracketed note]`.

## Procedure

1. **Collect.** Conversations in scope where the customer wrote last and no
   one has replied since. Merge duplicates from the same customer about the
   same order. Skip auto-replies and system notices; list spam and phishing
   separately (look for payment requests, spoofed domains, links to fake
   login pages) and never draft to them.
2. **Classify topic** (one primary): order status, delivery problem, damaged
   or faulty, wrong item, return or exchange, refund status, change or cancel,
   pre-purchase product question, discount or pricing, account or
   subscription, wholesale or partnership, feedback.
3. **Set urgency** and a reply-by target:
   - **Urgent (within 2 hours):** injury, safety or allergic reaction; legal
     threat; chargeback or dispute; double charge; suspected fraud or account
     takeover; threat of a public complaint; the brief's urgent rules.
   - **High (same day):** damaged, faulty or wrong item; parcel past its
     promised date; overdue refund; cancel or address change before shipping
     (the order may ship soon); a second or third message about the same
     issue.
   - **Normal (next business day):** status within the promised window,
     in-policy returns, product and sizing questions.
   - **Low:** feedback, thanks, pitches.
   Tone matters: raise one level when the customer is clearly angry.
4. **Look up the facts.** Find the order by number, then by the sender's
   email. Record status, items, dates, fulfilment, carrier and tracking,
   refunds issued. Only use an order in a reply when the sender's email
   matches it; otherwise ask the customer to confirm the order number.
5. **Draft replies** for Urgent, High and Normal messages:
   - First sentence answers the question or acknowledges the problem.
   - Use real facts: "Your order shipped on 3 October with UPS; tracking
     shows it arriving Friday" beats "it is on its way".
   - Damaged or wrong item: apologise once, ask for a photo only when the
     policy requires one, and state the next step and when it happens.
   - Offer only what policy and the allowed goodwill cover; anything more is
     a `[decide: …]` note, never a promise.
   - Safety, legal, dispute and fraud cases: a short, calm holding reply
     that commits only to a follow-up time, plus a flag for a person.
   - Match the tone, keep it under 120 words unless the question needs more,
     no internal jargon, and use the sign-off.
6. **Place drafts.** When the brief asks for drafts in the tool and the
   Connector can save an unsent reply draft or internal note on the
   conversation, save one per conversation. Otherwise write them into the
   report. Agent Mail (`create_mail_drafts`) creates new messages from the
   Company address rather than replies in the customer's thread, so use it
   only if the brief asks.
7. **Roll up patterns for the product team.** Group messages by product and
   issue ("lid cracks after washing", "size M runs small"), count customers
   and orders affected, quote one example each, and flag any safety issue.

## Deliverables

- **Primary:** `support-triage.md` titled "Support triage — <store> —
  <date>":
  1. Headline counts by urgency and topic, and the oldest waiting message.
  2. Urgent list: customer first name, the ask in one line, why it is urgent,
     what a person must decide.
  3. Conversation table: first name, topic, urgency, reply-by, order status,
     where the draft is.
  4. Drafts in full (when not saved in the tool), grouped by urgency.
  5. To resolve before sending: every bracketed note.
  6. Product and operations patterns, with counts.
  7. Skipped: spam, phishing and no-reply messages.
- Present it:

  ```sh
  zen output present --type text --title "Support triage — <store> — <date>" \
    --summary "<n> conversations; <n> urgent; <n> drafts ready" \
    --primary support-triage.md="Support triage"
  ```

## Quality bar

- Nothing is sent, closed, tagged, assigned, refunded or changed.
- Every order fact in a draft comes from the order record; no delivery date,
  refund or discount is invented.
- Order details are never shared with an email address that does not match
  the order.
- Urgent items are never buried; a reader sees them in the first screen.
- Customer data stays in the report; use first names only in tables.

# Market research report

You are producing a market research report that helps the Company decide
whether and how to enter a market. The reader is a founder, product lead
or investor who will act on it and will be challenged on its numbers.
Good output answers the questions in the brief directly, sizes the market
two independent ways with the maths in the open, grounds customer needs in
real customer words, and ends with the openings worth pursuing and what to
validate next. This is decision support built on public sources, not an
investment recommendation.

## Inputs

- Market, geography, buyer, the Company's idea, questions, sections,
  forecast horizon and any sources, all in the brief.
- Read every source the person shared first; it may be better than
  anything public. If a shared link cannot be opened, say so and continue.
- Google Drive via Connector, read-only, may hold shared reports.
- If the market definition is ambiguous (for example, "cleaning products"
  could include industrial), choose a definition, state it in the first
  section and keep to it.

## Procedure

1. **Define the market.** One paragraph: what product or service, which
   buyers, which geography, which currency and base year. List what is
   included and excluded. Every number later must match this definition.
2. **Size it top-down.** Start from published totals: government
   statistics (census and business registers, national accounts, trade
   and household spending surveys), industry associations, public company
   filings with segment revenue, and reputable analyst figures quoted in
   primary sources. Narrow to the defined market with explicit percentage
   cuts, each sourced or labelled as an assumption.
3. **Size it bottom-up.** Number of potential buyers x share who have the
   need x annual purchase frequency x price. Source each factor. Where you
   must assume, give a low, base and high value.
4. **Reconcile.** Compare the two results. If they differ by more than a
   factor of two, explain which assumptions drive the gap and which
   estimate you trust more. Report TAM (everyone with the need), SAM (the
   part the Company's model can serve) and SOM (a realistic share over
   the horizon, justified by comparable companies' growth, channel
   capacity and competition). Project growth over the horizon with a
   sourced growth rate or clearly labelled scenarios.
5. **Segment.** Split buyers by the variables that change what they buy
   and why: need, behaviour, size or demographics, channel. For each
   segment estimate size, growth, pain intensity, willingness to pay, ease
   of reach and competitive intensity, and score attractiveness 1 to 5 on
   each.
6. **Capture needs in customers' words.** Mine one- to three-star reviews
   of existing products, forums and communities, Q&A sites, and for
   business buyers job posts and public procurement notices. Write needs
   as jobs to be done ("when..., I want to..., so I can..."), rank them by
   frequency and severity, and keep two or three real quotes per need,
   anonymised, with links.
7. **Scan trends.** Technology, regulation, economics, behaviour and
   supply. For each trend: evidence, direction, timing and effect on the
   market (grows it, shrinks it, shifts it between segments).
8. **Map competitors.** Incumbents, challengers, substitutes and the
   do-it-yourself option. For each: offer, target segment, price point,
   channel, scale signals (funding, revenue if public, headcount) and
   reputation. Place them on a two-axis positioning map on the axes that
   matter most to buyers, and name the empty or underserved spaces.
9. **Cover the optional sections** requested: pricing and business
   models, distribution channels and their economics, regulation and
   barriers to entry.
10. **Conclude.** Answer each question from the brief in two or three
    sentences with the supporting numbers. Recommend the openings worth
    pursuing, the key risks, and the five cheapest experiments to validate
    the biggest assumptions (interviews, a landing page test, a pilot).

## Deliverables

- **Primary:** `market-research.docx` (python-docx), or
  `market-research.md` when the library is missing, titled "Market
  research — <market>": executive summary with the answers, market
  definition, sizing, segments, needs, trends, competitors, optional
  sections, openings and risks, validation plan, and sources.
- **Final:** `market-model.xlsx` with sheets *Inputs* (every assumption
  with source and low, base, high values), *Top-down*, *Bottom-up* and
  *Projection* using live formulas that reference Inputs, *Segments*,
  *Competitors* and *Sources*. Label currency, units and base year.
- Present them:

  ```sh
  zen output present --type file --title "Market research — <market>" \
    --summary "<SAM, the most attractive segment and the main opening>" \
    --primary market-research.docx="Market research report" \
    --final market-model.xlsx="Market sizing model"
  ```

  Use `--type text` with the `.md` path when you delivered Markdown.
  Without openpyxl, deliver one CSV per sheet (`market-inputs.csv`,
  `market-top-down.csv`, `market-bottom-up.csv`, `market-projection.csv`)
  plus the Python script that computes them, as `--final` items.

## Quality bar

- Every figure has a source link and year, or is labelled an estimate with
  its derivation shown in the model.
- No single analyst headline number stands alone as the market size.
- Distinguish fact, estimate and inference in the text.
- Quotes are real, dated, linked and stripped of personal names.
- Note the gaps: what could not be found and how it changes confidence.

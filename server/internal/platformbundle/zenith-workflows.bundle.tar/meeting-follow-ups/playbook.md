# Meeting follow-ups

You are drafting the email that goes out after a meeting — the one that
turns a good conversation into a commitment. The reader of each draft is
the person who hosted the meeting; the reader of the email is the other
side. A strong follow-up is short, specific to what was said, makes both
sides' commitments explicit and ends with one clear next step. You produce
drafts only: nothing is sent until the person approves it.

## Inputs

- The meetings: pasted notes or transcripts, links, or a description such
  as "my external calls yesterday". Resolve descriptions with a calendar
  Connector (attendees, title, time) and a meeting-recorder Connector
  (Fireflies, Gong) when available. If a meeting has no notes and no
  transcript can be found, draft only a brief thank-you with the next step
  if one is known, and flag that the recap is missing — never invent what
  was discussed.
- Audience, goal, what to include, materials, tone, sign-off and where the
  drafts go.
- A CRM Connector (HubSpot) is optional context: deal stage, earlier
  emails, the contact's role. Read it; never update records.

## Procedure

1. **Build the meeting list.** For each meeting capture title, date,
   attendees split into *our side* and *their side*, and the source of the
   notes. When the audience is "a mix", classify each meeting as external
   if any attendee is outside the Company's email domain.
2. **Extract the substance** from the notes:
   - The problem or goal the other side described, in their own words.
   - Decisions reached and anything explicitly left open.
   - Commitments by each side, each with an owner and a date.
   - The agreed next step; if none was agreed, propose one that fits the
     goal (a working session, a proposal by a date, a decision call).
   - Materials promised (deck, pricing, case study, recording).
3. **Separate internal from external.** Notes often contain things the
   other side must never see: price floors, negotiation strategy, opinions
   about individuals, competitor intel, internal disagreements. Keep all of
   it out of external drafts and list what you left out in the review
   notes.
4. **Draft each email** with this shape, trimmed to the brief's include
   list:
   - **Subject** — specific and searchable: "<Their company> × <Our
     company> — recap and next steps (<date>)" for external meetings,
     "<Topic> — decisions and owners" for internal ones.
   - **Opening** — one line of thanks tied to something specific from the
     conversation, not a generic pleasantry.
   - **Recap** — three to five bullets, their priorities first.
   - **Commitments** — "From us:" and "From you:" lists with dates. Phrase
     their side politely ("As discussed, you'll share…").
   - **Next step** — one concrete action. When a meeting is needed, offer
     two or three slots from the calendar with the time zone written out,
     or a booking link from the brief.
   - **Materials** — links from the brief only; never attach or link
     anything you were not given.
   - **Close** — the sign-off from the brief.
   Keep external follow-ups under about 200 words and internal ones as
   short as the decisions allow. For sales meetings restate value in the
   buyer's language, avoid pressure tactics, and never offer a discount,
   term or price that was not agreed in the meeting or given in the brief.
5. **Address it correctly.** External: the other side's attendees in To,
   our other attendees in Cc. Internal: all attendees in To. Use
   addresses from the calendar event or notes only; mark any missing
   address as `[email address]`.
6. **Place the drafts** per the brief:
   - **Agent Mail**: call `create_mail_drafts` with one draft per meeting
     and one delivery per meeting (`to` and `cc` as above; plain-text
     body). When only the CLI is available, run
     `zen mail draft --to <address> --subject "<subject>" --text-file <body.txt>`
     per email, repeating `--to` for each To recipient; the CLI has no Cc
     option, so list the intended Cc addresses in the review notes. If
     Agent Mail is not enabled for this Agent, fall back to the document
     and say so.
   - **Mailbox**: save unsent drafts through the mail Connector if it can;
     otherwise fall back to the document.
   - Always also write the review document below.

## Deliverables

- **Primary:** `follow-ups.md` titled "Meeting follow-ups — <date>" with,
  per meeting: the meeting (title, date, attendees), where the draft was
  placed, recipients, subject, body exactly as it would be sent, and
  review notes (assumptions, `[placeholders]` to fill, internal points
  deliberately left out).
- A short table at the top: meeting, recipients, next step, draft
  location, needs attention (yes/no).
- Present it:

  ```sh
  zen output present --type text --title "Meeting follow-ups — <date>" \
    --summary "<n> follow-ups drafted; <n> need a detail from you" \
    --primary follow-ups.md="Follow-up drafts"
  ```

## Quality bar

- Drafts only. Never send, and never create a draft for someone who was
  not in the meeting unless the brief names them.
- Every recap bullet and commitment traces to the notes; nothing is
  embellished or invented.
- No internal-only information reaches an external draft.
- Each email ends with exactly one next step that has an owner and a date.
- Names, titles and company names are spelled exactly as in the calendar
  event or notes.

# Unanswered threads

You are finding the conversations that have stalled — the ones where
someone is quietly waiting on the person, and the ones where the person is
waiting on someone else and has forgotten to chase. Dropped threads cost
deals, goodwill and weeks of delay; a reliable list costs minutes to act
on. Good output is precise (no false positives from "thanks!" messages),
ranked by what matters, and ready to act on with a reply gist or a nudge.
This workflow is read-only.

## Inputs

- Direction, look-back window, the minimum wait, the sources, people who
  always rank first and what to leave out.
- Connectors: a mail Connector for email; a chat Connector (Slack) for
  channels and direct messages; tracker or docs Connectors for comments
  that mention the person. Use each read-only. When a chosen source has no
  Connector, note it and continue; if none are available, stop and report
  that the workflow needs at least one.
- The person's own identities (email addresses, chat handle) come from
  the Connectors' account details; list any alias you could not confirm.

## Procedure

1. **Collect candidate conversations** in the window: email threads the
   person is on, direct messages and group DMs, channel threads where the
   person posted or was mentioned, and (when chosen) ticket or doc
   comments that mention them.
2. **Find the last meaningful message** in each. Ignore auto-replies,
   read receipts, calendar notifications and bot posts when deciding who
   spoke last.
3. **Apply the waiting tests.**
   - *Waiting on the person:* the last meaningful message is from someone
     else; it is addressed to the person (To in email, a DM, or an
     @mention); it contains a question, a request, a proposal awaiting
     approval or a document awaiting review; and the person has not
     replied or acted since.
   - *Waiting on someone else:* the last meaningful message is the
     person's; it asks a question, requests something or proposes a
     next step; and nobody has answered since.
   - The wait, measured in working days (Monday to Friday) from that
     message to now, is at least the minimum in the brief.
   Apply only the direction the brief asks for; when it asks for one
   side, leave the other list out of the report.
4. **Remove false positives.** A conversation is closed when the last
   message only acknowledges ("thanks", "great", "will do"), when a
   reaction clearly answers a yes/no question, when another participant
   answered on the person's behalf, when the ask was resolved elsewhere
   (a later thread, a merged pull request, an accepted invite), or when
   the person's reply went to a forked thread. Remove automated senders,
   bulk mail and everything on the leave-out list.
5. **Merge across tools.** The same person on the same topic in email and
   chat is one conversation; keep the most recent link and mention the
   other.
6. **Rank.** Score each conversation: people who rank first, then money,
   customers, legal or stated deadlines, then seniority or external
   status of the other side, then days waiting. Mark anything waiting
   more than twice the minimum as **overdue**.
7. **Suggest the move.**
   - For waiting-on-the-person items: the gist of a good reply in one
     line, or the decision the person must make first. Say "close it"
     when the thread no longer needs an answer.
   - For waiting-on-them items: a nudge of one or two sentences that
     restates the ask and offers an easy out ("If it's easier, a quick
     yes or no works"). Escalate tone only after a second nudge, and
     suggest a different channel (call, chat) when email has gone
     unanswered twice.

## Deliverables

- **Primary:** `unanswered-threads.md` titled "Unanswered threads —
  <date>" with:
  1. **Summary** — counts per list and the three most overdue items.
  2. **Waiting on you** — table: who, where (email or channel, with link),
     the ask, days waiting, priority, suggested reply gist.
  3. **Waiting on them** — table: who, where, what you asked, days
     waiting, suggested nudge.
  4. **Closed or skipped** — a count of false positives removed, by
     reason, so the person can trust the lists.
  5. **Gaps** — sources not read and identities not confirmed.
- Present it:

  ```sh
  zen output present --type text --title "Unanswered threads — <date>" \
    --summary "<n> waiting on you, <n> waiting on others; oldest: <n> days" \
    --primary unanswered-threads.md="Unanswered threads"
  ```

## Quality bar

- Read-only: never send the nudges, post, react, archive or mark read.
- Every row links to the conversation or names exactly where it lives.
- Days waiting are working days, computed from the timestamp of the last
  meaningful message.
- No private message content beyond the one-line ask appears in the
  report.
- If nothing is waiting, say "No open loops" and stop.

# Competitor price check

You are showing a store owner where their prices stand against the competitors
a shopper would actually compare them with, product by product. Shoppers
compare what they pay at the door, so good output compares delivered prices
(item, promotions and shipping) on like-for-like products, dates every
observation, and ends with a clear call per product that respects the
owner's margin and pricing rules. This is decision support; pricing decisions
stay with the owner.

## Inputs

- The brief gives the product line, our products and prices, competitors,
  market and currency, matching strictness, what to compare, and our costs
  and pricing rules.
- A store Connector (Shopify) can supply our current prices, compare-at
  prices, barcodes and unit costs; read only. A drive Connector opens a
  linked product sheet. A crawling Connector (Firecrawl) helps read public
  pages at scale; a normal browser works too.
- If our product list cannot be read, stop and report. If a competitor site
  blocks automated access, record "not checked" with the reason; never guess
  a price.

## Procedure

1. **Normalise our side.** For each product: name, size or count, barcode
   (GTIN, UPC or EAN), model number, current price, compare-at price, unit
   cost when given, and our shipping terms (cost for one unit, free-shipping
   threshold, delivery estimate, returns window).
2. **Match.** Search each competitor for the barcode, then the model number,
   then name plus size. Grade each match: **exact** (same product and size),
   **equivalent** (same use, different brand or spec; list the differences)
   or **none**. With "exact matches only", drop equivalents. Where pack sizes
   differ, compute a unit price (per 100 ml, per count, per kg).
3. **Observe like a shopper.** Use a clean, logged-out session set to the
   brief's market and a reference postcode. For each match record: list or
   strikethrough price, current price, promotion visible on the page or site
   banner, publicly advertised codes, shipping for one unit, free-shipping
   threshold, delivery estimate, returns terms, stock status and, on
   marketplaces, who sells and ships it (brand, retailer or third party).
   You may add an item to a guest cart to reveal shipping; never create an
   account, start checkout payment or enter any details. Record the URL and
   the timestamp of every observation. Respect robots.txt and site terms,
  keep request rates human, and skip any site that asks you to sign in.
4. **Compare like with like.** Keep tax treatment consistent (US prices are
   shown before sales tax; UK and EU prices include VAT). Exclude used,
   refurbished and member-only prices, or show them separately.
5. **Compute.**
   - Delivered price = current price after automatic discounts + shipping
     for one unit (also show it at the free-shipping threshold when the
     basket is usually larger).
   - Price index = our delivered price / median competitor delivered price x
     100, using exact matches first.
   - Position: below 95 cheaper, 95-105 parity, 105-115 premium, above 115
     well above market.
   - Margin now and at the suggested price = (price - unit cost) / price,
     when cost is known.
6. **Find the price-perception items.** Mark key value items: best sellers,
   entry-level products and the items shoppers search for by name. Gaps on
   these shape how expensive the whole store feels; gaps on accessories
   and niche items matter less.
7. **Make a call per product.** Hold, lower, raise, or change terms instead
   (shipping threshold, bundle, promotion). Rules: never suggest a price
   below the margin floor or below a minimum advertised price the brief
   names; prefer fixing shipping or promotions when the item price is at
   parity but the delivered price is not; call out products priced below
   market with margin headroom. State the expected trade-off in one line.
8. **Stay on the right side of competition law.** Use only public prices.
   Never contact competitors, and never suggest signalling or coordinating
   prices; the recommendations are for the owner's independent decision.

## Deliverables

- **Primary:** `price-check.xlsx` (openpyxl) with sheets: `Summary` (one row
  per product: our delivered price, min, median and max competitor delivered
  price, index, position, call, margin impact), `Observations` (every
  competitor observation with URL and timestamp), `Matches` (match grade and
  differences), `Terms` (shipping, thresholds, delivery speed, returns,
  multi-buy and subscription offers by competitor), `Sources`. Use formulas
  for delivered price, index and margin. Without openpyxl, write
  `price-check.csv` from the Summary and put the rest in the report.
- **Final:** `price-check.md` titled "Competitor price check — <product
  line> — <date>": headline position, the five largest gaps on key value
  items, terms comparison, the calls table, and method and limits.
- Present them:

  ```sh
  zen output present --type file --title "Competitor price check — <product line>" \
    --summary "<n> products checked; we are <position> on <n> key items" \
    --primary price-check.xlsx="Price comparison" \
    --final price-check.md="Findings and calls"
  ```

## Quality bar

- Every competitor price has a URL, a timestamp and a match grade.
- Delivered price, not sticker price, drives the index and the calls.
- Unit prices are used whenever pack sizes differ; currencies are never
  mixed.
- No call breaks the margin floor or a stated pricing rule.
- Say plainly that prices change daily and that the check is a snapshot.

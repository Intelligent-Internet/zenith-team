# Acquisition underwriting

You are building the underwriting for one income-property acquisition: from
the seller's rent roll and trailing operating statement to an underwritten
NOI, a financed cash flow over the hold, and the returns and debt metrics a
lender, partner or investment committee will test. The reader is an
investor or acquisitions lead. Good underwriting re-underwrites the seller's
numbers rather than accepting them, uses live formulas with every
assumption in one place, reconciles to the source documents, and shows how
fragile the returns are. It is decision support, not investment advice.

## Inputs

- Property, asset type, price and closing costs, rent roll, trailing
  12-month (T12) statement, business plan, financing, hold period and
  targets — all in the brief.
- If the rent roll or T12 is missing or unreadable, stop and report;
  never model from an offering memorandum's pro forma alone. The exception
  is a lease-up of a vacant or new asset, where neither exists: underwrite
  from the unit or suite mix, cited market rents, a month-by-month lease-up
  schedule with concessions, and benchmarked expenses, and label the whole
  income side as an estimate.
- Missing financing terms: use current market terms for the asset type
  from a cited lender survey or rate source and label them. Market rents,
  cap rates and expense benchmarks come from cited public sources, broker
  research or comparable listings, each dated.

## Procedure

1. **Analyze the rent roll.** Unit mix or suite schedule, occupied and
   vacant units, in-place versus market rent (loss-to-lease), lease
   expirations by month, concessions, delinquency, and any non-revenue or
   employee units. For commercial assets: tenant, area, lease start and
   end, rent steps, recoveries structure (gross, modified gross, NNN),
   options, weighted average lease term, and the rollover schedule. Check
   the rent roll's monthly total against the T12's latest months.
2. **Normalize the T12.** Annualize, reclassify, and adjust: remove
   one-time items and owner expenses; reset property tax to the expected
   reassessment at the purchase price under local rules; replace
   insurance with a current quote or benchmark; set management at a
   market percentage of effective gross income; add payroll, repairs and
   utilities at supportable levels; add replacement reserves
   (multifamily commonly $250–400 per unit per year; commercial per
   square foot). Show seller figure, adjustment, underwritten figure and
   reason in adjacent columns.
3. **Build the pro forma** by year for the hold plus one: gross potential
   rent from the rent roll with market-rent resets at turnover or lease
   expiry; renovation premiums following the plan's schedule; less
   vacancy, credit loss and concessions; plus other income; equals
   effective gross income; less operating expenses (growing at stated
   rates) equals NOI; less reserves and capital expenditure equals cash
   flow before debt service. Commercial: model rollover with downtime,
   tenant improvements and leasing commissions per lease.
4. **Model the debt.** Size the loan as the lowest of the LTV, the DSCR
   and the debt-yield constraints; model interest-only and amortizing
   periods, fees, and any rate cap cost for floating debt. Report DSCR
   and debt yield every year.
5. **Model the exit.** Sale at the end of the hold on the following year's
   NOI divided by an exit cap rate (default: going-in cap plus 25–50 basis
   points, stated), less selling costs of 1–3%, less loan payoff.
6. **Compute the returns.** Going-in cap rate (year-1 NOI ÷ price),
   yield on cost (stabilized NOI ÷ total cost), unlevered and levered IRR
   (XIRR on dated cash flows), equity multiple, cash-on-cash by year,
   break-even occupancy, price per unit or per square foot, and the
   sources and uses of funds. Compare with the targets.
7. **Run sensitivities.** Two-way tables of levered IRR for exit cap rate
   × rent growth, vacancy × interest rate, and purchase price × exit cap
   rate. Excel data tables do not compute in openpyxl, so compute the
   grids in Python with the same logic, label them as calculated outputs,
   and confirm the base-case cell equals the live model.
8. **Flag the risks** the numbers reveal: exit cap below entry cap, rent
   growth above the market's history, expense ratio below comparables,
   refinance or maturity dependency, tenant concentration, heavy near-term
   rollover, and capital needs not covered by reserves.

## Deliverables

- **Primary:** `underwriting-<property>.xlsx` with sheets `Inputs` (every
  assumption, blue font), `Rent roll`, `T12 normalization`, `Pro forma`,
  `Debt`, `Returns`, `Sensitivity`, `Sources & uses`, `Checks` (rent roll
  ties to T12, sources equal uses, loan within every constraint, cash
  flows sum), `Sources` (citation and date for each market input).
- **Final:** `underwriting-summary.md`: the deal in one paragraph, key
  assumptions against T12 and market, returns versus targets, the
  sensitivity headline, risks, and what to verify in diligence.
- Present:

  ```sh
  zen output present --type file --title "Acquisition underwriting — <property>" \
    --summary "<levered IRR, equity multiple and minimum DSCR versus targets>" \
    --primary underwriting-<property>.xlsx="Underwriting model" \
    --final underwriting-summary.md="Underwriting summary"
  ```

  Without openpyxl, deliver the model as CSV tables plus the Python
  script that produced them, and make the summary primary with
  `--type text`.

## Quality bar

- Live formulas throughout; no typed outputs except labelled sensitivity
  grids.
- Every check on the `Checks` sheet shows zero difference or TRUE.
- Seller figures and underwritten figures are both visible, with reasons.
- Market inputs cite a source and date; estimates are labelled.
- Units, currency, and year labels (year 1 starts at closing) are
  explicit on every sheet.

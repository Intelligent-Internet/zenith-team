# Local lead finder

You are building a list of local businesses that a person can approach — in
person, by phone or by email — about an offer that suits businesses like
them. The reader is often a small agency, a local service provider or a B2B
seller with a territory. Good output is a clean, verified list of businesses
that really operate in the area, the channels they publish for enquiries,
and a specific, observable reason each one might want the offer.

## Inputs

- Business type, area, offer, signals to prioritize, exclusions and count —
  all in the brief.
- Connectors: a CRM (HubSpot, read-only) to drop businesses already in the
  pipeline; Firecrawl to read business websites.
- If the area is vague ("the Bay Area"), define a concrete boundary — a list
  of towns or a radius around a point — and state it. If the category is
  ambiguous ("clinics"), choose the reading that fits the offer and state it.

## Procedure

1. **Define the search.** Write the category synonyms and the edge cases to
   exclude (for "dentists": general dentists, dental clinics, orthodontists;
   exclude hospital departments). Turn the area into place names or a
   bounding box.
2. **Enumerate candidates** from sources that permit it:
   - OpenStreetMap through the Overpass API — open data under the ODbL,
     credited "© OpenStreetMap contributors" — using the matching tags (for
     example `amenity=dentist`, `shop=bakery`, `craft=plumber`);
   - chamber of commerce and local business association directories;
   - licensing and trade registries (many states and cities publish licensed
     contractors, clinics and food businesses);
   - web searches such as "<category> in <town>" to reach businesses' own
     sites.
   Do not bulk-scrape map or review platforms whose terms forbid it; open
   individual public listing pages only to verify a business.
3. **Deduplicate.** Merge by normalized name plus street address or phone;
   keep one row per location; mark chains and multi-location businesses and
   apply the exclusions.
4. **Verify each business is operating.** Require at least one recent sign
   of life: a website updated in the last year, recent reviews or posts, or
   current opening hours. Drop listings marked permanently closed.
5. **Collect published contact channels** — only those the business
   publishes for customers or enquiries: website, main phone, a business
   email shown on its site, contact-form link, booking or ordering link, and
   business social pages. Never add personal mobile numbers, owners'
   personal emails or home addresses. If a sole trader publishes a mobile
   number as the business line, record it as published and label it.
6. **Check the fit signals.** Record the observable facts behind each chosen
   signal: website present, mobile-friendly, served over HTTPS, online
   booking, last update; review count and average rating with the platform
   and the date checked; social activity; open job ads; opening date; number
   of locations.
7. **Score and write the angle.** Score 0–100 against the prioritized
   signals and the offer. Write a one-line fit note ("No online booking;
   several recent reviews mention long phone waits") and a one-sentence
   opening angle usable at the door or in an email.
8. **Add compliance reminders** to the method sheet: check do-not-call
   registries and local telemarketing rules before cold calling, and follow
   email marketing rules (identify the sender, offer an opt-out).

## Deliverables

- **Primary:** `local-leads-<category-slug>.xlsx` with sheets:
  - *Businesses* — rank, name, category, address, town, website, phone,
    public email, contact form, booking link, social pages, rating and
    review count (platform and date checked), signals observed, score, fit
    note, opening angle, source links;
  - *Method* — area definition, sources, search terms, exclusions, scoring,
    compliance reminders and data attribution (OpenStreetMap when used);
  - *Removed* — duplicates and closed or excluded businesses, with reasons.
  If openpyxl is unavailable, deliver the sheets as CSV.
- **Final:** `local-leads-<category-slug>.csv` — the Businesses sheet, for
  import or a mail merge.
- Present it:

  ```sh
  zen output present --type file --title "Local leads — <category>, <area>" \
    --summary "<N businesses found; the most common signal; the best three prospects>" \
    --primary local-leads-<category-slug>.xlsx="Local leads" \
    --final local-leads-<category-slug>.csv="Import file"
  ```

## Quality bar

- Every business is real, operating and inside the defined area, with a
  source link.
- Published business channels only; no personal data about owners or staff
  beyond names they publish in a business role.
- Ratings and review counts are dated and attributed to their platform.
- Fit notes cite observable facts, never assumptions about a business's
  finances or owners.
- Nothing is contacted, submitted or posted; contact forms are recorded,
  never filled in.

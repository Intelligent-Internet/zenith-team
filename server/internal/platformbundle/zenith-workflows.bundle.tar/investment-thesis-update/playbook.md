# Investment thesis update

You are re-testing an investment thesis the team already holds against what
has actually happened since it was last reviewed. The reader is the analyst
or portfolio manager who owns the position and must decide whether
conviction has risen, held or fallen. Good output is disciplined: every
pillar gets a verdict backed by dated, sourced facts; triggered falsifiers
are impossible to miss; and nothing is scored on price action alone. This
is research and decision support, not investment advice; sizing and trading
decisions stay with the team.

## Inputs

- The company, the current thesis, the last review date, the position type,
  depth, evidence families and any notes on what changed internally.
- If the thesis link cannot be opened, stop and report it. Never
  reconstruct a thesis from memory or from the web.
- If the thesis has no explicit milestones or falsifiers, derive candidates
  from its pillars, label them "proposed" and score them separately.
- Google Drive or Notion Connectors, when present, often hold the original
  memo, the model and meeting notes. Read them; never edit them.

## Procedure

1. **Build the thesis register.** Split the thesis into numbered items:
   pillars (P1, P2…), milestones (M1…) and falsifiers (F1…). For each,
   record the claim in one sentence, the metric that evidences it, the
   original expectation (level, direction and date) and where to check it.
   Show the register first so a reader can correct a misreading.
2. **Collect dated developments** from the last review date to today for
   the evidence families in the brief. Listed companies: EDGAR (10-Q, 10-K,
   8-K, DEF 14A, Forms 4 and 13D/G) or the home-market regulator, IR
   releases and decks, call transcripts, competitor and supplier results,
   regulator actions and trade press. Private holdings: board packs and
   company updates in the Connectors, funding and hiring news, customer
   announcements. Keep only items that have a date and a source.
3. **Log each development**: date, source link, the fact in one sentence,
   the register items it touches, direction (supports, contradicts,
   neutral) and materiality (high, medium, low). Keep fact and
   interpretation in separate columns.
4. **Score pillars** with fixed rules:
   - **Strengthened**: the evidencing metric beat the original expectation,
     or a key uncertainty resolved in the thesis's favour.
   - **Intact**: evidence is in line, or mixed without a trend.
   - **Weakened**: one reporting period or one credible source contradicts
     it, but no falsifier threshold is crossed.
   - **Broken**: a linked falsifier triggered, or the metric moved against
     the thesis for two consecutive periods.
   - **Untested**: no new evidence yet; say when there will be.
5. **Check milestones**: hit, on track, slipped (give the new expected
   date), missed or superseded. A milestone that slips twice counts as
   missed unless management gave a specific, credible reason.
6. **Test falsifiers**: not triggered, approaching (within 20% of the
   threshold, or moving toward it for two periods) or triggered. Every
   triggered falsifier goes to the top of the memo with its evidence.
7. **Check what is priced in.** Listed positions: share price and relative
   performance since the last review, the change in the valuation multiple
   the thesis uses (forward EV/sales, EV/EBITDA or P/E) and the direction of
   estimate revisions where visible. Private holdings: latest round price,
   fund marks and comparable public multiples. Ask whether the upside the
   thesis claimed is still available.
8. **Look for drift.** List material developments that touch no register
   item: a new competitor, a regulation, a management change, a capital
   allocation decision. Propose new pillars or falsifiers where warranted.
9. **State the conviction change**: up, unchanged or down, in two
   sentences, naming the two or three facts that drove it. Frame
   implications as questions for the team ("the margin pillar no longer has
   support; revisit sizing"), not trade instructions. For a short position,
   evidence that supports the thesis is bad news for the company; keep the
   direction straight.
10. **Write the revised register**: updated expectations, new dates for
    slipped milestones, sharper falsifiers with numeric thresholds, and the
    next checkpoints (earnings dates, regulatory decisions, launches) with
    dates.

## Deliverables

- **Primary:** `thesis-update-<company>.docx` (Markdown if python-docx is
  unavailable), titled "Thesis update — <company> — <today>":
  1. Bottom line: conviction change, triggered falsifiers, the three facts
     that matter most.
  2. Scorecard: item, original wording, verdict, key evidence with date and
     link.
  3. Milestone and falsifier tables.
  4. What the market is pricing.
  5. Drift: developments outside the thesis.
  6. Revised thesis register and next checkpoints.
  A quick check keeps sections 1, 2, 3 and 6 within two pages.
- **Full review only:** `thesis-tracker.xlsx` with sheets Register, Log (one
  row per development), Checkpoints and Sources.
- Present:

  ```sh
  zen output present --type file --title "Thesis update — <company>" \
    --summary "<conviction change and any triggered falsifier in one sentence>" \
    --primary thesis-update-<company>.docx="Thesis update" \
    --final thesis-tracker.xlsx="Thesis tracker"
  ```

  Drop `--final` for a quick check. Use `--type text` with the `.md` path
  when you delivered Markdown; deliver the tracker as CSV files if openpyxl
  is missing.

## Quality bar

- Every verdict cites at least one dated source; no verdict rests on share
  price moves alone.
- Quote the original thesis wording beside each verdict so the reader sees
  what was claimed against what happened.
- Separate fact from inference in every row; label estimates.
- Report bad news first and plainly; never soften a triggered falsifier.
- Do not move the goalposts: when you rewrite a pillar or a threshold, show
  the old and new text side by side and say why.

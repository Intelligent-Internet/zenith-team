# Key driver analysis

You are finding out what actually moves one listed company's share price, as
distinct from what the narrative says moves it. The reader is a portfolio
manager or analyst who wants to know which variables to watch, how
sensitive the stock is to each and how stable those links are. Good work
tests candidates against the stock's own history with honest statistics,
checks results out of sample and never confuses correlation with cause.
This is research, not investment advice.

## Inputs

- Company and ticker, history length, return frequency, benchmark and
  driver families, plus — when given — suspected drivers and data the team
  can share.
- Estimate-revision histories and many industry series sit behind paid
  terminals. If the team has not supplied them and no free source exists,
  test the closest free proxy (for example the reaction to guidance
  changes) and state the substitution.
- Use free sources that allow programmatic access and respect their terms:
  exchange or vendor price history, FRED and central banks for rates and
  macro data, EIA, USDA and exchange settlement data for commodities, the
  Kenneth French data library for style factors, and filings for KPIs.

## Procedure

1. **Generate hypotheses.** From the annual report (segment data, MD&A
   sensitivity statements, risk factors), the last eight earnings calls
   (the topics analysts ask about most) and industry context, list 10 to 25
   candidates. Map each to a measurable series with its frequency,
   publication lag and source.
2. **Assemble the data.** Adjusted prices for the stock, benchmark, sector
   index and peers; log returns at the chosen frequency (Friday or
   month-end closes). Transform drivers into changes: percent change for
   prices, basis-point change for yields and spreads, surprise against the
   prior reading for releases. Align each data release to its **publication
   date**, not its reference period, so nothing is known before it was
   public.
3. **Fit baselines.** Regress excess returns on the market for beta and R²;
   add the sector for the industry share; add style factors (market, size,
   value, profitability, investment, momentum) where the library covers the
   market. Keep the residuals as the stock-specific return.
4. **Test drivers one at a time** against total and residual returns:
   coefficient, t-statistic with Newey-West standard errors, correlation,
   incremental R², and the sign in each third of the sample. Test a one
   period lead or lag only where a mechanism justifies it.
5. **Guard against false positives.** Many candidates means some look
   significant by chance: apply a Benjamini-Hochberg correction and report
   raw and adjusted p-values.
6. **Build a multivariate model** from the survivors. Flag collinearity
   (variance inflation factor above 5), keep at most one driver per 15
   observations, fit on the first 70% of the sample and test on the last
   30%, and report in-sample and out-of-sample R².
7. **Check stability.** Rolling 52-week (or 24-month) betas and correlations
   for the top drivers; name each regime break and the events around it.
8. **Study earnings days.** For each report in the window, compute the
   abnormal return (stock minus beta × market) from the day before to the
   day after, and relate it to surprises in revenue, EPS, guidance and the
   key KPI. Show which surprise best explains the reaction (rank
   correlation) and what share of return variance falls on earnings days.
9. **Decompose variance** into market, sector, factors, macro drivers,
   earnings days and the unexplained residual.
10. **Interpret.** Rank drivers by robust explanatory power. For each give a
    plain sensitivity ("a 10% monthly rise in corn futures has coincided
    with about 2% higher relative return"), the likely mechanism, its
    stability and caveats. Finish with the dated release calendar for the
    top drivers.

## Deliverables

- **Primary:** `key-drivers-<ticker>.docx` (Markdown if python-docx is
  unavailable): 1. Summary and ranked driver table; 2. Method and data;
  3. Baselines and variance decomposition; 4. Driver results with charts;
  5. Stability and regimes; 6. Earnings reactions; 7. What to watch, with
  dates; 8. Limitations.
- **Final:** `key-drivers-<ticker>.xlsx` with Sources, Returns, Drivers,
  Single tests, Multivariate, Rolling, Earnings events and Checks sheets.
- **Supporting:** `analysis.py`, the script that reproduces every number.
- Present:

  ```sh
  zen output present --type file --title "Key drivers — <ticker>" \
    --summary "<the top two drivers and the share of variance they explain>" \
    --primary key-drivers-<ticker>.docx="Key driver report" \
    --final key-drivers-<ticker>.xlsx="Driver workbook" \
    --supporting analysis.py="Analysis script"
  ```

  Without python-docx, deliver the report as Markdown with `--type text`;
  without openpyxl, deliver the workbook sheets as CSV files.

## Quality bar

- No look-ahead: every driver value was public on the date it is aligned
  to.
- Every statistic states its sample, frequency and standard-error method.
- Links that fail out of sample or flip sign between sub-periods are
  reported as unstable, never dropped silently.
- Write "coincided with", not "caused", unless a mechanism is documented.
- Charts label units, dates and sources.

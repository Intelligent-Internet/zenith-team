# Inbound lead qualification

You are triaging inbound leads so the best-fit, most urgent ones get a human
response first and nobody falls through the cracks. The reader is a founder
or sales lead who wants a ranked list: who to call now, who to email today,
who goes to nurture and who to decline politely. Inbound interest cools
within hours, so the output must be decisive — but every score shows its
evidence.

## Inputs

- Pasted leads, or none — then read leads received in the window from the
  CRM (HubSpot, Salesforce), form tools (Typeform) or the inbox (Gmail),
  plus a Slack channel where lead alerts land. If nothing is pasted and no
  CRM, form or mail Connector is connected, stop before scoring and say
  what is missing; if they return no leads, report that there is nothing
  to qualify.
- Criteria, framework, routing rules, disqualifiers and our offer — all in
  the brief. When the criteria are prose, restate them as a numbered
  checklist first and include it in the output.
- Every Connector is read-only here: never reply, assign owners, change
  lifecycle stages or post to Slack.

## Procedure

1. **Collect and normalize.** One row per lead: name, email, title, company,
   domain, country, source, time received, and the lead's own message or
   form answers verbatim. Merge duplicates — the same email, or the same
   person arriving by form and by email.
2. **Check existing relationships.** Look up the email and domain in the
   CRM. An existing customer goes to the account owner as an expansion or
   support lead; an open deal goes to the deal owner; a past loss keeps its
   loss reason attached. Existing ownership overrides general routing.
3. **Apply disqualifiers.** Students, job seekers, vendors selling to us,
   competitors and spam. A free-mail address with no company is flagged,
   not rejected, when the message shows real intent. Record every reason.
4. **Research lightly.** For each remaining lead, check the company website
   and one other public source: industry, size range, location and what the
   company does. At most five minutes per lead; mark unverified fields.
5. **Score.** Fit from 0 to 60 against the checklist — weight each
   criterion, and give zero for an unknown while listing it as a question.
   Intent from 0 to 40 from behavior: demo or pricing request 40, "talk to
   sales" or a detailed problem description 30, trial sign-up 25, event or
   webinar 15, content download 10. Map framework evidence (for BANT:
   budget, authority, need, timing) as Yes, Partial, No or Unknown.
6. **Tier and set response times.** Hot is 75 or more (respond within one
   business hour), Warm 50–74 (same business day), Nurture below 50
   (marketing follow-up), Disqualified with its reason. Move a lead up one
   tier for a strategic account or a senior title, and say you did.
7. **Route.** Apply the routing rules in order. When none match, use the
   default queue the rules name, or "unassigned — needs owner". Flag
   conflicts, such as a lead that matches both a size rule and a region
   rule with different owners.
8. **Next actions and replies.** For every Hot and Warm lead: the next
   action (call, email, book a demo, send pricing, ask a specific question)
   and a draft reply that answers their question, references what they
   wrote and proposes two times. For Nurture, the content or sequence to
   use. For Disqualified, an optional polite decline.

## Deliverables

- **Primary:** `inbound-leads-<date>.xlsx` with sheets:
  - *Leads* — lead fields, CRM status, fit score, intent score, total, tier,
    framework evidence, unknowns to ask, owner, next action, deadline and
    draft reply;
  - *Rules* — the criteria checklist, scoring weights and routing rules as
    applied.
  If openpyxl is unavailable, deliver the Leads sheet as CSV.
- **Final:** `inbound-summary-<date>.md` — counts per tier and owner, Hot
  leads first with their draft replies, then routing conflicts.
- When Agent Mail is enabled, you may also create reviewable drafts for Hot
  leads with `create_mail_drafts`, one delivery per lead. Never send.
- Present it:

  ```sh
  zen output present --type file --title "Inbound leads — <date>" \
    --summary "<N leads: H hot, W warm; owners assigned>" \
    --primary inbound-leads-<date>.xlsx="Qualified leads" \
    --final inbound-summary-<date>.md="Summary and draft replies"
  ```

## Quality bar

- Every score shows its evidence and its unknowns; budget or authority is
  never assumed without a source.
- Existing customers and open deals are never routed as new leads.
- Draft replies respond to what the lead actually wrote; "thanks for your
  interest" is never the whole reply.
- Read-only everywhere: no replies, record updates or reassignments.
- Lead data stays inside the deliverables and is not pasted into outside
  tools.

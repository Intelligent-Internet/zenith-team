# Software adoption analysis

You are estimating how widely a piece of software is used, by whom, and
which way adoption is moving. No single public number answers this: vendor
customer counts are marketing, download counts are inflated by automation,
surveys over-represent enthusiasts. The craft is triangulation — several
independent, imperfect signals, each with its bias named, converging on a
range the reader can defend. A strong analysis is honest about its
uncertainty and still commits to a best estimate.

## Inputs

- The subject and its type, alternatives, market, purpose, breakdowns and
  trend window. When no alternatives are given, pick the three to five
  most common ones and say which.
- The reader's own data. Treat it as one more signal, with its own bias
  (their customer base is not the market).
- A GitHub Connector helps with repository and dependency data; a scraping
  Connector (Firecrawl) helps with review sites and customer pages;
  LinkedIn helps with job and company signals. Stop only if the subject
  cannot be identified at all.

## Procedure

1. **Define the unit and the population.** Decide what "adopted" means
   here — paying organisations, active organisations, seats, developers,
   installs or production deployments — and the population it is a share
   of (for example, US companies with 100 to 999 employees). For a
   category, write the membership rule. Every number later must be in
   these units or converted to them.
2. **Collect at least four independent signal families:**
   - **Vendor disclosures** — customer counts, large-customer counts,
     revenue and retention from filings (SEC EDGAR 10-K, S-1, earnings
     materials) and press releases. Note definition changes over time.
   - **Developer and industry surveys** — for example the Stack Overflow
     Developer Survey, JetBrains Developer Ecosystem, CNCF surveys.
     Record sample size and who answers.
   - **Package and artifact registries** — npm, PyPI, crates.io, Maven,
     container registries, marketplace install counts. Downloads are
     inflated by CI and mirrors; use them for trend and relative share,
     not absolute users.
   - **Repository signals** — dependents ("used by"), contributors,
     commit and issue activity. Stars measure attention, not use.
   - **Job postings** — the share of relevant postings that name the tool
     versus alternatives, sampled consistently over time.
   - **Technology detection** — web-facing tools only (analytics, CMS,
     commerce, tags); note the blind spot for back-end software.
   - **Review sites and marketplaces** — review counts and reviewer
     company-size and industry splits (self-selected, vendor-solicited).
   - **Customer evidence** — named customers, case studies, logos.
   - **Search interest** — relative only; always plot against the
     alternatives.
   Record every data point with source, metric, value, unit, date, link
   and caveat.
3. **Normalise.** Convert to the chosen unit, align dates, and prefer
   ratios versus alternatives over raw counts where absolute levels are
   unreliable.
4. **Triangulate the level.** Build two to four independent estimates,
   each with its formula written out, such as survey share × size of the
   relevant population, or vendor customer count × the market's share of
   the vendor's business. Take low, base and high cases; explain which
   estimate you trust most and why. When estimates disagree by more than
   a factor of two, say what would explain the gap.
5. **Profile who adopts** along the requested breakdowns, using customer
   evidence, reviewer profiles, job-posting employers and detection data.
   Give three to five named example adopters per major segment.
6. **Read the trend.** Chart or tabulate each signal over the window.
   State the direction per signal and whether they agree. Tie inflection
   points to events — pricing or licence changes, major releases,
   acquisitions, a competitor's launch.
7. **Explain drivers and barriers**: the jobs it is adopted for, switching
   costs, pricing, ecosystem and integrations, skills availability, and
   where it is losing ground. Place it on the adoption curve (early,
   growing mainstream, mature, declining).
8. **Answer the purpose.** Adopt: maturity, talent pool, lock-in and
   vendor-risk signals. Go-to-market: reachable adopter count by segment.
   Integration: overlap with the reader's customers. Investment: share,
   momentum and durability, as research input only; never a buy, sell or
   valuation recommendation.

## Deliverables

- **Primary:** `adoption-analysis.md` titled "Software adoption —
  <subject>", with: bottom line (level as a range, trend direction,
  confidence); definitions; adoption estimate with the triangulation
  table; who adopts; trend; versus alternatives; drivers and barriers;
  implications for the stated purpose; caveats and gaps.
- **Final:** `adoption-data.xlsx` with sheets Signals (source, metric,
  value, unit, date, link, caveat), Estimates (low, base and high with
  live formulas from the Signals sheet), Trend (time series per signal),
  Segments, and Sources. If openpyxl is unavailable, deliver the same
  sheets as CSV files.
- Present them:

  ```sh
  zen output present --type text --title "Software adoption — <subject>" \
    --summary "<adoption range, trend and confidence in one sentence>" \
    --primary adoption-analysis.md="Adoption analysis" \
    --final adoption-data.xlsx="Adoption data"
  ```

## Quality bar

- Every figure has a source link, a date and a unit; estimates are
  labelled as estimates and show their arithmetic.
- The headline level is a range, never a single unexplained number.
- Each signal's bias is stated where it is used, not only in a footnote.
- Trends are relative to alternatives wherever the signal allows.
- Never present stars, downloads or search interest as a count of users.
- Collect only what a normal visitor can see: respect robots rules and
  site terms (many review sites forbid scraping), never log in or bypass
  limits, and keep individual reviewers' names and profiles out of the
  data.

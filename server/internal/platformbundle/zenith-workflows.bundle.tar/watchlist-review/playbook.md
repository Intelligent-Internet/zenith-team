# Watchlist review

You are sweeping a list of companies for everything that happened since a
given date and deciding what deserves the reader's attention. The reader is
an investor or analyst with limited time: they want the three things that
change a thesis at the top, and confidence that nothing material was missed
lower down. Good work checks primary disclosures first, dates every item,
scores materiality consistently and says "nothing material" when that is the
answer. This is research support, not investment advice.

## Inputs

- The watchlist (names or tickers, often with a note on why each is there),
  the start date, the reading lens, event types, inclusion threshold and
  thesis triggers — all in the brief.
- Resolve each entry to legal name, ticker, exchange and primary regulator
  before searching. If an entry is ambiguous (a ticker on two exchanges, a
  private company), pick the most likely match, record it, and continue.
  If an entry cannot be resolved at all, list it under "Not reviewed".
- The date is inclusive. If it is more than a year ago, keep going but warn
  that coverage becomes thinner and the list will be long.

## Procedure

1. **Pull primary disclosures per company**, since the date:
   - US: SEC EDGAR filings — 8-K (note the item numbers: 1.01 material
     agreements, 1.03 bankruptcy, 2.02 results, 2.05 and 2.06 restructuring
     and impairments, 4.01 auditor change, 4.02 non-reliance on prior
     financials, 5.02 executive or director changes, 8.01 other events),
     10-Q and 10-K, Form 4 insider trades, Schedule 13D and 13G stakes, and
     proxy filings.
   - Elsewhere: the local equivalent (for example regulatory news
     announcements in the UK, SEDAR+ in Canada, exchange announcement
     pages in Europe and Asia).
   - The company's investor relations news page.
2. **Add secondary coverage.** Reputable financial and trade press for
   events not yet in a filing: product launches, contract wins or losses,
   investigations, strikes, outages, lawsuits, credit rating actions and
   analyst changes when asked for. Prefer the original report over
   aggregators, and do not rely on paywalled text you cannot read.
3. **Quantify the market's reaction** when a price source is available:
   share price change since the date and on each event day, versus a broad
   index. A large move with no found cause is itself an item ("down 12%
   on 3 March, no disclosed catalyst found").
4. **Deduplicate and date.** One row per development, with the earliest
   public date and the best source. Merge a press release, its filing and
   its news coverage into one row.
5. **Score materiality** 1–5 on each of:
   - **Impact** on earnings, cash flow, balance sheet or strategy, read
     through the brief's lens (a credit investor weighs refinancing and
     covenants; a trader weighs catalysts and surprises).
   - **Certainty** — announced and binding versus rumoured.
   - **Thesis relevance** — does it touch the note beside the ticker or a
     stated trigger?
   Priority = Impact × Certainty × Relevance (1–125). Apply the brief's
   threshold: material ≥ 36, notable ≥ 12, or everything dated.
   Always escalate: non-reliance on prior financials, auditor resignation,
   going-concern language, bankruptcy filings, CEO or CFO departure, a
   hit trigger, and activist 13D filings.
6. **Check triggers explicitly.** For each thesis trigger, state Hit,
   Not hit or Cannot tell, with the evidence.
7. **Make a call per company**: Review now, Monitor, or No action, with
   one line of reasoning.

## Deliverables

- **Primary:** `watchlist-review.md` titled "Watchlist review — since
  <date>":
  1. Top developments across the list, ranked by priority (up to ten),
     each with company, date, one-line summary, why it matters, source.
  2. Trigger check table.
  3. Company cards in watchlist order: call, price change since the date,
     developments in date order, and "Nothing material found" when true.
  4. Not reviewed, with reasons; method and sources.
- **Supporting:** `watchlist-events.xlsx` (or `.csv`) with one row per
  development: date, company, ticker, type, headline, source URL, impact,
  certainty, relevance, priority, call.
- Present:

  ```sh
  zen output present --type text --title "Watchlist review — since <date>" \
    --summary "<number of companies, and the top development in one line>" \
    --primary watchlist-review.md="Watchlist review" \
    --supporting watchlist-events.xlsx="Event log"
  ```

## Quality bar

- Every item has a date and a working source link; filings are cited by
  form type and filing date.
- Nothing before the start date appears, except as context clearly marked.
- Scores follow the rubric above for every company, so rankings across
  companies are comparable.
- Rumours are labelled as such and never scored above 2 on certainty.
- No buy or sell recommendations; the calls are about attention, not
  trades.

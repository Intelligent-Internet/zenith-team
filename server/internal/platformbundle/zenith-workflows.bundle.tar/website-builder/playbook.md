# Website builder

You are planning, writing and building a small website or landing page
for a business or project, and handing it over as a web app the person
can preview immediately and deploy anywhere. A good small site does one
job: it tells the right visitor, within five seconds, what is offered and
for whom, and makes the one next step obvious. It is fast, readable on a
phone, accessible, honest (no invented proof) and built from source the
person can edit.

## Inputs

- Name, what to build, the offer and audience, the primary action,
  sections, brand notes, reference sites, facts and copy, and the
  technology choice.
- Brand assets and reference sites must be reachable from this computer.
  A Figma Connector can supply colours, type and layouts when the brief
  links a Figma file. If an asset cannot be fetched, continue with a
  neutral treatment and list what is missing.
- Unknown facts (prices, address, hours) become clearly marked
  placeholders like `[Price]`, never plausible-looking inventions.

## Procedure

1. **Plan the site.** Write `PLAN.md` with: the primary visitor and their
   main question, the primary action, the sitemap, and for each page the
   sections in order. A landing page usually needs: hero (headline that
   states the outcome, a supporting line, primary button), proof (only
   real logos, quotes or numbers from the brief), the problem, how it
   works in three steps, benefits or features, pricing or offer, FAQ,
   final call to action, footer with contact and legal links.
2. **Write the copy.** Specific and benefit-first, in the brand's tone.
   Headlines under about ten words; sentences short; every button says
   what happens ("Book a 20-minute call", not "Submit"). No lorem ipsum,
   no invented testimonials, client logos, awards or statistics.
3. **Set the visual direction.** Define design tokens as CSS custom
   properties: colour palette (primary, accent, neutrals, with text
   contrast of at least 4.5:1), a type scale (one or two families; system
   fonts or at most two web fonts with `font-display: swap`), a spacing
   scale and a max content width around 1100–1200 px. Borrow structure,
   not assets, from reference sites.
4. **Choose the stack.** For "let the Agent choose": plain HTML and CSS
   for a single page; Astro for a multi-page static site; Next.js only
   when the brief asks for it or dynamic features require it. Keep
   dependencies minimal and pin versions.
5. **Build.** Put the site in `site/` in the worktree.
   - Semantic HTML (`header`, `main`, `section`, `footer`), one `h1` per
     page, logical heading order, a skip link.
   - Mobile-first responsive layout with CSS grid or flexbox; test at
     375, 768 and 1280 px.
   - Accessibility: alt text on meaningful images, labelled form fields,
     visible focus styles, keyboard-reachable navigation, reduced-motion
     respected.
   - Performance: no heavy frameworks for static pages, images sized and
     compressed, `loading="lazy"` below the fold, SVG for icons.
   - SEO basics: unique `<title>` and meta description per page, Open
     Graph tags, a favicon, `robots.txt`, `sitemap.xml`, and
     Organization or LocalBusiness structured data when facts allow.
   - Forms: there is no backend. Wire the primary action to what the
     brief provides (a booking link, a `mailto:` address, an app-store
     link); otherwise point the form at a clearly commented placeholder
     endpoint and explain the options in the README.
   - Images: there is no image-generation model on this computer. Use
     the person's assets, or build visuals with SVG, CSS gradients and
     shapes, or render simple graphics with HTML and a headless browser
     or Pillow. Use stock photos only with a clear licence and record it.
6. **Verify.** Run the site locally. With Playwright or another headless
   browser, capture screenshots at the three widths and review them for
   overflow, overlap and contrast; check the console for errors; check
   that every internal link resolves. Run Lighthouse when available and
   fix anything below 90 in accessibility or best practices. Stop any
   server you started for these checks before presenting.
7. **Document and commit.** `site/README.md` covers how to run it, where
   to change copy and colours, the placeholders to replace, and deploy
   steps for Netlify, Vercel, Cloudflare Pages and GitHub Pages. Commit
   the work in the worktree.

## Deliverables

- **Primary:** the runnable site in `site/`, presented as an app. For a
  plain HTML site:

  ```sh
  zen output present --type app --title "<site name> website" \
    --summary "<type> for <site name>, focused on <primary action>" \
    --app-command '{"command":"python3","args":["-m","http.server","4173"],"workingDirectory":"site","port":4173}'
  ```

  For Astro use
  `{"command":"npm","args":["run","dev","--","--port","4321","--host"],"workingDirectory":"site","port":4321}`
  and for Next.js
  `{"command":"npm","args":["run","dev","--","-p","3000"],"workingDirectory":"site","port":3000}`,
  after `npm install` has completed. Do not start the server yourself.
- `PLAN.md` and `site/README.md` live in the repository; mention the
  placeholders to fill in the final summary.

## Quality bar

- The primary action is visible without scrolling on a phone and repeated
  at the end of the page.
- No invented testimonials, logos, statistics or prices; placeholders are
  bracketed and listed.
- Passes a keyboard-only walkthrough and has no console errors.
- Every page has a title and meta description; images have alt text.
- The site builds and runs from a clean checkout using only the README.

# Loan structuring

You are designing the terms of one business loan so that it fits the
borrower's cash flow, the purpose of the money and the collateral behind it.
The reader is the borrower preparing to negotiate, a lender preparing an
offer, or an adviser. Good means every term has a reason, the repayment
profile matches how the business generates cash, covenants leave real
headroom, and the stress tests show exactly when the structure would
break. This is decision support, not lending, legal or tax advice; final
terms depend on the lender's credit process and loan documents.

## Inputs

- Borrower, role, purpose, requested amount, financials, collateral, rate
  type, amortization preference and constraints are in the brief.
- You need at least one full year of financials and a current balance
  sheet (pasted, linked or through the Xero Connector). Without them,
  stop and report what is needed.
- Blank amount: size it in step 2. Amount above capacity: structure the
  largest prudent loan and show the gap and how to close it.

## Procedure

1. **Match tenor to purpose.** Working capital: a revolving line reviewed
   annually, or a short term loan for a permanent working capital build.
   Equipment: no longer than the asset's useful life. Owner-occupied real
   estate: longer amortization with an earlier maturity. Acquisitions:
   repaid from the acquired cash flow over a medium term. For SBA 7(a),
   cite the current SOP's maximum maturities for the use of proceeds.
2. **Size the loan** as the lowest of: the request; coverage sizing
   (CFADS ÷ target DSCR, less existing debt service, converted to principal
   as the present value of the payments at the proposed rate and tenor);
   a leverage limit (debt ÷ EBITDA) for the lender type; and collateral
   value × advance rate. Cite advance rates and leverage bands or label
   them indicative. Show which constraint binds.
3. **Compare amortization profiles** on one sheet, period by period:
   - Level payment: `PMT(rate, n, −principal)`, rising principal share.
   - Straight-line: equal principal, interest on the declining balance.
   - Sculpted: principal = CFADS ÷ target DSCR − interest, so coverage is
     flat; useful for seasonal or ramping cash flows.
   - Balloon: amortize over a longer schedule and mature early; quantify
     the balloon and the refinancing risk.
   - Interest-only then amortizing: for construction or ramp periods;
     show the payment jump.
   For each: payment by year, minimum DSCR, total interest, balance at
   maturity. Recommend one and say why.
4. **Price it.** Floating: base rate (Term SOFR from CME, or the prime rate
   from the Federal Reserve H.15 release, dated) + spread for the risk, with
   any floor. Fixed: a comparable-maturity Treasury or swap rate + spread,
   labelled. Fees: origination, commitment or unused fees on lines,
   prepayment terms (step-down, yield maintenance on fixed loans), and the
   cost of an interest rate swap if hedging floating debt. Compute the
   all-in cost as the IRR of the borrower's net cash flows including fees.
5. **Set covenants** with headroom of 20–30% against the base case:
   financial (minimum DSCR or fixed charge coverage tested quarterly on a
   trailing twelve-month basis, maximum senior leverage, minimum liquidity,
   capex limits), reporting (monthly or quarterly statements, annual
   reviewed or audited statements, borrowing-base certificates for lines),
   negative covenants (additional debt, liens, distributions, change of
   control) and events of default with any cure rights.
6. **Collateral and support.** Lien position, specific assets, guarantees
   (personal or corporate, limited or unlimited), key-person insurance, and
   the collateral coverage ratio (lendable value ÷ loan).
7. **Stress test** the recommended structure: revenue down 15% and 25%,
   margin down three points, collections 15 days slower and, for floating
   rates, base rate up 200 and 300 basis points. Report covenant results by
   quarter, the first quarter any test fails, and the EBITDA decline that
   takes DSCR to 1.00x.
8. **Tailor to the role.** Borrower or adviser: list negotiation asks in
   priority order with fallbacks. Lender: a risk rating rationale and the
   conditions you would attach to approval.

## Deliverables

- **Primary:** `loan-structure-<borrower>.xlsx` with sheets Summary,
  Inputs, Sizing, Amortization options, Pricing and all-in cost, Covenant
  tests, Stress tests, Sources. Live formulas; inputs in blue.
- **Final:** `term-sheet-<borrower>.docx` (Markdown if python-docx is
  unavailable), marked "Indicative, non-binding": borrower, lender,
  facility, amount, purpose, tenor, amortization, rate, fees, prepayment,
  collateral, guarantees, covenants, reporting, conditions precedent.
- Present:

  ```sh
  zen output present --type file --title "Loan structure — <borrower>" \
    --summary "<recommended amount, tenor, amortization and rate in one sentence>" \
    --primary loan-structure-<borrower>.xlsx="Loan structure" \
    --final term-sheet-<borrower>.docx="Indicative term sheet"
  ```

  Without openpyxl, write each sheet as a CSV (`loan-sizing.csv`,
  `amortization-options.csv`, `covenant-tests.csv`, `stress-tests.csv`)
  plus the Python script that computes them, make the term sheet primary
  and pass the CSVs as `--supporting` items.

## Quality bar

- Every rate, spread, fee and advance rate is cited with a date or
  labelled as an assumption.
- Payment schedules sum exactly to principal; interest uses the stated day
  count and payment frequency.
- Covenant levels are shown next to base-case values and headroom.
- No term sheet language implies a commitment to lend.

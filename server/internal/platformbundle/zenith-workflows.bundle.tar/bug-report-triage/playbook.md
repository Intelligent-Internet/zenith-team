# Bug report triage

You are turning a pile of raw bug reports — support tickets, chat messages,
issue-tracker entries, app-store complaints — into a short, ranked list of
distinct problems that engineering can act on today. The reader is an
engineering lead or product manager running the triage meeting. Good triage
collapses duplicates, rates every issue against the same rubric, writes
reproduction steps an engineer can follow without asking, and is honest
about what is still unknown.

## Inputs

- Product, window, pasted reports or Connectors, the duplicate-search
  link, severity scale, ownership notes, recent releases and the
  reproduction mode — all in the brief.
- Read reports through GitHub, Linear, Jira or Zendesk Connectors when
  selected, or through `gh issue list` for GitHub. With no pasted reports
  and no working Connector, stop before triaging and report what is
  missing; never invent reports.
- This workflow is read-only on every system. Labels, assignments and
  replies are proposed in the deliverable, never applied.

## Procedure

1. **Normalize.** One row per report: source and link, reporter type
   (customer, internal, automated), received time, account or plan when
   known, platform, app version, browser or device, the user's words, any
   error text, logs or screenshots referenced.
2. **Cluster duplicates.** Group reports that share an error message, a
   stack frame, the same screen and action, or the same regression window.
   Then search the existing open issues (the tracker link or Connector)
   for each cluster using its error text and key nouns. A cluster matching
   an open issue becomes "additional occurrences of #123". Keep reports
   that look alike but differ in platform or version as separate if the
   evidence points to different causes, and note the possible link.
3. **Separate non-bugs.** Mark feature requests, how-to questions,
   expected behaviour and user configuration mistakes; route them to
   support or the feedback backlog with a one-line reason.
4. **Rate severity** on the brief's scale, mapping levels top to bottom:
   - Level 1: data loss or corruption, security or privacy exposure,
     payments failing, or the product unusable for many users.
   - Level 2: a core workflow broken with no reasonable workaround.
   - Level 3: broken with a workaround, or a narrow slice of users.
   - Level 4: cosmetic, copy, minor inconvenience.
   Then set **priority** separately: raise it for reach (number of
   reporters and accounts), revenue at stake, a regression in the latest
   release, or an SLA commitment; lower it when the workaround is trivial.
   Write the reason for both in one sentence.
5. **Write reproduction steps.** Numbered steps from a clean state,
   expected result, actual result, environment, frequency (always,
   intermittent, once). Where the reports disagree or skip a step, write
   the gap as a question for the reporter.
6. **Attempt reproduction** only when the brief asks and the repository is
   checked out: run the app or the relevant test locally, try the steps,
   and record "reproduced", "not reproduced (tried X)" or "not attempted
   (needs production data or credentials)". For a regression, use `git log`
   on the touched paths since the last release to name candidate commits.
   Never touch production systems or real customer accounts.
7. **Route.** Suggest the owning team from the ownership notes, then
   CODEOWNERS or recent history of the relevant paths. Mark "unclear" when
   the evidence is thin.
8. **Draft the follow-ups.** For each cluster missing information, write
   the reply to the reporter asking the specific questions (version,
   steps, screenshot, time of occurrence) — as text in the report, not
   sent.

## Deliverables

- **Primary:** `bug-triage.md` titled "Bug triage — <product>, <date>":
  headline counts (new reports, distinct issues, duplicates, non-bugs, and
  anything at level 1); a table of distinct issues sorted by severity then
  priority (ID, one-line summary, reporters, severity, priority, reason,
  repro status, suggested team, missing info); a section per level-1 and
  level-2 issue with full reproduction steps; duplicate groups; non-bugs;
  drafted reporter questions.
- **Final:** `bug-triage.csv` with one row per distinct issue and the
  same columns, ready to import into a tracker.
- Present:

  ```sh
  zen output present --type text --title "Bug triage — <product>" \
    --summary "<distinct issues, duplicates merged, and the top-severity items>" \
    --primary bug-triage.md="Triage report" \
    --final bug-triage.csv="Issues for import"
  ```

## Quality bar

- Every distinct issue links to all the reports it came from; counts in
  the headline match the table.
- Severity reasons cite the evidence ("3 customers, checkout fails on
  Safari 17"), never impressions.
- Reproduction steps are specific enough to follow without the reporter.
- Nothing is labelled, assigned, closed or replied to on any system.
- Personal data in reports (emails, phone numbers, addresses) is omitted
  or masked in the deliverable.

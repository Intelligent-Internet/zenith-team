# Content ideas

You are producing a ranked list of content ideas a marketing lead can
commission this week. The difference between a useful list and a
brainstorm is evidence: every idea here answers a question that real people
in this audience are asking now, in their own words, and the ranking shows
why one idea beats another. Fewer, well-evidenced ideas beat a long list of
generic topics.

## Inputs

- Topic, audience, goal, formats and the number of ideas come from the
  brief. Communities, competitors and already-covered topics are optional.
- The company's own data, when Connectors are available (all read-only):
  - Zendesk — recurring questions and complaints in recent tickets.
  - Gong — objections and questions from recent sales calls.
  - Firecrawl — reading forums and competitor blogs at scale.
  Without Connectors, rely on public signals and say so in the method.

## Procedure

1. **Collect signals — aim for 40 or more.** Search with the audience's
   vocabulary, not the company's. Good sources:
   - search suggestions and "people also ask" questions for the core
     problems;
   - Reddit, industry forums, Q&A sites and the communities named in the
     brief — threads from the last 6–12 months with real replies;
   - review sites and marketplaces: middling reviews of products in the
     category, where people describe what they wanted and did not get;
   - comments under popular videos and posts on the topic;
   - industry news, regulation changes and seasonal moments in the next
     90 days;
   - competitors and publications: what they cover, what is thin or out of
     date, which questions they leave unanswered.
   For each signal record the source, URL, date, the question or pain in
   the audience's words and how much engagement it had.
2. **Cluster.** Group signals by the underlying job or question, not by
   keyword. A cluster supported by several independent sources is demand;
   a single viral thread is a spike.
3. **Turn clusters into ideas.** For each: a specific working title; the
   angle that makes it different from what exists (new data, a firmer
   opinion, a template, a worked example, a comparison); the best format
   from the brief's list; the funnel stage; and the one question it
   answers. Drop anything already covered or off-limits.
4. **Score each idea from 1 to 5** on:
   - *Demand* — breadth and recency of the evidence;
   - *Fit* — how naturally it serves the goal and leads to the product;
   - *Gap* — how weak or dated the best existing answers are;
   - *Timeliness* — tied to something happening now or soon;
   - *Ease* — effort for the available formats (5 = easy).
   Total = 0.30 × Demand + 0.25 × Fit + 0.20 × Gap + 0.15 × Timeliness +
   0.10 × Ease. Rank by total and break ties on Demand.
5. **Brief the top five.** Hook, a four-to-seven section outline, the
   proof or examples to include, the call to action and two distribution
   ideas.
6. **Sanity check.** Remove near-duplicates, make sure the list spans
   funnel stages and formats, and confirm every top-ten idea rests on at
   least two independent signals.

## Deliverables

- **Primary:** `content-ideas.md`, titled "Content ideas — <topic>":
  1. Method: sources searched, date range, Connectors used.
  2. The ranked list: rank, working title, angle, format, funnel stage,
     score, and one or two evidence quotes with links.
  3. Briefs for the top five.
  4. Themes worth watching, and gaps in the research.
- **Final:** `content-ideas.xlsx` with an *Ideas* sheet (one row per idea,
  the five sub-scores and a live formula for the total) and a *Signals*
  sheet (every signal with source, URL, date, quote and cluster). Deliver
  two CSV files instead if openpyxl is unavailable.
- Present them:

  ```sh
  zen output present --type text --title "Content ideas — <topic>" \
    --summary "<number of ideas, the top idea and the strongest theme>" \
    --primary content-ideas.md="Ranked content ideas" \
    --final content-ideas.xlsx="Ideas and evidence"
  ```

## Quality bar

- No invented search volumes or trend figures. Without a keyword source
  that reports them, describe demand from the evidence, not with a number.
- Every idea links to real, dated evidence; quotes are verbatim.
- Quote public posts without usernames or personal details — the subject
  is the question, not the person who asked it.
- Titles are specific ("How to price a follow-up physio session"), never
  generic ("Pricing tips").
- Say where evidence is thin instead of inflating a score.
- Read public pages only, within each site's terms and robots rules;
  never log in to closed groups or communities to collect signals.

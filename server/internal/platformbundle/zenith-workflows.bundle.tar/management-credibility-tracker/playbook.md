# Management credibility tracker

You are building an evidence-based track record of one management team:
what they said they would do, when, and whether it happened. The reader is an
investor, analyst, board member or lender deciding how much weight to put on
the next set of promises. Good work is a ledger anyone can audit — every
promise quoted with its source, every outcome tied to a reported number — and
a verdict that separates bad luck from bad forecasting. This is research
support, not investment advice; say so once in the memo.

## Inputs

- The company, look-back window, commitment types and scoring standard from
  the brief. Resolve the company to its legal name, ticker, exchange and
  fiscal calendar first; if the name is ambiguous, pick the most liquid
  listing and record the choice.
- Optional commitments to check and material the person already holds. Treat
  pasted excerpts as primary evidence and cite them as "provided by the
  requester".
- Sources to gather yourself: earnings releases and filings (SEC EDGAR 8-K
  item 2.02 exhibits, 10-Q and 10-K MD&A, or the local regulator's filing
  system), investor-day decks, call transcripts or webcasts on the investor
  relations site, and shareholder letters. If no transcripts are freely
  available, use prepared remarks and releases and state that Q&A commitments
  may be missing. Never reconstruct a quote from memory.
- A Google Drive Connector can supply the person's own notes when available.

## Procedure

1. **Map the reporting calendar.** List every earnings date, investor day,
   guidance update and pre-announcement inside the window, with links. Note
   CEO and CFO tenure so each promise can be attributed to who made it.
2. **Build the promise ledger.** For each commitment of a tracked type
   record: ID, date made, venue, speaker, verbatim quote, category, metric,
   target (point or range), deadline or period, and a specificity grade:
   - **A** quantified and dated ("FY26 revenue of $4.1–4.3B")
   - **B** quantified, undated, or dated but directional ("margin
     expansion next year")
   - **C** aspirational ("best-in-class returns over time")
   Include commitments older than the window when they fall due inside it.
3. **Trace every revision.** Build a guidance walk per metric: initial
   guide, each reaffirmation, raise, cut or withdrawal, with dates. Flag late
   cuts (made in the final month of the period or at the results date) and
   pre-announcements.
4. **Match outcomes.** Pull the reported actual for each promise from the
   release or filing. Check comparability before scoring: GAAP versus
   non-GAAP, constant currency, acquisitions or disposals, restated periods,
   and changed KPI definitions. Record the adjustment you made.
5. **Score each promise** using the brief's standard for guidance:
   - Delivered, Delivered late, Partially delivered, Missed, Withdrawn
     (openly), Quietly dropped (never mentioned again or the KPI stopped
     being disclosed), Pending (deadline not yet reached).
   - Guidance variance = (actual − original midpoint) ÷ |original midpoint|.
   - Timeline slippage in months for dated milestones.
6. **Compute the scorecard.** Hit rate on resolved A and B promises;
   average and median variance to midpoint; directional bias (a run of large
   beats signals sandbagged guidance, which is reliable but uninformative);
   share of promises revised; count of redefined or dropped metrics; average
   slippage. Weight by materiality: a missed margin or leverage target counts
   more than a slipped product date.
7. **Separate cause from excuse.** For each miss, record management's stated
   reason, then test it: did peers face the same shock, did the miss persist
   after it faded, was the risk flagged when the promise was made?
8. **Grade and look ahead.** Give an overall grade (A to D) with a
   two-sentence rationale, a grade per executive if leadership changed, and
   list open commitments due in the next four quarters with the evidence that
   would confirm or break each one.

## Deliverables

- **Primary:** `credibility-tracker.xlsx` with sheets:
  1. `Summary` — grade, rationale, hit rate and bias metrics as formulas
     over the ledger.
  2. `Ledger` — one row per promise with the fields from step 2, outcome,
     variance, status and source links.
  3. `Guidance walk` — one block per metric, initial guide through actual.
  4. `Open items` — pending commitments and their due dates.
  5. `Sources` — every document with date and URL.
- **Final:** `credibility-memo.md`: verdict, three to five defining
  episodes with quotes, pattern analysis, open commitments and caveats.
- Present both:

  ```sh
  zen output present --type file --title "Management credibility — <company>" \
    --summary "<grade and hit rate in one sentence>" \
    --primary credibility-tracker.xlsx="Credibility tracker" \
    --final credibility-memo.md="Credibility memo"
  ```

  Without openpyxl, deliver the ledger as `credibility-ledger.csv` and make
  the memo primary with `--type text`.

## Quality bar

- Every ledger row carries a verbatim quote, a date and a working link or
  document reference. No quote, no row.
- Never mark a promise missed before its deadline; mark it Pending.
- Scores use the original promise, not the last revised version, and the
  memo says so. Show the revised-guidance hit rate alongside it.
- Keep GAAP and non-GAAP comparisons like-for-like and label units, currency
  and fiscal periods on every figure.
- Distinguish fact from judgment: the ledger is fact; the grade and the
  cause analysis are your judgment and are labelled as such.

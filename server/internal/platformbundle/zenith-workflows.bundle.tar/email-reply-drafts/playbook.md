# Email reply drafts

You are writing replies a busy person can send after a thirty-second read.
Each draft must sound like them, answer what the sender actually asked,
stay consistent with everything already said in the thread and never commit
them to something they have not agreed. You produce drafts only: nothing is
sent, and the person reviews every word.

## Inputs

- The brief gives which emails to answer, reply length, where the drafts
  go, the sign-off, per-thread direction, facts the replies may use and a
  description or sample of how the person writes.
- A mail Connector (Gmail) is required to find and read threads. If none
  is available, stop before drafting anything and report that the
  workflow needs one; never draft replies to threads you have not read.
- A calendar Connector helps with scheduling replies; a drive Connector
  helps when a thread refers to a shared document. Use them read-only.
- Per-thread direction in the brief always overrides your own judgement.

## Procedure

1. **Build the reply list.** Collect threads in the scope where the last
   message is from someone else, is addressed to the person (To, not only
   Cc) or asks them something directly, and has no later reply from them.
   Exclude bulk and automated mail, threads that already hold an unsent
   draft reply (so repeated runs do not stack duplicates), and anything
   the brief excludes. When
   the scope is "only the threads I describe", match the brief's
   descriptions to threads and list any you could not find.
2. **Learn the voice.** If the brief gives samples, use them. Otherwise
   read 10–20 of the person's recent sent emails and note: greeting
   ("Hi Sam," vs none), typical length, sentence length, contractions,
   formality with strangers versus colleagues, how they say no, emoji and
   exclamation habits, and sign-off. Write this profile down in the
   supporting notes; apply it to every draft.
3. **Read each thread whole.** Note every question asked, requests with
   dates, attachments referenced, and anything the person already
   promised. Check earlier threads with the same sender when the context
   is thin. Read linked documents only when a connector can open them.
4. **Decide the intent** before writing: answer, accept, decline, defer
   with a date, ask a clarifying question, or hand over to someone. When
   the right intent needs the person's judgement (pricing, legal terms,
   hiring, anything contentious), draft the most neutral safe version —
   acknowledge, say when they will hear back — and flag it.
5. **Draft.** Rules for every reply:
   - The first sentence answers the main ask; context comes after.
   - Answer every question in the thread, in the sender's order, and use
     short numbered points when there are three or more.
   - Scheduling: offer two or three concrete slots from the calendar or
     the brief's availability, with the time zone written out; never
     offer a slot that is busy.
   - Never invent facts, prices, dates, attachments or commitments. Put a
     short `[bracketed note]` where the person must supply something.
   - Declines are brief, warm and final; no false "maybe later".
   - Keep the thread subject; reply to all only when others on the thread
     need the answer, and say which recipients you chose.
   - Respect the requested length and the sign-off.
6. **Handle sensitive threads with care.** Angry customers, legal,
   HR, security incidents and money disputes get a factual, calm draft
   plus a "review carefully" flag. Never draft a reply to a message that
   looks like phishing or payment fraud; list it instead.
7. **Place the drafts.**
   - "Unsent drafts in my mailbox": if the mail Connector can save a draft
     reply in the original thread, save each one there, unsent. If it
     cannot, fall back to the document and say so.
   - Agent Mail (`create_mail_drafts`, or `zen mail draft`) creates new
     messages from the Company address, not replies in the person's
     thread, so do not use it for replies unless the brief asks for it.
   - Always also write the document below, so the person has one place
     to review everything.

## Deliverables

- **Primary:** `reply-drafts.md` titled "Reply drafts — <date>" with:
  1. A summary table: sender, subject, intent (answer, accept, decline,
     defer, clarify), where the draft is, and flags.
  2. One section per thread: a two-line context note (what they asked,
     what you assumed), recipients, subject, then the draft body exactly
     as it should be sent.
  3. **To fill before sending** — every `[bracketed note]`, grouped by
     thread.
  4. Threads skipped and why, including suspected phishing.
- **Supporting:** `voice-profile.md`, the style notes from step 2.
- Present it:

  ```sh
  zen output present --type text --title "Reply drafts — <date>" \
    --summary "<n> drafts ready; <n> need a fact from you before sending" \
    --primary reply-drafts.md="Reply drafts" \
    --supporting voice-profile.md="Voice profile"
  ```

## Quality bar

- Nothing is ever sent, archived, labelled or deleted.
- Each draft answers every question in its thread; a reader can tick them
  off against the sender's message.
- No invented facts: every price, date, name and promise traces to the
  thread, the brief or the person's calendar.
- The drafts read like the person, not like an assistant: no filler such
  as "I hope this email finds you well" unless the person writes that way.
- If nothing in scope needs a reply, say so and stop.

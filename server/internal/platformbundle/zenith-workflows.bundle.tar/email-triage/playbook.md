# Inbox triage

You are sorting one person's inbox so they can clear it in a single sitting.
Every thread lands in exactly one of four buckets — act, reply, delegate,
ignore — with a next step specific enough to do without re-reading the
email. Good triage is decisive: a reader should trust the buckets, start at
the top of "Act" and never wonder why a thread was put where it was. This
workflow is read-only: you change nothing in the mailbox.

## Inputs

- The brief gives the scope (which messages), a thread cap, the person's
  role, the people they can delegate to, senders to rank high and what
  counts as ignore.
- A mail Connector (Gmail) is required. If none is available in this Run,
  stop before triaging and report that triage needs one; never triage from
  memory or invent messages.
- A calendar Connector is optional. Use it to spot emails that affect a
  meeting today or tomorrow.
- If the role is blank, infer it from the signature and sent mail and state
  the inference in the report. If the delegate list is blank, do not invent
  delegates: leave the bucket empty and say why.

## Procedure

1. **Collect threads.** Pull messages matching the scope, newest first, and
   group them by thread. Stop at the cap; if more threads matched, say how
   many were left out and the date range you covered. For each thread note:
   who sent the last message, whether the person is in To or only in Cc,
   whether the person has already replied, attachments (invoices,
   contracts, decks) and any stated date.
2. **Drop the already-handled.** A thread whose last message is the
   person's own, with nothing new since, is not in the inbox's debt. Count
   these separately as "already answered" rather than bucketing them.
3. **Classify** each remaining thread with these rules, in order:
   - **Ignore** — automated or bulk mail (unsubscribe footer, no-reply
     sender, notifications, receipts, newsletters), cold pitches, and
     threads where the person is only copied and nothing is asked of them.
     Apply the person's ignore rules first, but pull out anything about
     failed payments, security alerts, legal notices or account suspension
     and bucket it on its merits.
   - **Act** — the essential next step is a non-writing action: approve,
     pay, sign, review a document, decide, book, fix, attend. A thread that
     needs both an action and a short reply goes here, with the reply
     mentioned in the next step.
   - **Delegate** — a listed delegate owns this kind of work and can finish
     it without the person's judgement. Never delegate anything touching
     investors, board members, legal exposure, hiring decisions, or a
     sender the person ranks high unless the brief says so.
   - **Reply** — everything else that asks the person a question or waits
     on their answer.
4. **Write the next step.** One imperative sentence that starts with a
   verb and names the object: "Approve the Q4 vendor invoice ($4,200) in
   the portal", not "Look into this". For delegate items add the hand-off
   line the person could forward: "Priya — can you pay this by Friday and
   confirm to the sender?". For replies give the gist of the answer when
   it is obvious, or the one question the person must settle first.
5. **Rank inside each bucket** by consequence of delay: stated deadlines,
   money and legal first; customers and high-ranked senders next; then age
   of the oldest unanswered message. Mark anything with a deadline in the
   next 48 hours as **Today** or **Tomorrow**.
6. **Cross-check the calendar** when available: flag threads tied to a
   meeting in the next two working days (agenda requests, reschedules,
   documents to read before the meeting).
7. **Screen for risk.** Flag possible phishing or fraud (unexpected payment
   detail changes, credential requests, lookalike domains). Do not open
   links or attachments from such messages; describe the signal instead.
8. **Pick the top three.** Across all buckets, choose the three threads the
   person should handle first and say why in a few words each.

## Deliverables

- **Primary:** a Markdown report `inbox-triage.md` titled
  "Inbox triage — <date>" with:
  1. **Summary** — counts per bucket, already-answered count, threads left
     out by the cap, and the top three.
  2. **Act**, **Reply** and **Delegate** — tables with columns: sender,
     subject, what is needed, deadline, next step (plus delegate and
     hand-off line in the delegate table).
  3. **Ignore** — counts by type (newsletters, notifications, receipts,
     pitches, copied-only) and a short list of unsubscribe candidates the
     person rarely opens.
  4. **Flags** — suspicious messages and any assumptions you made.
- Present it:

  ```sh
  zen output present --type text --title "Inbox triage — <date>" \
    --summary "<n> to act, <n> to reply, <n> to delegate; top item: <one line>" \
    --primary inbox-triage.md="Inbox triage"
  ```

## Quality bar

- Read-only. Never send, draft, archive, label, move, mark read or delete.
- Every thread appears in exactly one bucket; the counts add up to the
  number of threads triaged.
- Never invent a deadline, amount or name. Quote the sender's own words
  when the ask is short.
- No next step is vaguer than a verb plus a specific object.
- Keep message content inside the report; do not paste private mail into
  web tools or anywhere outside the Task.
- If the scope holds nothing, say "Nothing needs you" and stop.

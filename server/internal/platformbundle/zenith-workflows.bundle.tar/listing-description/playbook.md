# Listing description

You are writing the marketing copy for one property listing. The reader is
an agent, landlord or property manager who will paste it into listing
portals, the MLS, social posts and emails. Good listing copy leads with the
property's real differentiator, walks the reader through the home in a
natural order, gives the practical facts buyers and renters filter on, and
is scrupulously accurate: in real estate, overstated square footage or an
invented view is a complaint or a lawsuit, and describing *people* instead
of the *property* can breach fair housing law.

## Inputs

- Address, listing type, facts, standout features, positioning, versions,
  character limits, tone and market conventions — all in the brief.
- If no versions are chosen, write headline options, the full description
  and the short card.
- If the facts omit essentials (bedrooms, bathrooms, size, price or rent,
  availability), write the copy with clear `[confirm: …]` placeholders
  rather than guessing, and list them.
- You may check public facts — distances to named places with a mapping
  service, the name of the neighborhood, transit lines — and must mark
  them as approximate. Do not copy text from other listings or portals.

## Procedure

1. **Build the fact sheet.** Tabulate every fact with its source (owner,
   appraisal, public record, measured by agent, your map check). Check
   consistency: room counts, area units, price per area, lot size, year
   built against "new" claims, HOA or service charges, parking. Note
   conflicts for the person to resolve.
2. **Pick the lead.** Choose the one or two verified features that most
   distinguish this home from its competition at this price (light,
   outdoor space, renovation, layout, location convenience). The
   positioning shapes emphasis: a renovation opportunity leads with
   potential and lot or structure, an income property leads with rent,
   units and condition.
3. **Draft the full description** in this order: hook sentence with the
   lead feature; arrival and main living space; kitchen; bedrooms and
   bathrooms; outdoor space and storage; recent upgrades with years;
   location facts stated as distances or times to named places; practical
   details (fees, parking, utilities or inclusions, availability); a
   simple call to arrange a viewing.
4. **Cut the other versions from it**, not from scratch: standard, short
   card or MLS remarks, social caption (two or three lines, one call to
   action, at most three relevant hashtags), feature bullets (6–10, each
   under 12 words) and an email (subject line plus 80–120 words) as
   requested. Write three headline options under 60 characters unless the
   brief sets another limit.
5. **Measure.** Count characters and words with a script (`len(text)`)
   for every version and fit the brief's limits exactly; show the counts.
6. **Run the fair housing check.** Describe the property and its features,
   never the ideal occupant. Replace or remove phrases that indicate a
   preference based on race, colour, religion, sex, disability, familial
   status or national origin (US Fair Housing Act), and on further
   classes where the market adds them (for example source of income,
   age, sexual orientation, marital status). Typical rewrites: "perfect
   for young professionals" → "open-plan layout near the station";
   "family-friendly street" → "quiet cul-de-sac"; "walk to St. Mary's" is
   fine as a landmark, "Christian neighborhood" is not; "handicap
   accessible" → list the actual features (step-free entry, 36-inch
   doors); "safe area" → remove; "no Section 8" or "no vouchers" →
   remove. For rentals, never state tenant restrictions the law forbids.
7. **Run the accuracy check.** Every superlative and every factual claim
   maps to the fact sheet; areas carry their source ("approx.", "per
   appraisal"); "newly renovated" carries a year; views, school
   assignments and zoning potential are stated only when verified.
   Remove filler clichés ("nestled", "boasts", "won't last") and all-caps
   or stacked exclamation marks.

## Deliverables

- **Primary:** `listing-<short-address>.md` titled "Listing copy —
  <address>", with each requested version under its own heading and its
  character and word counts, the headline options, a "facts to confirm"
  list, and a compliance table (original phrase or claim, issue, rewrite).
- Present:

  ```sh
  zen output present --type text --title "Listing copy — <address>" \
    --summary "<versions written and any facts still to confirm>" \
    --primary listing-<short-address>.md="Listing copy"
  ```

## Quality bar

- Nothing in the copy that is not on the fact sheet or clearly marked as
  approximate.
- No language describing who should live there; features, not people.
- Every version fits its stated limit, verified by count.
- Varied, concrete sentences; each version reads well on its own.
- The copy is original and never reuses other listings' text.

# Property comparison

You are putting several candidate properties on one page so a buyer or
investor can choose with numbers rather than impressions. The reader has a
goal (a home, a rental, a commercial holding) and a few priorities. Good
work normalizes every property to the same units and assumptions, estimates
rent and costs from evidence rather than listing optimism, cites every
neighborhood fact, and ends with a ranked recommendation whose weights are
visible and whose trade-offs are stated plainly. This is decision support,
not an appraisal or investment advice.

## Inputs

- Properties, goal, priorities, financing, places that matter, currency
  and units, and known facts — all in the brief.
- Open each listing link if the site allows automated reading; respect
  its terms and do not bypass blocks. Fill gaps from public records
  (assessor or land registry, tax records, planning portals) and the
  person's notes. Mark every field's source.
- If fewer than two properties can be identified, stop and report.

## Procedure

1. **Profile each property.** Asking price, type, tenure (and lease years
   remaining where leasehold), living area and its basis, lot size, beds,
   baths, year built, parking, condition and known repairs, HOA or
   service charge, annual property tax, days on market and price history.
2. **Normalize.** Price per square foot or metre on the same area basis.
   Convert currency and units as the brief specifies. Flag listings whose
   area figure looks inconsistent with room counts.
3. **Estimate market rent** (for investment goals, and as context for a
   home): three to five comparable rental listings or recent lets near
   each property with similar size and beds, plus an official benchmark
   where one exists (for example HUD Fair Market Rents in the US or
   national statistics office rent indices). Give a low, mid and high
   monthly rent, and use the mid unless there is an actual lease.
4. **Estimate annual operating costs:** property tax, insurance (quote or
   regional average, labelled), HOA or service charge, maintenance (about
   1% of value a year, more for older homes), management (8–12% of rent
   long-term; 20–30% short-term), vacancy (5–8% long-term; model occupancy
   explicitly for short-term), utilities the owner pays, and known
   repairs spread as an upfront cost.
5. **Compute the returns** in live formulas:
   - Gross yield = annual rent ÷ price.
   - Net operating income = rent − vacancy − operating costs.
   - Cap rate (net yield) = NOI ÷ price.
   - With financing: loan payment with the PMT formula, monthly cash flow,
     cash-on-cash return = annual cash flow ÷ (down payment + closing
     costs + upfront repairs), and debt service coverage.
   - For a home: total monthly cost of ownership (mortgage, tax,
     insurance, HOA, maintenance) and the equivalent rent comparison.
6. **Compare neighborhoods** with dated, cited facts: recent sale prices
   per area nearby (last 6–12 months) and the trend; time on market;
   travel times to the brief's places at the stated time using a routing
   service; transit access; official flood zone and other hazard maps;
   official crime statistics at the same geography for all properties;
   school ratings from official sources when relevant to the goal. Report
   facts, not characterizations of residents.
7. **Score and rank.** Score each property 0–10 per chosen priority using
   a stated rule (for example, best value 10, others scaled linearly),
   weight priorities equally unless the brief ranks them, and compute a
   weighted total. Test whether the winner changes if any single weight
   doubles; report it if so.
8. **Write the recommendation**: the best fit for the goal, the runner-up
   and what would make it the better choice, deal-breakers found, and the
   next checks before an offer (inspection, survey, lease review).

## Deliverables

- **Primary:** `property-comparison.xlsx` with sheets `Inputs` (all
  assumptions, editable), `Comparison` (one column per property, formulas
  only), `Rent comps`, `Returns`, `Scores` (weights editable),
  `Neighborhood`, `Sources` (link and access date per fact).
- **Final:** `property-comparison.md`: the recommendation, the comparison
  table, trade-offs, risks and next checks.
- Present:

  ```sh
  zen output present --type file --title "Property comparison" \
    --summary "<the top-ranked property for the goal and the main trade-off>" \
    --primary property-comparison.xlsx="Comparison workbook" \
    --final property-comparison.md="Recommendation"
  ```

  Without openpyxl, deliver CSV tables and make the Markdown primary with
  `--type text`.

## Quality bar

- Same assumptions and area basis for every property; differences are
  explained.
- Every rent, cost and neighborhood figure has a source and date, or is
  labelled an estimate with its method.
- Formulas, not typed results; the scores change when weights change.
- No language about who lives in a neighborhood; facts about the place.
- The recommendation states the uncertainty and what to verify next.

# Invoice data extraction

You are turning a pile of supplier invoices (email bodies, PDFs, scans,
photos) into structured data a bookkeeper can review in minutes and import
into the books. The value is accuracy, not speed: one wrong total or a
missed duplicate costs more than the time saved. Good means every invoice
captured once, every field traceable to its source, arithmetic checked,
and anything uncertain left blank and flagged instead of guessed.

## Inputs

- Source, where to look, period, level of detail, extra fields, home
  currency, output format and expense categories are in the brief.
- **Mail Connector:** search the period for invoices and bills, for
  example `has:attachment (invoice OR bill OR "amount due") after:2026/08/01
  before:2026/09/01` in Gmail syntax, plus any senders the brief names.
  Read-only: never label, archive, reply to or delete messages.
- **Folder or links:** download every file the links reach. If a link will
  not open, list it as unreadable and continue with the rest.
- **Pasted text:** treat each block as one document.
- Nothing readable at all — no mail or Google Drive Connector connected
  and no invoices or links in the brief, or nothing that opens: stop
  before building the spreadsheet and report what is missing or could not
  be opened.

## Procedure

1. **Collect and classify.** Gather each candidate document with its
   origin (message date, sender and subject, or file path). Classify it:
   invoice, credit note (negative amounts), receipt (already paid),
   statement (a summary, not a new bill: skip), quote or pro forma (not a
   bill: skip). Only invoices, credit notes and receipts go into the data.
2. **Extract text.** Digital PDFs: `pdfplumber` or `pdftotext -layout`.
   Scans and photos: OCR with Tesseract (`pytesseract`), after deskewing
   and raising contrast with Pillow when the first pass is poor. HTML
   emails: parse the body text. Keep the raw text per document for audit.
3. **Read the fields** per invoice: vendor legal name, vendor address,
   invoice number, invoice date, due date (or terms such as "Net 30" and a
   computed due date, marked computed), currency, subtotal, discount,
   shipping, tax by rate, total, amount paid and balance due, plus the
   extra fields requested. Line items: description, quantity, unit price,
   tax rate and line amount. Normalize dates to YYYY-MM-DD and amounts to
   plain numbers; resolve day-month order from the vendor's country and
   other dates in the same document.
4. **Check the arithmetic.**
   - Sum of line amounts = subtotal (within 0.01 per line for rounding).
   - Subtotal − discount + shipping + tax = total.
   - Tax ÷ taxable amount matches a plausible rate for the country.
   - Due date is on or after the invoice date.
   Any failure sets the row's confidence to low with the reason.
5. **Catch duplicates and fraud signals.** The same vendor and invoice
   number twice, or the same vendor, amount and date: keep one, list the
   other as a duplicate. When bank details are captured, compare them with
   the same vendor's earlier invoices; a change is a classic payment-fraud
   signal, so flag it prominently and recommend confirming by phone using
   a number already on file, not one in the email.
6. **Categorize and convert** when asked. Suggest one expense category per
   invoice (or per line) from the brief's list, marked as a suggestion.
   Convert foreign-currency totals at the invoice-date rate from a cited
   public source such as the central bank's reference rates.
7. **Shape the output.** For QuickBooks or Xero import formats, look up the
   current bill import template in the vendor's own help documentation and
   match its column headers and date format exactly; cite the page.
8. **Spot-check** five invoices (or all, if fewer than ten) field by field
   against the source before presenting.

## Deliverables

- **Primary:** `invoices-<period>.xlsx` with sheets Invoices (one row per
  invoice with a confidence column and a source reference), Line items
  (keyed by vendor and invoice number), Needs review (every low-confidence
  row, duplicate and fraud flag, with the reason), Vendor summary (count
  and total per vendor and currency) and Sources. For CSV or import
  formats, deliver `invoices-<period>.csv` (and `invoice-lines-<period>.csv`
  when line items were requested) plus `needs-review.csv`.
- Present:

  ```sh
  zen output present --type file --title "Invoice data — <period>" \
    --summary "<n> invoices totalling <amount>; <m> need review" \
    --primary invoices-<period>.xlsx="Invoice data"
  ```

  For a CSV or import format, make `invoices-<period>.csv` the primary item
  and add `--final invoice-lines-<period>.csv="Line items"` (when built) and
  `--supporting needs-review.csv="Needs review"`. If openpyxl is
  unavailable, fall back to the CSV set and say so.

## Quality bar

- Never guess a value: blank plus a flag beats a plausible wrong number.
- Every row links back to the email or file it came from.
- Totals in the output equal the sum of the source invoices, per currency.
- Invoice contents, bank details and tax IDs stay in the result only.
- Nothing in the mailbox, the folders or the books is changed.

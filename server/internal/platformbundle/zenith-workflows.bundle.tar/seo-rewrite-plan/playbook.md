# SEO rewrite plan

You are deciding what to do with the pages a site already has, using its
own search data. The reader is a content lead or founder with limited
writing time who needs to know which pages earn it. Good output sorts
every page into one clear action, backs each call with numbers, sizes the
opportunity, and fits the work to the stated capacity. It also avoids the
classic damage: pruning pages that carry links or conversions, or
redirecting everything to the homepage.

## Inputs

- Site, optional section, comparison period, goal, capacity, protected
  pages and the performance exports, all in the brief.
- The performance exports in the brief are the only data source and are
  required: a Search Console performance export (pages, and pages with
  queries, up to 16 months), pasted or linked. If the comparison needs
  more history than the export holds, use what exists and say so in the
  method notes. If the brief holds no export, or the link cannot be opened
  or has no clicks and impressions, stop before planning and report that
  the plan cannot be built without it; never invent clicks, impressions or
  positions.
- An analytics export of landing pages adds conversions. A backlink
  export, if shared, protects linked pages.

## Procedure

1. **Assemble one table per URL.** Clicks, impressions, CTR and average
   position for both periods; the same period a year earlier where data
   allows (to separate decay from seasonality); top queries; conversions;
   and from a polite crawl of the pages: status, canonical, title, H1,
   word count, last-updated date and internal links in. Normalise URLs
   (protocol, trailing slash, parameters) before joining.
2. **Detect decay.** Flag pages whose clicks fell by 20 percent or more
   period over period and year over year. Diagnose the cause from the
   numbers: impressions steady but CTR down (title, snippet or a new
   results-page feature), position slipping (content outdated or
   outcompeted), impressions down (demand fell or the page lost relevance).
3. **Detect cannibalisation.** For each query with meaningful impressions,
   count the site's URLs receiving impressions. Flag queries where a
   second URL takes at least 20 percent of impressions, or where the
   ranking URL keeps switching. Group the competing URLs.
4. **Classify every page into one action:**
   - **Keep**: stable or growing, with no decay, cannibalisation or
     intent mismatch worth fixing.
   - **Refresh**: small, fixable decay; update facts, dates, examples,
     title and meta.
   - **Rewrite**: high impressions but position 8 to 30, intent mismatch
     with today's results page, or thin content. Substantial rework.
   - **Merge**: two or more pages competing for the same queries. Pick
     the winner by clicks, links, conversions and fit; fold in the useful
     content; 301 the others to it.
   - **Redirect**: obsolete pages with links or traffic; 301 to the most
     relevant live page.
   - **Prune**: no clicks and negligible impressions for the full window,
     no links, no conversions and no business purpose. Recommend
     `noindex` or removal with a 410, and say which.
   Protected pages are always Keep or Refresh.
5. **Size the opportunity.** Build a CTR-by-position curve from the site's
   own Search Console export (average CTR per position bucket). Opportunity
   = impressions x (expected CTR at a realistic target position - current
   CTR). If the site has too little data, use a conservative curve and
   label it an assumption.
6. **Prioritise and schedule.** Rank by opportunity weighted toward the
   goal (conversions count double when the goal is conversions), then by
   effort. Fit the list to capacity: month one, month two, month three.
   Merges and redirects go early because they are cheap and consolidate
   signals.
7. **Write page-level notes** for every Refresh, Rewrite and Merge in the
   first two months: target query and intent, what today's top results do
   better, sections to add, cut or update, new title and meta description,
   and internal links to add. For merges, which content moves where.
8. **Produce the redirect map**: old URL, new URL, status code and reason,
   one-to-one, followed by the internal links and sitemap entries to
   update.

## Deliverables

- **Primary:** `seo-rewrite-plan.xlsx` with sheets *Pages* (URL, metrics
  for both periods, change, top query, conversions, word count, last
  updated, action, reason, opportunity, priority, month), *Cannibalisation*
  (query, competing URLs, impression share, winner), *Redirects*,
  *Page notes* and *Method*. If openpyxl is missing, deliver CSV files.
- **Final:** `seo-rewrite-plan.md`: summary counts by action, the top
  opportunities, the three-month schedule, risks and how to measure the
  result (annotate the change date and compare four to eight weeks later).
- Present them:

  ```sh
  zen output present --type file --title "SEO rewrite plan — <domain>" \
    --summary "<pages by action and the size of the top opportunity>" \
    --primary seo-rewrite-plan.xlsx="Rewrite plan" \
    --final seo-rewrite-plan.md="Summary and schedule"
  ```

## Quality bar

- Every action cites its numbers; no page is labelled from its title
  alone.
- Never recommend pruning a page with backlinks, conversions or a
  protected path without flagging it as a judgement call.
- Redirects go to the closest relevant page, never in bulk to the
  homepage, and never form chains.
- Note Search Console limits: anonymised queries, sampling and a delay of
  a few days in the latest data.
- Change nothing on the site; this is a plan.

# Daily work briefing

You are writing the page a person reads with their first coffee: it tells
them what today holds, what it demands of them and what happened while
they were away. A good briefing makes decisions easier — which three things
matter, which meeting needs prep, what can wait — instead of listing
everything. It is read-only: you look, you do not touch.

## Inputs

- The week's priorities, the sources to check, what counts as overnight,
  people or topics to watch, the time zone and the briefing length.
- Connectors: a calendar Connector is the backbone; mail, chat, task
  tracker, code host and docs Connectors add the rest. Use each read-only.
  If no calendar Connector is available, say so at the top and build the
  briefing from the others. If no Connector at all is available, stop and
  report that the briefing needs at least one.
- Time zone: the brief's, else the calendar's primary zone, else the
  computer's local zone, stated as an assumption. Every time in the
  briefing uses that zone.

## Procedure

1. **Frame the day.** Today's date, weekday, and whether it is a working
   day for the person (public holiday or out-of-office event on the
   calendar). On an out-of-office day produce only overnight items that
   cannot wait.
2. **Read the calendar.** For each event today: time, title, attendees
   (mark external people and anyone senior or new), whether the person
   accepted, the linked agenda or doc, and location or video link. Detect:
   - overlaps and double bookings;
   - runs of back-to-back meetings over three hours with no break;
   - meetings with no agenda or description;
   - events that need travel time;
   - the largest free blocks, which are the day's focus opportunities.
3. **Prepare meeting notes.** For each meeting that needs it (external
   calls, interviews, decisions, one-to-ones, anything the person
   presents at): the purpose in one line, the last email or chat thread
   with those attendees, open items between them, and what to bring or
   read. Skip prep for routine recurring meetings unless something about
   them changed.
4. **Collect deadlines.** Tickets and tasks due today, tomorrow or
   overdue; pull requests awaiting the person's review; promises the
   person made in sent email or chat ("I'll send it Tuesday") that fall
   due today; calendar deadlines such as filings or launches.
5. **Scan overnight.** Within the overnight window: emails that need the
   person, direct messages and mentions, new assignments, review
   requests, failed builds or incidents on main branches and production,
   calendar invitations, cancellations and moves, and anything about the
   watched people, projects or keywords. Collapse notifications,
   newsletters and routine bot messages into a single count line.
6. **Choose the top three.** Rank candidates by: deadline today, blocks
   other people, advances a stated weekly priority, external commitment.
   For each give one line of why and a suggested slot in a free block.
   If the day has no free block longer than 45 minutes, say so — that is
   useful information.
7. **Trim to length.** A two-minute read is at most about 250 words:
   top three, meeting list with one line each, due items, overnight
   highlights. A full briefing adds the prep notes and the watch list.

## Deliverables

- **Primary:** `daily-briefing.md` titled "Daily briefing — <weekday,
  date>" with sections in this order: Today at a glance (one line), Top
  three, Meetings, Due today and tomorrow, Overnight, Watch list (full
  briefing only), Gaps (sources that failed or were not connected).
- Present it:

  ```sh
  zen output present --type text --title "Daily briefing — <date>" \
    --summary "<n> meetings, <n> due today; first priority: <one line>" \
    --primary daily-briefing.md="Daily briefing"
  ```

## Quality bar

- Read-only: never accept, decline or move events, send messages, change
  ticket status or mark anything read.
- Every time is in one stated time zone; every due item names its source.
- Never invent attendees, agendas or deadlines; missing information is
  written as missing.
- The top three are specific actions ("Finish the pricing section of the
  board memo, 09:00–10:30"), not topics.
- A quiet day gets a short briefing. Do not pad.

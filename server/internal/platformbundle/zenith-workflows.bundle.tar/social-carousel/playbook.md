# Social carousel

You are designing a six-slide carousel and rendering it as finished image
files. Carousels win on two things: a cover that makes people swipe, and
slides that each deliver one clear point in type large enough to read on a
phone. The person should be able to upload the files exactly as delivered.

There is no generative image model on this computer. Build every slide
programmatically — HTML and CSS rendered to PNG by a headless browser
(preferred), or Python Pillow. Photos and screenshots come only from the
brief or from openly licensed sources.

## Inputs

- The idea and the platform come from the brief. Source material, call to
  action, style, brand details, logo and images are optional.
- Read any linked page fully. Facts on slides come only from the brief or
  that page; if the link fails, work from the idea and say so.
- Download the logo and images with `curl -L`, confirm each opens in
  Pillow and note its size. Prefer SVG or large PNG logos. Skip any image
  whose right to use you cannot confirm, and say so.
- A brand guide in Google Drive or Figma, when a Connector is available,
  sets colors and fonts. Otherwise choose one dark, one light and one
  accent color that fit the style, and a font pair whose licence allows
  commercial use (most Google Fonts do).

## Procedure

1. **Write the slides first.** Six slides, one job each:
   1. *Cover* — a promise, tension or number in at most 10 words, plus a
      small swipe cue.
   2. *Context* — why this matters now, or the problem in one line.
   3. *Point one*, 4. *Point two*, 5. *Point three* — a headline of at most
      8 words and at most 25 words of support: an example, a number or a
      how-to.
   6. *Payoff and call to action* — the takeaway in one line and the action
      (save, follow, comment or visit), using the brief's call to action
      when given.
   Read the six headlines alone: they should tell the whole story.
2. **Set the canvas.** Instagram and LinkedIn: 1080 × 1350 px (4:5).
   TikTok photo mode: 1080 × 1920 px (9:16). Keep at least 90 px margins.
   On 9:16, keep text clear of the top 220 px and the bottom 380 px, where
   app controls sit. On 4:5, keep key text inside the central
   1080 × 1080 area, since profile grids crop the edges.
3. **Design a system, then apply it.** One HTML template with CSS variables
   for colors and fonts; the same headline position, margins and footer
   (handle and slide number, such as "2/6") on every slide. Headlines
   80–120 px, body 38–48 px, nothing under 32 px, at most two typefaces.
   Text over photos sits on a solid panel or a strong gradient. Compute
   the contrast ratio from the hex values: at least 4.5:1 for body text.
4. **Render.** With Playwright (`pip install playwright`, then
   `playwright install chromium`): set the viewport to the exact canvas,
   `device_scale_factor=1`, wait for `document.fonts.ready`, and screenshot
   each slide to `slide-01.png` … `slide-06.png`. If no browser can run,
   draw the slides with Pillow and a downloaded TrueType font.
5. **Check every file** with Pillow: exact pixel size, RGB with no alpha
   channel (some apps turn transparency black), under 8 MB. Look at every
   image: no clipped words, no one-word last lines, nothing overlapping the
   footer. Downscale a copy to 360 px wide; the headline must still read.
6. **Assemble the extras.**
   - `carousel.pdf`: the six slides in order, one per page (`img2pdf`, or
     Pillow with `save_all=True`), for LinkedIn document posts.
   - `carousel-overview.png`: all six slides side by side for quick review.
   - A caption: a first line that complements the cover, three to six
     short lines of value, the call to action, and hashtags suited to the
     platform (3–5 on Instagram, 0–3 on LinkedIn, 3–5 on TikTok).
   - Alt text for each slide: its words plus what the visual shows.

## Deliverables

- **Primary:** `carousel-overview.png` — the six slides in order on one
  sheet.
- **Final:** `slide-01.png` … `slide-06.png` and `carousel.pdf`.
- **Supporting:** `caption.md` (caption, alt text per slide, image and font
  credits) and `carousel.html` (the source template, for later edits).
- Present them:

  ```sh
  zen output present --type media --title "Carousel — <idea>" \
    --summary "<platform, size and the cover line in one sentence>" \
    --primary carousel-overview.png="All six slides" \
    --final slide-01.png="Slide 1" --final slide-02.png="Slide 2" \
    --final slide-03.png="Slide 3" --final slide-04.png="Slide 4" \
    --final slide-05.png="Slide 5" --final slide-06.png="Slide 6" \
    --final carousel.pdf="PDF for LinkedIn" \
    --supporting caption.md="Caption and alt text" \
    --supporting carousel.html="Slide source"
  ```

## Quality bar

- Exactly six slides at the exact platform size, each file verified.
- The cover reads in under two seconds; no slide carries more than one idea
  or more than about 35 words.
- No invented statistics or testimonials, and no other company's logo.
  Credit every stock image; use only images the person supplied or that
  carry an open licence.
- Margins, fonts, colors and footer are consistent across all six slides.
- Never post or schedule anything.

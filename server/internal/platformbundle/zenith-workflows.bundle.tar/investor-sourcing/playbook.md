# Investor sourcing

You are building a fundraising target list for a founder. A long list of
famous funds is worthless; what helps is a ranked list of investors who
are actively writing cheques at this stage, in this sector and geography,
with the specific partner to approach, evidence that the thesis fits, and
a realistic idea for how to get introduced. This is research to support a
fundraise, not investment or securities advice, and you never contact
anyone.

## Inputs

- Company, pitch and traction, sector, stage, amount and lead status,
  location, investor types, list size, the founder's network and
  exclusions — all in the brief. If the pitch is too thin to judge fit,
  read the website; if there is none, proceed on the pitch and say so.
- A CRM Connector (HubSpot) or a mail Connector (Gmail) can show which
  investors the founder already knows or has spoken to. Read only; never
  update records or send mail. LinkedIn and Firecrawl help read public
  profiles and fund pages. Everything works with ordinary web research.

## Procedure

1. **Write the fit profile.** Stage; realistic cheque sizes (a lead
   typically takes a large share of the round, follow-ons smaller
   amounts); sector keywords and adjacent theses an investor would file
   this company under; geography rules (many seed funds invest only
   locally or in-region); and the three traits of the company most
   likely to attract or deter investors.
2. **Find candidates from deals, not directories.** The best signal is who
   recently backed comparable companies:
   - Funding announcements in the sector and stage over the last 24
     months (company press releases, trade press, fund blogs).
   - Portfolio pages and investment announcements of funds that appear
     repeatedly.
   - SEC Form D filings on EDGAR (US) and equivalent registries elsewhere
     (for example share-allotment filings at Companies House) to confirm
     rounds and dates.
   - Partner essays, podcasts and posts that state a thesis matching the
     company.
   - Accelerator cohorts and syndicate pages for pre-seed and seed.
   Gather two to three times the requested list size before filtering.
3. **Check they are active.** For each firm confirm: a new investment in
   the last 6 to 12 months; the current fund's vintage and size where
   public (a fund raised more than four years ago may be reserving
   capital for follow-ons); and that the relevant partner is still at the
   firm. Drop inactive investors or mark them clearly.
4. **Check conflicts.** Search each firm's portfolio for direct
   competitors of the company. A direct competitor usually means a no;
   list it and move the firm to the exclusions sheet unless the overlap
   is partial, in which case flag it.
5. **Score fit** out of 15:
   - **Stage** 0–3 — invests at this stage often, and leads at it.
   - **Cheque** 0–2 — typical cheque fits the round.
   - **Thesis** 0–4 — comparable deals and stated thesis; name them.
   - **Geography** 0–2.
   - **Activity** 0–2 — recency and pace of new deals.
   - **Access** 0–2 — strength of the warm path.
   Tier the list: **Tier 1** lead candidates (high score and leads at
   this stage), **Tier 2** strong co-investors, **Tier 3** angels and
   follow-on fillers.
6. **Name the partner.** For each firm, the person whose portfolio and
   public writing fit best, with a link to their public profile or bio.
7. **Suggest warm paths**, strongest first: founders of the investor's
   portfolio companies the founder knows; the founder's current investors
   who co-invest with this firm; advisors or former colleagues listed in
   the brief; shared accelerator or alumni networks. Label every path
   "to verify" — you are inferring from public information, never
   asserting a relationship. Where there is no path, give a cold-approach
   angle: the specific deal or essay to reference.
8. **Plan the sequence.** Recommend the order of outreach (leads first,
   in batches so meetings land in the same few weeks) and name any gaps,
   such as too few active leads for this stage in this region.

## Deliverables

- **Primary:** `investor-list.xlsx` with sheets:
  - **Investors** — rank, tier, firm, partner, profile link, investor
    type, location, stages, typical cheque, leads rounds (yes/no), fund
    and vintage, last new investment date, comparable deals (company,
    round, date, link), thesis evidence, score per factor, total score
    (formula), conflicts, warm path, approach angle, sources.
  - **Scoring** — the rubric and weights.
  - **Excluded** — firm and reason (conflict, inactive, in the brief's
    exclusions).
  - **Sources**.
  Deliver CSV files with the same columns if openpyxl is unavailable.
- **Final:** `investor-sourcing.md` — the fit profile, the top ten with
  two lines each on why, suggested sequencing, and gaps.
- Present them:

  ```sh
  zen output present --type file --title "Investor list — <company>" \
    --summary "<n> investors ranked; <n> Tier 1 lead candidates" \
    --primary investor-list.xlsx="Investor list" \
    --final investor-sourcing.md="Summary and sequencing"
  ```

## Quality bar

- Every thesis-fit claim links to a deal, portfolio page or public
  statement; deals older than 24 months are marked as such.
- No investor on the list backs a direct competitor without a flag.
- Contact details are limited to public professional channels (a firm
  page, a published submission form); never guess personal email
  addresses.
- Never present an inferred introduction path as an existing
  relationship.
- Respect the exclusions list exactly.

# Cash runway forecast

You are forecasting one company's cash so its leaders know how long the
money lasts and what to do about it. The reader is a founder or finance
lead who will reuse the forecast every week. Good means a 13-week view
built from actual receipts and payments (not a P&L in disguise), a
12-month view that agrees with it, runway dates for each scenario, and a
short list of levers with their effect in weeks. This is decision support,
not financial advice.

## Inputs

- Company, data source, cash on hand, actuals, known events, business
  model, week 1 date (default: the coming Monday), minimum buffer and
  downside definition are in the brief.
- **Accounting Connector:** read bank balances, the last 3–6 months of
  P&L, open invoices with due dates, unpaid bills, and recurring payroll.
  Read-only: never create, edit or categorize anything.
- **Pasted or linked data:** use it as given. With no accounting
  Connector in the Run and no actuals pasted or linked, stop before
  building anything and say the forecast needs one of them. If there is
  no starting cash figure and no way to read one, stop and ask for it;
  runway cannot be computed without it.
- Blank minimum buffer: use two months of average gross cash outflows and
  label it.

## Procedure

1. **Establish the opening position.** Cash by account on the start date,
   less any restricted or pledged cash, plus undrawn committed credit
   shown on a separate line (never mixed into cash).
2. **Study the history.** Average weekly receipts and payments, the
   collection pattern (share of invoices paid within 30, 60 and 90 days, or
   card and payout timing for online sales), payroll dates and amounts,
   recurring vendors and their days, seasonality.
3. **Build the 13-week forecast (direct method),** one column per week:
   - Receipts: open receivables by expected payment week (due date adjusted
     by each customer's past lateness), new sales collected on the observed
     lag, subscription renewals, payment processor payouts, other income.
   - Payments: payroll and payroll taxes on the actual pay calendar, rent,
     vendors from open bills and recurring spend, inventory purchases,
     loan payments, taxes, insurance, capex, and every known event.
   - Net cash flow, opening and closing cash, line availability, and a
     flag in any week closing cash falls below the buffer.
4. **Build the 12-month forecast** by month from drivers: revenue plan by
   stream, collections from revenue using days sales outstanding, cost
   lines by department with the hiring plan, capex, debt service. Months
   1–3 must reconcile to the 13-week view within a small tolerance; explain
   any difference.
5. **Business-model mechanics.** Subscription: annual prepayments arrive
   up front, so deferred revenue is cash already spent. E-commerce: payout
   delays, inventory buys ahead of peaks, returns. Services: milestone
   billing and slow payers. Manufacturing: raw materials paid before
   customers pay. Marketplace: money held for others is not your cash.
6. **Scenarios.**
   - Base: the plan and known events.
   - Downside: as chosen in the brief (sales below plan, slower
     collections, and a lost largest customer in the severe case), with
     costs unchanged unless a cut is already decided.
   - Upside: sales 10% above plan with collections on time, labelled.
   For each: net burn (payments minus receipts, monthly average), gross
   burn, the date cash falls below the buffer, and the cash-zero date.
7. **Levers.** List 5–8 concrete actions with cash effect and timing:
   collect the oldest receivables, move customers to annual prepay, delay
   or phase hires, renegotiate vendor terms, cut discretionary spend,
   draw or extend a credit line, sell surplus inventory, raise capital.
   Show the runway in weeks each adds and the combined effect.
8. **Make it reusable.** An Actuals sheet with the same rows so next week's
   real numbers sit beside the forecast, a variance column, and a note on
   how to roll the forecast forward by one week.

## Deliverables

- **Primary:** `cash-forecast-<company>.xlsx` with sheets Summary (runway
  by scenario, lowest cash week, buffer breach and cash-zero dates, a
  closing-cash chart), Inputs, 13-week, 12-month, Scenarios, Levers,
  Actuals vs forecast, Sources. Live formulas; inputs in blue.
- **Supporting:** `runway-brief.md`, under one page: runway in each case,
  the three biggest risks to it and the three levers to pull first.
- Present:

  ```sh
  zen output present --type file --title "Cash runway — <company>" \
    --summary "<base-case runway and cash-zero date, and the downside date>" \
    --primary cash-forecast-<company>.xlsx="Cash forecast" \
    --supporting runway-brief.md="Runway brief"
  ```

  If openpyxl is unavailable, deliver the 13-week and 12-month tables as
  CSV plus the brief.

## Quality bar

- Receipts and payments are timed by week from real dates, not spread
  evenly from monthly totals.
- Undrawn credit and restricted cash are shown separately from cash.
- Every assumption (collection lag, growth, hiring dates) is visible on the
  Inputs sheet with its basis.
- Dates are stated as calendar dates, not only "month 7".
- Nothing in the books is changed; figures you could not read are listed
  as gaps, never invented.

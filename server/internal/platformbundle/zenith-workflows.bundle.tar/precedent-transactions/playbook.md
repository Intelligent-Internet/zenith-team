# Precedent transactions

You are valuing one company by reference to what acquirers have paid for
similar businesses. The reader is pricing a sale, shaping an offer or
checking a proposed price, and needs to know which deals are truly
comparable, what was really paid, and what range that supports. Good means
deal terms rebuilt from primary disclosures on one consistent basis, honest
treatment of thin private-deal data, and a range tied to named percentiles.
This is decision support, not investment advice.

## Inputs

- Target, profile, purpose, look-back, deal types, geography, size range and
  known deals are in the brief. Include every known deal and verify it.
- Without a usable profile for a private target (sector and at least
  revenue or EBITDA), still build the deal set, but state that the implied
  value needs the target's metrics.
- Paid deal databases are usually unavailable. Work from public
  disclosures, cite every figure, and mark press-reported values
  "reported". A pasted database export may be used as-is with its source.

## Procedure

1. **Find candidate deals.** Search, in this order:
   - US filings on EDGAR: 8-K Item 1.01 and 2.01, merger proxies (DEFM14A),
     tender offers (SC TO-T), going-private statements (SC 13E-3) and S-4s.
     The fairness-opinion section of a merger proxy lists the adviser's own
     precedent set, which is an excellent lead list.
   - Outside the US: the takeover regulator or exchange announcement (for
     example UK firm-offer announcements under Rule 2.7), and annual reports
     of listed acquirers, which disclose acquisition consideration.
   - Acquirer and target press releases, investor presentations and
     reputable trade press for private deals.
   Keep deals inside the look-back, deal types, geography and size range;
   widen one criterion at a time if fewer than eight qualify, and say so.
2. **Normalize terms** for each deal:
   - Headline equity value (offer price × diluted shares at the offer
     price, treasury stock method) and enterprise value (+ debt, preferred,
     non-controlling interests − cash, from the last balance sheet before
     announcement).
   - Consideration mix: cash, stock (valued at the unaffected price, not
     the closing price), assumed debt.
   - Contingent consideration: show EV with earnouts at maximum and
     without; contingent value rights at stated value with a note.
   - Status: announced, completed, terminated; announcement and close
     dates.
3. **Build target metrics at announcement:** LTM revenue and EBITDA from
   the target's last filing before announcement, or the figures the deal
   documents cite. Use standalone metrics, not synergy-adjusted ones; if
   only a synergy-inclusive multiple is disclosed, flag it.
4. **Control premiums** for listed targets: offer price vs the unaffected
   price — one day, one week and four weeks before the unaffected date,
   which is the day before the first credible leak, rumour or approach, not
   simply the day before announcement. Cite the unaffected date's basis.
5. **Screen relevance.** Score each deal on business similarity, size,
   buyer type and market regime (rates and sector multiples at the time).
   Tier the set (most relevant, supporting). Distressed and minority deals
   stay in a separate block unless the brief asks for them. Keep an
   Excluded list with reasons.
6. **Statistics and implied value.** For EV/LTM revenue and EV/LTM EBITDA
   show maximum, 75th percentile, median, 25th percentile and minimum for
   all deals and for the top tier. Apply the top tier's 25th–75th band to
   the target's metrics. For a listed target, cross-check by applying the
   premium band to its unaffected price. Note that precedent multiples
   include a control premium and usually sit above trading multiples.
7. **Verify** three deals end to end against source documents before
   presenting.

## Deliverables

- **Primary:** `precedents-<target>.xlsx` with sheets Summary (implied
  range, method, disclaimer), Transactions (one row per deal: dates,
  acquirer, target, buyer type, consideration, equity value, EV, earnout,
  LTM revenue and EBITDA, multiples, premium, tier, source link),
  Premiums, Implied value, Excluded, Sources.
- **Supporting:** `precedents-memo.md`: the range, the five most relevant
  deals and why, market-regime caveats, data gaps.
- Present:

  ```sh
  zen output present --type file --title "Precedent transactions — <target>" \
    --summary "<implied value range and the deal multiples behind it>" \
    --primary precedents-<target>.xlsx="Precedent transactions" \
    --supporting precedents-memo.md="Precedents memo"
  ```

  Without openpyxl, write `precedents-transactions.csv` and
  `precedents-implied-value.csv`, make the memo primary with `--type text`
  and pass the CSVs as `--final` items.

## Quality bar

- Every figure links to a filing, announcement or article; press numbers
  are marked "reported" and never mixed silently with filed numbers.
- Enterprise value is built the same way for every deal.
- Undisclosed values stay blank; never back into a price from rumours.
- Deals from very different rate or valuation regimes are flagged.
- The range rests on named percentiles of the most relevant tier.

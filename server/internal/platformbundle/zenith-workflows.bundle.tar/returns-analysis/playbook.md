# Returns analysis

You are finding out why a store's customers send products back and which
fixes would save the most money. The reader is an owner or operations lead
who needs to know where returns really come from, what they cost, and what to
change first. Good analysis cleans messy reasons into one taxonomy, measures
return rates on orders old enough to have finished their return window, ranks
causes by cost rather than count, separates fixable causes from normal
customer behaviour, and gives every fix an estimated saving with its
assumptions shown.

## Inputs

- The brief gives the store, the order period, breakdowns, the return policy,
  return costs, known issues and any data links.
- A store Connector (Shopify) gives orders, refunds, returns and variants,
  read only. A helpdesk Connector (Zendesk) adds the customer's own words
  when return reasons are thin. A drive Connector opens linked exports.
- If neither a store Connector nor readable returns data in the brief is
  available, stop before analysing and say what is missing.
  When cost inputs are missing, use clearly labelled defaults (return label
  at the store's typical shipping cost, 10 minutes of handling, 80 percent
  resaleable) and show how the total changes if they are wrong.

## Procedure

1. **Assemble the data.** One row per returned unit: order id and date,
   return date, product, variant, category, price paid, discount, refund
   amount, refund type (money back, store credit, exchange), reason code,
   customer note, channel, new or repeat customer, carrier. Add units sold
   per variant for the same order period.
2. **Use mature orders.** Count returns against orders placed in the period
   whose return window has closed. For the most recent weeks, report rates
   separately as provisional. Return rate = units returned / units sold;
   also show value return rate = refunds / net sales.
3. **Clean the reasons.** Map codes and free-text notes to one taxonomy:
   - Fit: too small, too large, other fit (length, width, shape).
   - Not as expected: looks different from photos, colour, material or feel,
     smaller or bigger than expected.
   - Defect: faulty, broken, missing parts; damaged in transit.
   - Fulfilment: wrong item or size sent, arrived too late.
   - Preference: changed mind, ordered several sizes to choose from, gift,
     found cheaper, no reason.
   Use the note over the code when they disagree ("changed mind" with the
   note "strap broke" is a defect). Report how many rows were reclassified.
4. **Cost each return.** Cost = return shipping paid by the store + handling
   and inspection + payment fees not refunded + outbound shipping the store
   paid + unit cost x share that cannot be resold. Report lost gross margin
   on refunded orders separately, and treat exchanges as a second outbound
   shipment instead of a lost sale.
5. **Rank the causes.** Build a table of reasons by units, share and total
   cost, sorted by cost, with a cumulative share (the few reasons behind most
   of the cost). Mark each as controllable (fit, not as expected, defect,
   fulfilment) or mostly behavioural (preference).
6. **Find the outliers.** For each product and variant with at least 30
   units sold, compare its return rate with its category's rate. Flag it
   when the lower bound of a 95 percent Wilson interval is above the
   category rate. For apparel and footwear, look for size skew: many "too
   small" returns on one size, or a style that runs small across sizes.
   Detect multi-size ordering: one order holding the same product in several
   sizes with all but one returned.
7. **Cut by the requested segments** (channel, new or repeat, discounted or
   full price, carrier) and note only differences that are large and rest on
   enough orders. Look at repeat returners in aggregate only: how much of the
   return volume a small share of customers creates. Never list individual
   customers.
8. **Check the known issues.** Compare rates before and after each dated
   change (new factory, new size chart, carrier switch) with sample sizes.
9. **Recommend fixes.** For each major controllable cause, a specific fix:
   fit notes and measured size charts, better photos and material close-ups,
   supplier quality checks, sturdier packing, scan-verified picking, clearer
   delivery estimates, exchange-first or store-credit incentives, final sale
   on deep discounts. Estimate savings = returns avoided x cost per return
   (+ margin kept), with the assumed reduction stated as a range.

## Deliverables

- **Primary:** `returns-analysis.md` titled "Returns analysis — <store>":
  1. Summary: return rate, total cost, the three causes behind most of it,
     and the top three fixes with savings.
  2. Reasons ranked by cost, with the controllable flag.
  3. Products and variants that stand out, with size-skew findings.
  4. Segment findings and before/after checks.
  5. Fix plan: cause, fix, owner type, effort, estimated saving, assumptions.
  6. Method and limits: data sources, maturity cut-off, reclassification
     count, cost defaults used.
- **Final:** `returns-analysis.xlsx` (openpyxl) with sheets `Inputs` (costs
  and assumptions), `Returns` (every coded row), `Reasons`, `Products`,
  `Fixes` (live formulas linked to Inputs) and `Notes`. Without openpyxl,
  write `returns-analysis.csv` of the coded rows.
- Present them:

  ```sh
  zen output present --type text --title "Returns analysis — <store>" \
    --summary "<return rate, total cost and the top cause, in one sentence>" \
    --primary returns-analysis.md="Returns analysis" \
    --final returns-analysis.xlsx="Returns workbook"
  ```

  Name `returns-analysis.csv` in the `--final` line instead when you fell
  back to CSV.

## Quality bar

- Return rates use mature orders and state their denominator.
- Costs rest on stated inputs; defaults are labelled and have a sensitivity
  line.
- Small samples are never called outliers; every flagged product meets the
  minimum volume and the interval test.
- Fixes are specific to a product or process, never "improve quality".
- No customer names, emails or addresses appear in any output.

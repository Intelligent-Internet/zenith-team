# Content repurposing

You are turning one substantial piece of content into a kit of smaller
pieces that each stand on their own and together send people back to the
original. The craft is extraction, not summarising: find the ideas,
numbers, stories and lines strong enough to carry a post by themselves,
then give each one the shape its channel rewards. Someone who never sees
the original should still get value from every piece.

## Inputs

- Title, the piece (text or link), its kind and the outputs wanted come
  from the brief. Audience, volume, destination link and house rules are
  optional; with no destination link, point to the original piece.
- Read the whole piece. For an article, fetch the page and strip the
  navigation; for a PDF use `pdftotext -layout`; for a YouTube video fetch
  captions with `yt-dlp --write-subs --write-auto-subs --sub-format vtt
  --skip-download <url>` and keep the timestamps. If nothing readable comes
  back, stop and report — never repurpose a piece you have not read.
- Google Drive or Notion Connectors, when available, are for reading the
  source or a brand voice guide only.
- Repurpose only content the Company owns or has permission to reuse. If
  the piece is clearly a third party's work, stop and report; quoting
  someone else's piece with attribution belongs in a commentary post, not
  a repurposing kit.

## Procedure

1. **Build the idea inventory.** Before writing anything, list:
   - the core thesis in one sentence;
   - 5–12 distinct ideas, each with the section or timestamp it comes from;
   - every number with its context (what, when, sample, source);
   - quotable lines, verbatim, with speaker and location;
   - stories, examples and before-and-after moments;
   - lists and frameworks (steps, mistakes, principles);
   - surprising or contrarian points, and the questions the piece answers.
   Rate each item's standalone strength from 1 to 3. Only items rated 2 or
   3 become pieces.
2. **Match ideas to formats.** Lists and frameworks → carousel or thread;
   a single striking number → stat card or short post; a story → LinkedIn
   post or short video; a how-to → thread or email; a sharp line → pull
   quote; a surprising finding → short video hook; the questions → FAQ.
   One idea per piece, and no two pieces in the same channel built on the
   same idea.
3. **Size the kit** to the chosen volume: light about 8 pieces, standard
   about 15, full 25 or more. Cover every requested output type once before
   adding a second piece of any type.
4. **Write each piece natively.**
   - LinkedIn: hook in the first line, 80–250 words, short paragraphs, a
     question or the link at the end.
   - X: single posts under 280 characters, and one thread of four to eight
     posts whose first post stands alone.
   - Carousel outline: 6–10 slides; per slide a headline and at most 25
     words; a cover that makes a promise and a last slide with the call to
     action.
   - Short video script (30–60 seconds): on-screen hook text, a spoken hook
     in the first three seconds, three beats and a closing line. When the
     source is a video, name the timestamp to cut from.
   - Newsletter section of 120–200 words with one link; nurture email with
     subject, preview text, a 120–180 word body and one call to action.
   - Pull quotes and stat cards: the verbatim line or number, attribution
     and a one-line caption.
   - FAQ: the question in the audience's words and a 40–80 word answer.
   - Summary blurb of 50–80 words and a meta description under 155
     characters.
5. **Sequence the release.** Spread the pieces over two to four weeks: lead
   with the strongest idea, alternate formats and channels, place quotes
   and stats between heavier pieces, and close with a recap that links the
   original. Give each piece a suggested day, not a time.
6. **Check fidelity.** Trace every number and quote to its location in the
   source. Quotes stay verbatim (trim filler only, marked with an
   ellipsis). No piece claims more than the source does; findings keep
   their caveats. People quoted in the piece keep their attribution.

## Deliverables

- **Primary:** `repurposing-kit.md`, titled "Repurposing kit — <title>":
  1. The idea inventory as a table: ID, idea, type, location, strength.
  2. The pieces grouped by channel. Each has an ID, the idea ID it uses,
     the text in a fenced block, character or word count, a visual
     suggestion and where the link goes.
  3. The release sequence: day, channel, piece ID, purpose.
  4. Notes: assumptions, gaps in the source, anything to confirm.
- **Final:** `pieces.csv` with columns `id, channel, format, suggested_day,
  text, link`, for import into a scheduling tool.
- Present them:

  ```sh
  zen output present --type text --title "Repurposing kit — <title>" \
    --summary "<number of pieces, channels and weeks covered>" \
    --primary repurposing-kit.md="Repurposing kit" \
    --final pieces.csv="Pieces for a scheduler"
  ```

## Quality bar

- Every piece makes sense without the original and carries one idea.
- Nothing new is claimed: every fact, number and quote maps to an inventory
  item with a location.
- Every piece respects its format's length, verified by count.
- At least half the pieces point back to the original or the destination
  link, without every piece being a link post.
- Never publish or schedule anything; the kit is copy for a person to use.

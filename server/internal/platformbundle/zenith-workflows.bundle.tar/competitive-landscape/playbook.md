# Competitive landscape

You are mapping the competition around one company. The reader is the
company's own team, an investor, a would-be entrant or an advisor, as the
brief says, and each wants the same core answer: who really competes for
the same customers, how they differ, who is winning and what that means for
the company. Good work draws the market boundary deliberately, sources every
claim, estimates share with a visible method, and ends with implications
rather than a directory of competitors.

## Inputs

- The company, market, perspective, known competitors, comparison
  dimensions and depth — all in the brief. If the company name is
  ambiguous, use its website to confirm which one and record it.
- If the market is blank, define it from the company's own positioning
  (homepage, product pages, filings) and state the definition up front.
- A Firecrawl Connector, when available, helps collect pricing and
  product pages at scale; otherwise fetch pages directly. Respect
  robots.txt and site terms; do not log in or bypass paywalls.

## Procedure

1. **Define the market.** State the customer, the job they hire the
   product for, the geography and the price band. This boundary decides
   who counts as a competitor; write it in two sentences.
2. **Build the competitor set in tiers.**
   - **Direct:** same customer, same job, similar price.
   - **Adjacent:** overlapping job from a different starting point (a
     suite with a module, a service firm, an upmarket or downmarket
     player).
   - **Substitutes:** spreadsheets, in-house builds, agencies, doing
     nothing.
   - **Emerging:** recently funded or launched entrants.
   Start from the brief's list, then search category pages, review-site
   categories, "alternatives to" comparisons, the company's own
   comparison pages, filings of listed peers (the competition section of
   an annual report) and recent funding announcements. Size the list to
   the depth chosen, prioritizing direct competitors.
3. **Profile each competitor** on the chosen dimensions: what it sells
   and to whom; pricing and packaging (from public pricing pages, dated;
   "contact sales" noted as such); product strengths and gaps; go-to-market
   (self-serve, sales-led, partners); scale (revenue from filings, or
   headcount, customer counts and funding as proxies); ownership and
   funding; customer sentiment from review sites (rating, review count,
   recurring praise and complaints — a biased sample, say so); and recent
   moves (launches, pricing changes, acquisitions, executive hires,
   hiring focus from job postings). Every fact gets a link and a date.
4. **Estimate share.** Choose the best available method and show it:
   reported revenue for public players; for private ones, triangulate
   from headcount × a revenue-per-employee benchmark for the category,
   stated customer counts × estimated average price, or funding stage.
   Present ranges, label every figure an estimate, and give the total
   market size only if a credible, dated source supports it.
5. **Find the axes.** Pick the two dimensions that best separate the
   players for this market's buyers (for example price versus breadth of
   product, or SMB versus enterprise focus against point solution versus
   platform). Score each competitor on both with a written rubric and plot
   the matrix with matplotlib: labelled points, bubble size for estimated
   scale, the company highlighted.
6. **Compare features and pricing** in grids: capability rows × players,
   marked full, partial or none with evidence; pricing tiers normalized
   to a common unit (per seat per month, per transaction) where possible.
7. **Assess differentiation and defensibility.** For the company and the
   three closest rivals: sources of advantage (switching costs, network
   effects, data, distribution, brand, cost position, regulation) and how
   durable each is.
8. **Draw implications** for the stated perspective: where the company
   wins and loses, white space, the most dangerous competitor and why,
   likely next moves, and three to five questions to investigate further.

## Deliverables

- **Primary:** `competitive-landscape.md` (or `.docx`): executive summary
  (five bullets); market definition; competitor tiers; positioning matrix
  image; comparison tables; share estimates with method; one profile per
  competitor (half a page each); differentiation; implications; sources.
- **Final:** `competitors.xlsx` with sheets `Profiles`, `Features`,
  `Pricing`, `Share estimates` (inputs and formulas), `Positioning scores`
  (rubric and scores) and `Sources`; and `positioning-matrix.png`.
- Present:

  ```sh
  zen output present --type text --title "Competitive landscape — <company>" \
    --summary "<the company's position and the main threat in one sentence>" \
    --primary competitive-landscape.md="Competitive landscape" \
    --final competitors.xlsx="Competitor workbook" \
    --final positioning-matrix.png="Positioning matrix"
  ```

  If openpyxl is missing, deliver one CSV per sheet as `--supporting`
  items. If matplotlib is missing, render the matrix as an HTML/SVG
  scatter captured to PNG with a headless browser, or include the scores
  table and say the image is missing.

## Quality bar

- Every competitor fact has a source link and a date; pricing pages are
  dated because they change.
- Estimates are labelled, shown as ranges and backed by a stated method.
- The matrix axes are explained, and the same rubric scores every player.
- Keep fact separate from judgment; mark the implications as analysis.
- Balanced: name where the company is weaker, not only where it wins.

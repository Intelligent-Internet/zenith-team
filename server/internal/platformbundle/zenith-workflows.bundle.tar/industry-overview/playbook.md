# Industry overview

You are writing a primer that brings a smart reader who is new to an
industry up to working fluency. They should finish it able to explain how
money flows, who holds power, what moves growth and margins, and which
companies matter. Good primers are structural rather than newsy, quantify
wherever they can, triangulate market size instead of quoting one headline
number, and end with the questions insiders actually argue about. This is
research, not investment advice.

## Inputs

- Industry, geographic scope, audience and format, plus — when given —
  focus questions and the companies the team already tracks.
- If the industry is loosely defined ("fintech", "AI"), set a precise scope
  in the first section, state what you excluded and why, and proceed.
- The audience sets emphasis. Public equity wants listed players, cycles
  and KPIs; private equity wants fragmentation, consolidation and deal
  multiples; venture wants disruption vectors and funding flows; strategy
  wants value chain power and adjacencies; credit wants cyclicality, cash
  flow stability and asset coverage.

## Procedure

1. **Define the industry.** What is in and out, the products and customer
   groups, and the classification codes (NAICS, NACE or GICS) behind any
   statistics you use.
2. **Size and growth.** Triangulate with at least two methods: official
   statistics (national statistics offices, the US Census Bureau, BEA,
   Eurostat), trade association data, a bottom-up sum of the main players'
   revenues, or units × price. Show the range, the method behind each
   number and a five-year history. Figures quoted from market research
   press releases are labelled as such, with methodology unknown.
3. **Structure.** Concentration (top-five share, and HHI where data
   allows), fragmentation, cyclicality, capital intensity, barriers to
   entry, buyer and supplier power and substitutes. Back each point with a
   fact, not an assertion.
4. **Value chain.** Every step from inputs to end customer. For each: what
   happens, typical players, the revenue pool, typical gross and operating
   margins (from cited listed comparables), capital intensity and who holds
   pricing power. Draw it as a diagram (Graphviz or matplotlib) with the
   margins annotated.
5. **Economics.** Revenue models, cost structure (the largest cost lines
   as a share of revenue), unit economics of a typical operator, and the
   KPIs insiders use — for example same-store sales in retail, the combined
   ratio in insurance, RevPAR in hotels, book-to-bill in semiconductors,
   ARPU and churn in telecoms. Define each KPI and give a current
   benchmark with its source.
6. **Growth drivers and headwinds.** Separate secular from cyclical forces
   and quantify sensitivities where possible, including technology shifts
   and substitutes.
7. **Regulation.** Regulators, licensing, the rules that matter and their
   economic effect, and pending changes with dates.
8. **Key players.** A table of 10 to 25 companies: name, listed or
   private, HQ, revenue, estimated share, place in the value chain, a
   one-line positioning in your own words, and owner. Include every company
   the team tracks.
9. **Capital and M&A.** Recent notable transactions with disclosed
   multiples, sponsor activity, listings and funding trends.
10. **Debates and what to watch.** Three to five live questions, each with
    both sides and the data that would settle it, and a dated calendar of
    upcoming regulatory or industry events.

## Deliverables

- **Primary:** `primer-<industry>.docx` for the written format or
  `primer-<industry>.pptx` for slides (one idea per slide, a headline that
  states the takeaway, a source line on every slide). Open with an
  executive summary, follow the sections above, and close with a glossary
  and sources.
- For "Both", the document is primary and the slides are `--final`.
- **Supporting:** `players.csv` holding the key players table, and the
  value chain diagram as `value-chain.png`.
- Present:

  ```sh
  zen output present --type file --title "Industry primer — <industry>" \
    --summary "<size, growth and the most important structural fact>" \
    --primary primer-<industry>.docx="Industry primer" \
    --final primer-<industry>.pptx="Slide primer" \
    --supporting players.csv="Key players" \
    --supporting value-chain.png="Value chain"
  ```

  Keep only the items you produced; for slides alone, the `.pptx` is the
  `--primary`. If python-docx or python-pptx is missing, deliver Markdown
  with the diagram as PNG and use `--type text`.

## Quality bar

- Every figure has a source and a year; market size shows its range and
  method.
- Margin and share claims come from cited filings or data, never intuition.
- Define every acronym on first use; the glossary covers industry jargon.
- Keep facts, estimates and interpretation visibly separate.
- No marketing language: company descriptions are your own words.

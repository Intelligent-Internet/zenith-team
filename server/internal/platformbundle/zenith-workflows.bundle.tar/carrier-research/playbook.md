# Insurance carrier research

You are researching which insurance carriers and markets are worth
approaching for one risk. The reader is a broker, an account executive or a
risk manager who needs a defensible shortlist: carriers that actually write
this class in this jurisdiction, are financially strong enough, and offer
the coverage features this risk needs. Good work separates stated appetite
from guesswork, cites every rating with its date and treats price as
unknown until quoted. This is research support; placement decisions belong
to a licensed broker, and only underwriters can confirm appetite and terms.

## Inputs

- The risk, lines, location, exposure details, market type, minimum
  rating, priorities and carriers to include or exclude — all in the brief.
- If the risk is described too loosely to judge appetite ("a business"),
  define the most likely class from the details, state it, and continue.
- Do not contact carriers, request quotes or submit anything.
- The sources below are US-specific. Outside the US, use the local
  regulator's register of authorised insurers and its rules for
  non-admitted or overseas insurers, and say which equivalents you used.

## Procedure

1. **Frame the risk.** Restate the class of business, size, jurisdiction,
   limits and retention sought, loss history and anything that narrows the
   market (hazardous operations, prior claims, new venture). Decide
   whether it is likely a standard, middle-market or specialty risk, since
   that decides where to look.
2. **Build the long list** (15–25 names) from:
   - Carrier appetite guides, class lists and program pages published on
     carrier websites.
   - The state insurance department's licensing look-up for admitted
     status in the jurisdiction.
   - For excess and surplus lines, the state's surplus lines stamping
     office or eligible-insurer list and the NAIC Quarterly Listing of
     Alien Insurers; Lloyd's syndicates and managing agents when specialty
     markets are allowed.
   - Programs and managing general agents that specialize in the class.
   - Carriers named in the brief, including the incumbent.
3. **Screen.** Remove carriers that are not licensed or eligible in the
   jurisdiction, fall below the minimum rating, or state they exclude the
   class. Keep a record of each removal and its reason.
4. **Research each remaining carrier.**
   - **Financial strength:** AM Best rating and outlook, plus S&P, Moody's
     or Fitch where available, each with its date and source page; note
     group versus individual company ratings.
   - **Market standing:** direct premiums in the line and state (NAIC
     data or the carrier's filings, when public).
   - **Complaints:** the NAIC complaint index where published (1.00
     means complaints in proportion to premium volume; higher is worse).
   - **Appetite:** classes, size bands, limits capacity, states and
     distribution (open brokerage, appointment required, wholesale only).
     Mark each as "stated (source)" or "inferred (why)".
   - **Coverage features** relevant to the lines: occurrence or
     claims-made, retroactive date, defence inside or outside limits,
     key sublimits, notable exclusions and endorsements. Use specimen
     policies, filed forms (SERFF Filing Access in many states) or carrier
     product sheets. For cyber, check ransomware and social-engineering
     cover and dependent business interruption; for liability,
     additional-insured wording and per-project aggregates.
   - **Services:** risk-control, claims handling reputation and
     available pre-loss services.
5. **Explain admitted versus non-admitted trade-offs** for this risk:
   state guaranty funds generally protect admitted policies only; surplus
   lines placements carry premium taxes and, in many states, a diligent
   search requirement before placement; rates and forms are more flexible.
6. **Score fit.** Criteria from the brief's priorities, each scored 1–5
   with a one-line justification, weighted (the brief's priorities share
   70% of the weight; other criteria share 30%). Price competitiveness is
   scored only from public rate-filing evidence and is otherwise
   "unknown".
7. **Recommend a shortlist** of three to six to approach, in order, each
   with why it fits, what to confirm, and two or three questions for the
   underwriter.

## Deliverables

- **Primary:** `carrier-research.md` (or `.docx`): risk framing, market
  overview, shortlist with rationale, admitted versus non-admitted note,
  questions for underwriters, excluded carriers and why, sources.
- **Final:** `carrier-comparison.xlsx` with sheets `Long list` (carrier,
  group, admitted status, ratings with dates, appetite and its basis,
  distribution), `Coverage grid`, `Scoring` (weights and scores with
  formulas), `Removed` and `Sources`. If openpyxl is missing, deliver one
  CSV per sheet as `--supporting` items and show the scoring weights and
  arithmetic in the report.
- Present:

  ```sh
  zen output present --type text --title "Carrier research — <risk>" \
    --summary "<shortlist size and the top candidate in one sentence>" \
    --primary carrier-research.md="Carrier research" \
    --final carrier-comparison.xlsx="Carrier comparison"
  ```

## Quality bar

- Every rating has an agency, a date and a source link; outdated ratings
  are flagged.
- Appetite is labelled stated or inferred; nothing is presented as a
  guarantee that a carrier will quote.
- No premium estimates presented as quotes.
- Carriers are compared on the same criteria and the scoring is
  reproducible from the workbook.

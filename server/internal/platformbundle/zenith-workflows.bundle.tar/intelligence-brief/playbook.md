# Intelligence brief

You are telling a decision-maker what actually changed about one company,
sector or topic over a fixed period, and which of those changes deserve
their attention. The reader has no time for a news roll: they want the few
developments that move their plans, ranked by consequence, each dated,
sourced and explained in a sentence. A good brief separates what is
confirmed from what is reported or rumoured, and says plainly when a quiet
period was genuinely quiet.

## Inputs

- The subject, its type, the period, and the reader's relationship to it.
  Convert the period into exact start and end dates (end = today) and
  print them in the header.
- The dimensions to cover, the length, what the reader already knows and
  their source preferences. Do not re-report what they say they know
  unless it changed.
- If the subject is ambiguous (two companies with one name, a sector with
  fuzzy edges), pick the reading the context supports, state it in one
  line under the header, and keep going. Stop only when nothing about the
  subject can be found at all.
- A web-scraping Connector (Firecrawl) helps read pages that block simple
  fetches; a LinkedIn Connector helps with executive statements and
  hiring signals. Everything also works with ordinary web search.

## Procedure

1. **Frame.** Write down the subject's aliases, tickers, subsidiaries and
   key people (for a company), or an inclusion rule (for a sector or
   topic: which firms, products and jurisdictions count). From the
   reader's relationship, write the three to five questions a sharp
   analyst in their seat would ask. These drive the ranking.
2. **Collect broadly, by dimension.** Run date-restricted searches for the
   subject combined with each dimension's vocabulary (launch, pricing,
   raises, acquires, appoints, resigns, lawsuit, fine, outage, breach,
   guidance). Work down this source ladder:
   - **Primary:** regulatory filings (SEC EDGAR 8-K, 10-Q, 6-K; Companies
     House; national registries), earnings materials and transcripts,
     official newsroom, blog and changelog, court dockets, regulator and
     legislature pages, standards bodies.
   - **Secondary:** established business and trade press, wire services.
   - **Signals only:** social posts, forums, job boards, review sites.
     Never rank a development on signals alone.
   For non-English subjects, search in the local language too.
3. **Turn coverage into events.** One event is one real-world development.
   Merge every article about it into a single row with: event date (when
   it happened, not when it was reported), first-report date, best
   primary source, number of independent sources, and dimension. Drop
   anything whose event date falls outside the period, except earlier
   events whose consequences landed inside it (label those).
4. **Verify.** Mark each event **Confirmed** (a primary source or the
   subject itself), **Reported** (two or more independent reputable
   outlets) or **Unconfirmed** (one outlet, or social only). Unconfirmed
   items go in a separate short list, never in the ranked body.
5. **Score significance** from 1 to 5 on each factor and sum:
   - **Magnitude** — money, customers, people or market share affected.
   - **Durability** — how hard it is to reverse.
   - **Relevance** — how directly it answers the reader's questions. For
     a competitor lens weight product, pricing, customers and hiring; for
     an investor lens weight financials, guidance, capital and
     leadership; for a customer lens weight pricing, reliability,
     security and the supplier's financial health.
   - **Surprise** — how far it departs from what was expected.
   - **Certainty** — Confirmed 5, Reported 3.
   Tier the results: **Material** (top scores, usually three to seven),
   **Notable**, and **Background**. Adjust by judgement where the sum
   misleads, and say why.
6. **Synthesize.** Look across events for the pattern: a pivot, a squeeze,
   an acceleration, a regulatory turn. State it as a claim with the
   events that support it and any that cut against it. Answer the
   reader's questions directly, including "no evidence found".
7. **Look ahead.** List dated things to watch: scheduled earnings,
   regulatory deadlines, product events, contract renewals, court
   dates, and the observable signal that would confirm or refute each
   open question.
8. **Fit the length.** Headlines: bottom line plus the Material tier in
   one line each. Standard: full body. Deep: add the full event log as
   an appendix.

## Deliverables

- **Primary:** `intelligence-brief.md` titled "Intelligence brief —
  <subject> — <start> to <end>", with:
  1. Header: subject, exact period, as-of date, the lens used, and any
     disambiguation note.
  2. Bottom line: at most five sentences on what changed and what it
     means for the reader.
  3. Material developments, ranked: headline, event date, what happened
     (two to three sentences), why it matters to the reader, status
     (Confirmed or Reported), source links.
  4. Notable developments: one or two lines each, with links.
  5. Background: one line each.
  6. Patterns and implications, and answers to the reader's questions.
  7. Watch list: date, item, what to look for.
  8. Unconfirmed reports, gaps and method: sources searched, languages,
     what could not be verified.
- **Supporting:** `events.csv` with columns rank, tier, event_date,
  dimension, headline, magnitude, durability, relevance, surprise,
  certainty, score, status, sources.
- Present them:

  ```sh
  zen output present --type text --title "Intelligence brief — <subject>" \
    --summary "<the single most significant development, in one sentence>" \
    --primary intelligence-brief.md="Intelligence brief" \
    --supporting events.csv="Event log"
  ```

## Quality bar

- Every development has a date and at least one working link; every
  Material item has a primary source or two independent reputable ones.
- Rank by consequence to this reader, not by recency or volume of
  coverage. A widely covered non-event stays out of the Material tier.
- Separate fact from inference in the wording ("filed", "announced" versus
  "suggests", "likely"). Never state a rumour as fact.
- Numbers keep their units, currency and period; restated figures cite
  the restatement.
- If the period was quiet, say so in the bottom line and keep the brief
  short. Do not pad with background to fill space.

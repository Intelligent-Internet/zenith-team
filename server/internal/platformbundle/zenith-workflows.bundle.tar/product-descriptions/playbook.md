# Product descriptions

You are writing the selling copy for a set of products: titles, descriptions,
bullet points and search tags that a store owner can import and publish with
light edits. Good copy is specific (it names materials, sizes and uses),
answers the questions a buyer has before paying, reads like the brand, fits the
channel's limits exactly and never claims anything the facts do not support.
Generic adjectives ("premium", "high quality", "perfect for everyone") are a
sign you did not have or did not use the facts.

## Inputs

- The brief gives the product set, the facts per product, the channel, length,
  language, audience, target search terms, voice notes, a page to match and
  claims to avoid.
- If the product facts are a link you cannot open, stop and report it; never
  write copy for products you cannot see. With a store Connector (Shopify),
  read product records, variants and existing copy read-only.
- A missing fact is not a reason to stop: write around it and mark it
  `[confirm: fabric weight]` so the owner can fill it in.

## Procedure

1. **Build a fact sheet per product.** Name, SKU, variants (size, colour),
   materials and composition, dimensions and weight, capacity or fit, what is
   in the box, care, compatibility, origin, certifications, warranty, price
   tier. Tag each fact with its source (brief, store record, page). List the
   gaps per product.
2. **Learn the voice.** From the samples, the store URL or the voice notes,
   write five to seven concrete rules: person (we/you), sentence length,
   sensory versus technical vocabulary, formality, humour, words the brand
   uses and words it never uses. With no input, choose a clear, warm, plain
   voice and say so. Apply the same rules to every product.
3. **Choose search terms.** Use the brief's terms first. Otherwise research
   how buyers phrase it: marketplace search suggestions, competitor titles
   and "people also ask" questions. Give each product one primary term and
   two to four secondary terms, and make sure two
   products in the set do not chase the same primary term; separate them by
   the distinguishing attribute ("queen linen duvet cover" vs "king").
4. **List buyer questions.** For each product type, note the five questions a
   buyer asks before buying (fit, compatibility, care, what is included,
   durability), from reviews, Q&A sections and FAQs. The copy must answer them.
5. **Write to the channel's rules.** The limits below are long-standing but
   channels change them: confirm the current rule in the channel's seller
   help pages before finalizing, and cite the page in the review document.
   - **Own store:** product title under about 70 characters, noun first; body
     opens with who it is for and the main benefit, then feature-to-benefit
     paragraphs, then a specs block (materials, dimensions, care, in the box);
     SEO title 50-60 characters; meta description 140-155 characters with the
     primary term and a reason to click; lowercase hyphenated URL handle; image
     alt text that describes the picture in under 125 characters.
   - **Amazon:** follow the category style guide in Seller Central for the
     current title limit (keep it short and front-loaded either way): brand,
     product type, key attributes, size or count. Five bullets, one idea each,
     starting with a short capitalised benefit phrase. No prices, promotions,
     "best seller" or decorative symbols. Backend search terms under 250 bytes,
     no repeats, no competitor brands.
   - **Etsy:** title up to 140 characters with the most descriptive words
     first; 13 tags of up to 20 characters, as multi-word phrases; spend
     tags on synonyms and variants rather than repeating the title's exact
     words.
   - **eBay:** title up to 80 characters, no filler words; list the item
     specifics (brand, size, colour, material) as a separate block.
   - **Google Shopping feed:** title up to 150 characters with the important
     attributes in the first 70 (brand, type, material, colour, size);
     description plain text, no promotional text, no all caps.
   - **Several channels:** write the store version first, then derive each
     marketplace version from it; do not paste the same text everywhere.
6. **Keep the set distinct.** Variants and near-identical products get
   different opening lines that lead with their distinguishing attribute.
   Do not copy a manufacturer's description; rewrite it.
7. **Audit claims.** Every claim traces to a fact. Remove or flag: health and
   medical claims, unqualified environmental claims ("eco-friendly", "green"),
   origin claims such as "Made in USA" unless the facts support them fully,
   "handmade" unless it is, superlatives no one can verify, and anything on the
   brief's avoid list. Keep regulated details (fibre content, allergens,
   safety warnings) exactly as supplied.
8. **Check mechanically.** Count characters and bytes with a script, not by
   eye, and fix everything over a limit. Scan for banned words and for the
   primary term in the title, first sentence and SEO title.

## Deliverables

- **Primary:** `product-copy.csv`, one row per product (or variant when the
  copy differs), columns: `sku`, `handle`, `product_name`, `title`,
  `seo_title`, `meta_description`, `description_html`, `bullet_1` to
  `bullet_5`, `tags`, `image_alt`, `primary_term`, `facts_to_confirm`. Use
  simple HTML (`<p>`, `<ul>`, `<strong>`) in `description_html`. For a Shopify
  store, also note which columns map to Shopify's import headers (Handle,
  Title, Body (HTML), Tags, SEO Title, SEO Description, Image Alt Text) and
  advise exporting a backup and test-importing one product first.
- **Final:** `product-copy.md`: the voice rules, the search-term map, each
  product's copy in readable form, the claims audit (claim, source, kept or
  removed) and a "Facts to confirm" list grouped by product.
- Present them:

  ```sh
  zen output present --type file --title "Product descriptions — <product set>" \
    --summary "<n> products written for <channel>; <n> facts to confirm" \
    --primary product-copy.csv="Import-ready copy" \
    --final product-copy.md="Copy review document"
  ```

## Quality bar

- Nothing is invented: every material, measurement, certification and promise
  comes from the facts, or is marked `[confirm: …]`.
- Every field fits its channel limit, checked by script.
- The first sentence of each description tells a buyer what it is and why it
  suits them; a reader can find size, material and care in five seconds.
- Search terms read naturally; no term appears more than twice in a
  description, and no keyword lists are stuffed into the body.
- The copy sounds like the brand across the whole set, and no two products
  share the same opening line.

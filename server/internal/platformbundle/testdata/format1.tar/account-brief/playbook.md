# Account brief

Research the account.
